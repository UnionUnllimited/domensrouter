"""
Менеджер обновлений через загрузку zip-архива.

Workflow:
  1. upload_zip(content)        — сохраняем zip в data/uploads/, парсим его
  2. analyze_upload(token)      — возвращаем превью: какие файлы изменятся
  3. apply_upload(token, pin)   — делаем бэкап, распаковываем, удаляем zip

Защиты:
  - Архивы только до 50 МБ
  - Файлы внутри проверяются на zip-slip (попытки выйти из /app)
  - Файлы из этих папок/имён ИГНОРИРУЮТСЯ при распаковке:
      .env, data/*, /Caddyfile (если есть свой)
  - Перед заменой делается полный бэкап в data/backups/upload_<timestamp>/
  - Применение требует ПИН-подтверждения (как рестарт)
"""

from __future__ import annotations

import hashlib
import io
import os
import secrets
import shutil
import time
import zipfile
from datetime import datetime
from pathlib import Path


# Корень проекта в контейнере. Используем чтобы класть бэкапы и читать структуру.
PROJECT_ROOT = Path(os.getenv("PROJECT_ROOT", "/app"))
BACKUP_DIR = Path(os.getenv("BACKUP_DIR", "/app/data/backups"))
UPLOADS_DIR = Path(os.getenv("UPLOADS_DIR", "/app/data/uploads"))

# Лимит размера архива
MAX_ZIP_SIZE = 50 * 1024 * 1024  # 50 МБ

# Файлы и папки, которые НЕ ТРОГАЕМ при обновлении.
# Реальные данные (тексты, кнопки, авто-ответы) теперь хранятся в БД,
# а texts.py / keyboards.py — это «источник дефолтов» в коде. Их можно
# спокойно перезаписывать — данные клиента в content_texts/buttons/qa
# при этом не пострадают.
PROTECTED_PATHS = {
    ".env",
    "data",       # БД со всем редактируемым контентом, бэкапы
    ".git",
    "__pycache__",
}

# Файлы которые ОБЯЗАНЫ быть в архиве, чтобы считать его «нашим проектом»
REQUIRED_MARKERS = ["app/main.py"]

# In-memory state: {token: {zip_path, sha256, pin, expires_at, file_count}}
# Состояние живёт в памяти процесса. Если админка перезапустится — токен
# инвалидируется, нужно загружать заново.
_pending: dict[str, dict] = {}
_PENDING_TTL = 15 * 60  # 15 минут на подтверждение
_PIN_TTL = 90  # 90 секунд после старта confirm


# ============================================================
#  Helpers
# ============================================================

def _gc_pending() -> None:
    """Удаляем протухшие токены."""
    now = time.time()
    to_del = [tok for tok, info in _pending.items() if info["expires_at"] < now]
    for tok in to_del:
        _drop_token(tok)


def _drop_token(token: str) -> None:
    """Удаляет токен и связанный с ним zip-файл."""
    info = _pending.pop(token, None)
    if info and "zip_path" in info:
        try:
            Path(info["zip_path"]).unlink(missing_ok=True)
        except Exception:
            pass


def _detect_common_prefix(names: list[str]) -> str:
    """[v3.5] Если ВСЕ файлы архива лежат под одной верхней папкой
    (например 'vpn_support_bot/app/main.py', 'vpn_support_bot/Dockerfile'),
    возвращает эту папку — её надо обрезать при распаковке.

    Возвращает '' если общего префикса нет, или 'prefix/' (со слэшем).
    """
    file_names = [n for n in names if not n.endswith("/")]
    if not file_names:
        return ""

    # Берём первый сегмент каждого пути
    first_segs = set()
    for n in file_names:
        norm = n.replace("\\", "/")
        if "/" not in norm:
            return ""  # есть файлы в корне → общего префикса нет
        first_segs.add(norm.split("/", 1)[0])

    if len(first_segs) != 1:
        return ""

    prefix = first_segs.pop()
    # Защитная проверка: префикс не должен совпадать с реальной папкой проекта
    if prefix in ("app", "admin_web", "data"):
        return ""

    return prefix + "/"


def _strip_prefix(rel_path: str, prefix: str) -> str:
    """Удаляет общий префикс из пути архива."""
    if prefix and rel_path.startswith(prefix):
        return rel_path[len(prefix):]
    return rel_path


def _is_protected(rel_path: str) -> bool:
    """
    Проверяет, что путь не попадает в защищённую папку/файл.

    Защита срабатывает если:
      - путь точно совпадает с защищённой записью (например 'app/texts.py')
      - первый сегмент пути совпадает с защищённой папкой ('data', '.env', и т.п.)
      - путь начинается с защищённой записи + '/' (для папок)
    """
    norm = rel_path.replace("\\", "/")
    if not norm:
        return True
    if norm.startswith("/"):
        # абсолютный путь — точно отвергаем
        return True

    # Точное совпадение пути (например 'app/texts.py')
    if norm in PROTECTED_PATHS:
        return True

    # Совпадение префикса: путь внутри защищённой папки
    for protected in PROTECTED_PATHS:
        if norm.startswith(protected + "/"):
            return True

    # Первый сегмент совпадает (для обратной совместимости — например '.env')
    parts = norm.split("/")
    if parts[0] in PROTECTED_PATHS:
        return True

    return False


def _is_safe_path(rel_path: str) -> bool:
    """Защита от zip-slip — путь не должен выходить за корень."""
    if rel_path.startswith("/") or rel_path.startswith("\\"):
        return False
    # Резолвим относительный путь
    norm = os.path.normpath(rel_path)
    if norm.startswith(".."):
        return False
    if "/.." in norm.replace("\\", "/"):
        return False
    return True


# ============================================================
#  Этап 1: загрузка
# ============================================================

def upload_zip(content: bytes, original_filename: str = "upload.zip") -> dict:
    """
    Принимает байты zip-файла. Валидирует, сохраняет в data/uploads/,
    возвращает токен для следующих операций.

    Возвращает: {ok: bool, token: str, sha256: str, message: str}
    """
    _gc_pending()

    if len(content) > MAX_ZIP_SIZE:
        return {
            "ok": False,
            "message": f"Файл слишком большой ({len(content) // 1024 // 1024} МБ). "
                       f"Максимум {MAX_ZIP_SIZE // 1024 // 1024} МБ.",
        }

    if len(content) < 1024:
        return {"ok": False, "message": "Файл подозрительно маленький (<1 КБ)"}

    # Пробуем открыть как zip
    try:
        with zipfile.ZipFile(io.BytesIO(content)) as zf:
            names = zf.namelist()
            if not names:
                return {"ok": False, "message": "Архив пустой"}

            # [v3.5] Определяем общий префикс (например 'vpn_support_bot/')
            # и обрезаем при проверке маркеров.
            common_prefix = _detect_common_prefix(names)
            effective_names = [_strip_prefix(n, common_prefix) for n in names]

            # Проверяем что есть маркеры нашего проекта
            for marker in REQUIRED_MARKERS:
                if marker not in effective_names and not any(
                    n.endswith(marker) for n in effective_names
                ):
                    return {
                        "ok": False,
                        "message": (
                            f"В архиве нет файла <code>{marker}</code>. "
                            "Это не похоже на архив бота поддержки."
                        ),
                    }

            # Проверяем zip-slip и общую безопасность
            for name in names:
                if not _is_safe_path(name):
                    return {
                        "ok": False,
                        "message": (
                            f"Подозрительный путь в архиве: <code>{name}</code>. "
                            "Архив отклонён."
                        ),
                    }

    except zipfile.BadZipFile:
        return {"ok": False, "message": "Это не zip-архив или он повреждён"}

    # Считаем хэш для отображения
    sha = hashlib.sha256(content).hexdigest()

    # Сохраняем
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_name = f"upload_{stamp}_{sha[:8]}.zip"
    zip_path = UPLOADS_DIR / safe_name
    zip_path.write_bytes(content)

    token = secrets.token_urlsafe(24)
    _pending[token] = {
        "zip_path": str(zip_path),
        "sha256": sha,
        "size": len(content),
        "original_filename": original_filename,
        "expires_at": time.time() + _PENDING_TTL,
        "file_count": len(names),
        "common_prefix": common_prefix,  # [v3.5] для распаковки
        "pin": None,
        "pin_expires_at": 0,
    }

    return {
        "ok": True,
        "token": token,
        "sha256": sha,
        "size": len(content),
        "file_count": len(names),
        "message": "Архив загружен и проверен",
    }


# ============================================================
#  Этап 2: анализ
# ============================================================

def analyze_upload(token: str) -> dict | None:
    """
    Возвращает превью изменений: какие файлы будут добавлены, заменены,
    защищённые — будут пропущены.

    Возвращает None если токен невалидный/протух.
    """
    _gc_pending()
    info = _pending.get(token)
    if not info:
        return None

    zip_path = Path(info["zip_path"])
    if not zip_path.exists():
        _drop_token(token)
        return None

    added: list[dict] = []
    replaced: list[dict] = []
    skipped: list[dict] = []
    common_prefix = info.get("common_prefix", "")

    try:
        with zipfile.ZipFile(zip_path) as zf:
            for zi in zf.infolist():
                if zi.is_dir():
                    continue
                # [v3.5] Обрезаем общий префикс архива
                rel = _strip_prefix(zi.filename, common_prefix)
                if not rel:
                    continue
                if _is_protected(rel):
                    skipped.append({"path": rel, "reason": "защищённый файл"})
                    continue
                if not _is_safe_path(rel):
                    skipped.append({"path": rel, "reason": "небезопасный путь"})
                    continue

                target = PROJECT_ROOT / rel
                size_kb = round(zi.file_size / 1024, 1)
                entry = {"path": rel, "size_kb": size_kb}

                if target.exists():
                    # Проверяем — действительно ли отличается
                    try:
                        existing = target.read_bytes()
                        new_content = zf.read(zi)
                        if existing == new_content:
                            # Идентичный файл — пропустим в чейнджлисте
                            continue
                        existing_size_kb = round(len(existing) / 1024, 1)
                        entry["old_size_kb"] = existing_size_kb
                        entry["diff_bytes"] = abs(len(new_content) - len(existing))
                        replaced.append(entry)
                    except Exception:
                        replaced.append(entry)
                else:
                    added.append(entry)
    except zipfile.BadZipFile:
        return None

    return {
        "token": token,
        "sha256": info["sha256"],
        "size": info["size"],
        "original_filename": info.get("original_filename", "—"),
        "added": added,
        "replaced": replaced,
        "skipped": skipped,
        "total_changes": len(added) + len(replaced),
        "expires_in": max(0, int(info["expires_at"] - time.time())),
    }


# ============================================================
#  Этап 3: подтверждение через ПИН
# ============================================================

def request_apply_pin(token: str) -> dict | None:
    """
    Генерирует ПИН для подтверждения применения архива.
    Возвращает {pin: "1234", expires_in: int} или None.
    """
    info = _pending.get(token)
    if not info:
        return None

    pin = f"{secrets.randbelow(10000):04d}"
    info["pin"] = pin
    info["pin_expires_at"] = time.time() + _PIN_TTL
    return {"pin": pin, "expires_in": _PIN_TTL}


def apply_upload(token: str, pin: str) -> dict:
    """
    Применяет обновление: бэкап + распаковка.

    Возвращает {ok: bool, message: str, backup_path: str}.

    Само перезапускает контейнеры — вызывающий код должен это сделать.
    """
    _gc_pending()
    info = _pending.get(token)
    if not info:
        return {"ok": False, "message": "Токен невалиден или истёк. Загрузи архив заново."}

    if not info.get("pin"):
        return {"ok": False, "message": "ПИН не запрошен. Открой страницу обновления заново."}

    if time.time() > info["pin_expires_at"]:
        info["pin"] = None
        return {"ok": False, "message": "Время на ввод ПИНа истекло. Запроси новый."}

    if pin.strip() != info["pin"]:
        return {"ok": False, "message": "Неверный ПИН"}

    zip_path = Path(info["zip_path"])
    if not zip_path.exists():
        _drop_token(token)
        return {"ok": False, "message": "Файл архива потерян. Загрузи заново."}

    # 1. Делаем бэкап всех файлов, которые БУДУТ заменены
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = BACKUP_DIR / f"upload_{stamp}"
    backup_dir.mkdir(parents=True, exist_ok=True)

    backed_up_count = 0
    extracted_count = 0
    skipped_count = 0
    common_prefix = info.get("common_prefix", "")

    try:
        with zipfile.ZipFile(zip_path) as zf:
            # Сначала бэкап
            for zi in zf.infolist():
                if zi.is_dir():
                    continue
                # [v3.5] Обрезаем общий префикс (vpn_support_bot/ → "")
                rel = _strip_prefix(zi.filename, common_prefix)
                if not rel:
                    continue
                if _is_protected(rel) or not _is_safe_path(rel):
                    continue
                target = PROJECT_ROOT / rel
                if target.exists():
                    backup_target = backup_dir / rel
                    backup_target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, backup_target)
                    backed_up_count += 1

            # Теперь распаковываем
            for zi in zf.infolist():
                if zi.is_dir():
                    continue
                rel = _strip_prefix(zi.filename, common_prefix)
                if not rel:
                    continue
                if _is_protected(rel) or not _is_safe_path(rel):
                    skipped_count += 1
                    continue
                target = PROJECT_ROOT / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(zi) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
                extracted_count += 1
    except Exception as e:
        return {
            "ok": False,
            "message": f"Ошибка при применении: {e}. Возможно, обновление частично прошло. "
                       f"Бэкап в {backup_dir}.",
            "backup_path": str(backup_dir),
        }

    # Чистим токен и сам файл архива — больше не нужен
    _drop_token(token)

    return {
        "ok": True,
        "message": (
            f"Обновление применено. Файлов: добавлено/заменено {extracted_count}, "
            f"в бэкапе {backed_up_count}, пропущено защищённых {skipped_count}."
        ),
        "backup_path": str(backup_dir),
        "extracted_count": extracted_count,
        "backed_up_count": backed_up_count,
    }


def cancel_upload(token: str) -> bool:
    """Отменяет загрузку (удаляет zip и токен)."""
    if token in _pending:
        _drop_token(token)
        return True
    return False
