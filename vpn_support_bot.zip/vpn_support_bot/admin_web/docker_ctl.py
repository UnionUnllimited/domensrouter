"""
Управление контейнером бота через Docker socket.

Что делает:
- Видит, запущен ли контейнер vpn_support_bot.
- Перезапускает его командой эквивалентной `docker restart`.

Использует UNIX-сокет Docker (/var/run/docker.sock), который пробрасывается
в контейнер admin_web через docker-compose.yml. Без этого сокета модуль
просто вернёт ошибку — функция останется недоступной, остальная админка
работать продолжит.
"""

from __future__ import annotations

import asyncio
import json
import os
from urllib.parse import quote

import aiohttp


# Имя контейнера бота из docker-compose.yml
BOT_CONTAINER = os.getenv("BOT_CONTAINER_NAME", "vpn_support_bot")
DOCKER_SOCK_PATH = os.getenv("DOCKER_SOCK_PATH", "/var/run/docker.sock")


def is_available() -> bool:
    """Доступен ли сокет Docker (примонтирован ли в контейнер)."""
    return os.path.exists(DOCKER_SOCK_PATH)


async def _api_call(
    method: str,
    path: str,
    timeout: int = 15,
) -> tuple[int, dict | str]:
    """
    Низкоуровневый запрос к Docker Engine API через UNIX-сокет.
    Возвращает (status, body) — body это dict если JSON, иначе str.
    """
    connector = aiohttp.UnixConnector(path=DOCKER_SOCK_PATH)
    timeout_ = aiohttp.ClientTimeout(total=timeout)
    async with aiohttp.ClientSession(connector=connector, timeout=timeout_) as session:
        url = f"http://localhost{path}"
        async with session.request(method, url) as resp:
            text = await resp.text()
            try:
                return resp.status, json.loads(text) if text else {}
            except json.JSONDecodeError:
                return resp.status, text


async def container_info() -> dict:
    """
    Возвращает короткое состояние контейнера бота.
    Поля: name, available, exists, running, status, started_at, error.
    """
    info: dict = {
        "name": BOT_CONTAINER,
        "available": is_available(),
        "exists": False,
        "running": False,
        "status": "unknown",
        "started_at": None,
        "error": None,
    }

    if not info["available"]:
        info["error"] = (
            f"Docker socket {DOCKER_SOCK_PATH} не примонтирован — "
            f"управление контейнером недоступно."
        )
        return info

    try:
        status, body = await _api_call(
            "GET",
            f"/containers/{quote(BOT_CONTAINER)}/json",
        )
        if status == 404:
            info["error"] = f"Контейнер {BOT_CONTAINER} не найден"
            return info
        if status != 200 or not isinstance(body, dict):
            info["error"] = f"Docker API ответил HTTP {status}"
            return info

        info["exists"] = True
        state = body.get("State", {})
        info["running"] = bool(state.get("Running"))
        info["status"] = state.get("Status") or "unknown"
        info["started_at"] = state.get("StartedAt")
    except aiohttp.ClientError as e:
        info["error"] = f"Ошибка обращения к Docker: {e}"
    except asyncio.TimeoutError:
        info["error"] = "Таймаут запроса к Docker"

    return info


async def restart_container() -> tuple[bool, str]:
    """
    Перезапускает контейнер бота. Возвращает (success, message).
    """
    if not is_available():
        return False, "Docker socket не примонтирован"

    try:
        status, body = await _api_call(
            "POST",
            f"/containers/{quote(BOT_CONTAINER)}/restart?t=10",
            timeout=30,
        )
    except aiohttp.ClientError as e:
        return False, f"Ошибка обращения к Docker: {e}"
    except asyncio.TimeoutError:
        return False, "Таймаут — операция могла не завершиться"

    if status == 204:
        return True, "Контейнер перезапущен"
    if status == 404:
        return False, f"Контейнер {BOT_CONTAINER} не найден"

    # Ошибка
    msg = body
    if isinstance(body, dict):
        msg = body.get("message") or str(body)
    return False, f"HTTP {status}: {msg}"


async def rebuild_all() -> tuple[bool, str]:
    """
    Пересборка и поднятие всех контейнеров: `docker compose up -d --build`.

    Используется функцией «Обновление» в админке после применения нового
    архива. Команда выполняется через subprocess — docker-compose-plugin
    должен быть установлен в образе админки (см. Dockerfile).

    ВНИМАНИЕ: эта команда перезапустит САМ контейнер админки тоже.
    Текущий процесс будет убит. Нужно вызывать через BackgroundTask
    после отправки ответа клиенту.
    """
    if not is_available():
        return False, "Docker socket не примонтирован"

    # Путь к docker-compose.yml внутри контейнера — мы его примонтировали
    # в /app/docker-compose.yml через docker-compose.yml volumes.
    compose_file = "/app/docker-compose.yml"
    if not os.path.exists(compose_file):
        return False, f"Файл {compose_file} не найден"

    # Для команды нужна рабочая директория, где docker compose поймёт
    # относительные пути volumes (./app, ./data). Используем /app.
    proc = await asyncio.create_subprocess_exec(
        "docker", "compose",
        "-f", compose_file,
        "up", "-d", "--build",
        cwd="/app",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )

    try:
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=300)
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        return False, "Сборка длится слишком долго (>5 мин), убита"

    output = stdout.decode("utf-8", errors="replace") if stdout else ""

    if proc.returncode == 0:
        # Берём последние 500 символов вывода — для лога
        tail = output[-500:] if len(output) > 500 else output
        return True, f"Контейнеры пересобраны. Вывод (хвост):\n{tail}"

    return False, f"docker compose вернул код {proc.returncode}. Вывод:\n{output[-2000:]}"


async def rebuild_down_up() -> tuple[bool, str]:
    """
    [v3.5] Полный цикл: `docker compose down` → `docker compose up -d --build`.

    Запускается в DETACHED subprocess через nohup, чтобы пережить
    смерть собственного контейнера (down убьёт админку, потом up её
    поднимет заново). Возвращается СРАЗУ после запуска — операция
    выполняется в фоне, HTTP-ответ успеет дойти до клиента.

    После вызова:
    - админка станет недоступна на 30-90 сек
    - страницу надо обновить (F5) после возврата
    - вывод docker compose пишется в /tmp/restart.log внутри хоста
    """
    if not is_available():
        return False, "Docker socket не примонтирован"

    compose_file = "/app/docker-compose.yml"
    if not os.path.exists(compose_file):
        return False, f"Файл {compose_file} не найден"

    # Detached команда: пауза 2с чтобы вернуть HTTP-ответ, потом down + up.
    # nohup + setsid + & — отделяем от родительского процесса полностью.
    # Перенаправляем stdout/stderr в файл — пригодится для дебага.
    cmd = (
        "nohup setsid bash -c '"
        "sleep 2 && "
        f"docker compose -f {compose_file} down && "
        f"docker compose -f {compose_file} up -d --build"
        "' > /tmp/restart.log 2>&1 &"
    )

    try:
        proc = await asyncio.create_subprocess_shell(
            cmd,
            cwd="/app",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        # Ждём чтобы shell успел запустить background-команду и вернуться
        try:
            await asyncio.wait_for(proc.wait(), timeout=3)
        except asyncio.TimeoutError:
            # Это нормально — &-команда отделилась, ждём отказались
            pass
        return True, (
            "Запущен полный rebuild (down + up --build). Контейнер "
            "перезапустится в фоне. Через 60-90 секунд обновите страницу (F5)."
        )
    except Exception as e:
        return False, f"Не смог запустить rebuild: {e}"