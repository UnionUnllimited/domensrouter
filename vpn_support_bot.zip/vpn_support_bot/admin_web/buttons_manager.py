"""
Менеджер кнопок через БД (content_buttons).

Полностью совместимый со старым API:
  - list_menus() → список меню
  - get_menu(name) → {name, title, items, flat, ...}
  - update_button(menu, index, text, kind, value) → (ok, msg)
  - move_button(menu, index, direction) → (ok, msg)
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

import aiosqlite

DB_PATH = os.getenv("DB_PATH", "/app/data/vpn_support.db")
SIGNAL_FILE = Path(os.getenv("CONTENT_SIGNAL", "/app/data/content_reload.signal"))


_MENU_TITLES = {
    "main_menu": ("Главное меню", "Что видит клиент при /start"),
    "pay_menu": ("Меню оплаты", "Раздел «💳 Оплата»"),
    "bot_menu": ("Меню проблем с ботом", "Раздел «🤖 Проблема с ботом»"),
    "vpn_menu": ("Меню работы VPN", "Раздел «🛜 Работа VPN»"),
    "community_menu": ("Меню чата сообщества", "Раздел «💬 Спросить в чате»"),
    "mykey_back_keyboard": ("Кнопка «Назад» в Мой ключ", "Под сообщением профиля"),
    "mykey_reset_confirm_keyboard": ("Подтверждение сброса", "Сброс подписки клиента"),
}


# Маппинг: имя меню → ключ текста, который показывается боту вместе с этим меню.
# Нужно чтобы при редактировании меню админ мог сразу править и его текст.
MENU_TO_TEXT = {
    "main_menu":     "WELCOME",
    "pay_menu":      "PAY_MENU",
    "bot_menu":      "BOT_MENU",
    "vpn_menu":      "VPN_MENU",
    "community_menu": "COMMUNITY_INFO",
}


# Маппинг: имя меню → callback-кнопка, которая ведёт в это меню из других мест
# (главное меню и т.п.). Нужно для каскадного удаления: когда удаляем меню,
# заодно убираем все кнопки которые в него вели, иначе клиент кликнет
# и попадёт в пустоту.
MENU_TO_CALLBACK = {
    "pay_menu":       "m_pay",
    "bot_menu":       "m_bot",
    "vpn_menu":       "m_vpn",
    "community_menu": "m_community",
}


# [v3.5] Обратный маппинг для редактора: callback → имя подменю.
# Используется в buttons_menu.html чтобы понять, что системная кнопка
# `m_pay` ведёт в `pay_menu` (без submenu_name, потому что это статика).
CALLBACK_TO_MENU = {v: k for k, v in MENU_TO_CALLBACK.items()}

# [v3.5] Дополнительные callback-кнопки которые ведут в виртуальные меню.
# Это «🔑 Мой ключ» и другие — клавиатура генерится динамически в keyboards.py,
# но мы показываем виртуальное представление для редактора.
CALLBACK_TO_MENU["m_mykey"] = "mykey_menu"
CALLBACK_TO_MENU["back_main"] = "main_menu"  # кнопка «🏠 Главное меню» в подменю


# Маппинг: callback кнопки → ключ текста, который бот отправляет/показывает
# при нажатии на эту кнопку. Зашит в коде бота:
#   - FAQ_ARTICLES — для конечных FAQ-кнопок (a_*)
#   - SECTION_MENUS — для кнопок-переходов на другие меню (m_*)
# Если у кнопки value есть в этом маппинге — на странице редактирования
# кнопки покажем редактор соответствующего текста.
CALLBACK_TO_TEXT = {
    # === Кнопки-переходы на другие меню (m_*) ===
    # При нажатии бот показывает текст соответствующего меню.
    "m_pay":               "PAY_MENU",
    "m_bot":               "BOT_MENU",
    "m_vpn":               "VPN_MENU",
    "m_community":         "COMMUNITY_INFO",

    # === FAQ-статьи: Оплата ===
    "a_pay_no_page":       "PAY_NO_PAGE",
    "a_pay_tariffs":       "PAY_TARIFFS",
    "a_pay_autorenew":     "PAY_AUTORENEW",
    # === FAQ-статьи: Бот ===
    "a_bot_no_sub":        "BOT_NO_SUB",
    "a_bot_no_key":        "BOT_NO_KEY",
    "a_bot_broken":        "BOT_BUTTONS_BROKEN",
    "a_bot_slow":          "BOT_SLOW",
    "a_bot_pay_err":       "BOT_PAY_ERROR",
    "a_bot_paid_not_work": "BOT_PAID_NOT_WORK",
    # === FAQ-статьи: VPN ===
    "a_vpn_how":           "VPN_HOW_CONNECT",
    "a_vpn_where":         "VPN_WHERE_SUB",
    "a_vpn_not_work":      "VPN_NOT_WORKING",
    "a_vpn_happ_na":       "VPN_HAPP_NA",
    "a_vpn_ping":          "VPN_PING",
    "a_vpn_router":        "VPN_ROUTER",
    "a_vpn_other":         "VPN_OTHER_DEVICE",
}


# Системные меню — их можно удалять (по запросу пользователя),
# но с большим предупреждением. Раньше они были полностью защищены.
# Теперь PROTECTED_MENUS используется только для ВИЗУАЛЬНОГО маркера 🔒
# и предупреждения, не для блокировки удаления.
PROTECTED_MENUS = frozenset({
    "main_menu", "pay_menu", "bot_menu", "vpn_menu", "community_menu",
    "mykey_back_keyboard", "mykey_reset_confirm_keyboard",
})

# [v3.5] Меню которые НЕЛЬЗЯ удалить ни при каких условиях.
# Это критически важные части бота — если их удалить, клиент потеряет
# доступ к функциям. Кнопки удаления для них в UI не показываются.
UNREMOVABLE_MENUS = frozenset({
    "main_menu",
    "service_menu",   # системное меню
    "mykey_menu",     # динамическое меню «Мой ключ»
})


def _touch_signal() -> None:
    try:
        SIGNAL_FILE.parent.mkdir(parents=True, exist_ok=True)
        SIGNAL_FILE.touch(exist_ok=True)
        os.utime(SIGNAL_FILE, None)
    except Exception:
        pass


def _run(coro):
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as ex:
                return ex.submit(asyncio.run, coro).result()
        return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


def _is_env_placeholder(value: str) -> bool:
    """Распознаёт значения типа {COMMUNITY_CHAT_URL} — их редактировать нельзя."""
    return bool(value) and value.startswith("{") and value.endswith("}")


# ============================================================
#  list_menus
# ============================================================

async def _list_menus_async() -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT menu_name, COUNT(*) FROM content_buttons GROUP BY menu_name"
        )
        rows = await cur.fetchall()
    menu_counts = dict(rows)

    result = []
    for name, (title, desc) in _MENU_TITLES.items():
        if name not in menu_counts:
            continue
        result.append({
            "name": name,
            "title": title,
            "description": desc,
            "buttons_count": menu_counts[name],
        })
    for name, cnt in menu_counts.items():
        if name not in _MENU_TITLES:
            result.append({
                "name": name,
                "title": name,
                "description": "(нет описания)",
                "buttons_count": cnt,
            })
    return result


def list_menus() -> list[dict]:
    return _run(_list_menus_async())


# ============================================================
#  [v3.5] Иерархия меню — для навигатора с breadcrumb
# ============================================================

async def _find_parents_async(menu_name: str) -> list[dict]:
    """Возвращает список меню которые ссылаются на это подменю.
    Каждый элемент: {'menu': str, 'button_index': int, 'button_text': str}
    """
    if not menu_name:
        return []
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        # 1) Динамические submenu кнопки (submenu_name=...)
        result = []
        try:
            cur = await db.execute(
                """SELECT menu_name, position, text FROM content_buttons
                   WHERE submenu_name = ? AND menu_name != ?
                   ORDER BY menu_name, position""",
                (menu_name, menu_name),
            )
            for r in await cur.fetchall():
                result.append({
                    "menu": r["menu_name"],
                    "button_index": r["position"],
                    "button_text": r["text"],
                })
        except Exception:
            pass

        # 2) Статические callback-ссылки (m_pay → pay_menu из MENU_TO_CALLBACK)
        ref_callback = MENU_TO_CALLBACK.get(menu_name)
        if ref_callback:
            try:
                cur = await db.execute(
                    """SELECT menu_name, position, text FROM content_buttons
                       WHERE kind='callback' AND value=? AND menu_name != ?
                       ORDER BY menu_name, position""",
                    (ref_callback, menu_name),
                )
                seen = {(r["menu"], r["button_index"]) for r in result}
                for r in await cur.fetchall():
                    key = (r["menu_name"], r["position"])
                    if key not in seen:
                        result.append({
                            "menu": r["menu_name"],
                            "button_index": r["position"],
                            "button_text": r["text"],
                        })
            except Exception:
                pass
    return result


def find_parents(menu_name: str) -> list[dict]:
    """Меню которые ведут на это подменю (через submenu кнопку)."""
    return _run(_find_parents_async(menu_name))


def find_breadcrumb(menu_name: str, max_depth: int = 8) -> list[dict]:
    """[v3.5] Путь от корневого меню до этого.
    Возвращает [{'name': str, 'title': str}, ...] от корня до текущего.

    Если несколько родителей — берёт ПЕРВОГО (по алфавиту), это редкий
    кейс когда одно подменю ссылается из разных мест.
    """
    path: list[dict] = []
    seen = set()
    current = menu_name
    while current and current not in seen and len(path) < max_depth:
        seen.add(current)
        title, _ = _MENU_TITLES.get(current, (current, ""))
        path.insert(0, {"name": current, "title": title})
        parents = find_parents(current)
        if not parents:
            break
        # Берём первого родителя (по алфавиту имени меню)
        parents.sort(key=lambda p: p["menu"])
        current = parents[0]["menu"]
    return path


def is_root_menu(menu_name: str) -> bool:
    """Корневое меню — никто на него не ссылается."""
    return len(find_parents(menu_name)) == 0


async def _list_root_menus_async() -> list[dict]:
    """Меню без родителей — то что показывается на главной /buttons."""
    all_menus = await _list_menus_async()
    roots = []
    for m in all_menus:
        parents = await _find_parents_async(m["name"])
        if not parents:
            roots.append(m)
    return roots


def list_root_menus() -> list[dict]:
    """Меню верхнего уровня — те на которые никто не ссылается."""
    return _run(_list_root_menus_async())


# ============================================================
#  get_menu — возвращает items И flat (для совместимости со старым шаблоном)
# ============================================================

async def _get_menu_async(name: str) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        # [v3.5] Админка показывает ВСЕ кнопки, включая скрытые.
        # response_text/submenu_name — для динамических кнопок (try/except
        # на случай старой БД без миграции).
        try:
            cur = await db.execute(
                """
                SELECT position, text, kind, value,
                       COALESCE(hidden, 0) AS hidden,
                       response_text, submenu_name
                FROM content_buttons
                WHERE menu_name = ?
                ORDER BY position
                """,
                (name,),
            )
            rows = await cur.fetchall()
        except Exception:
            # Старая схема без новых колонок
            cur = await db.execute(
                """
                SELECT position, text, kind, value,
                       COALESCE(hidden, 0) AS hidden
                FROM content_buttons
                WHERE menu_name = ?
                ORDER BY position
                """,
                (name,),
            )
            rows = await cur.fetchall()

    if not rows:
        return None

    title, desc = _MENU_TITLES.get(name, (name, ""))

    flat = []
    for r in rows:
        is_env = _is_env_placeholder(r["value"]) or _is_env_placeholder(r["text"])
        # Безопасно достаём новые поля (может не быть в старой БД)
        try:
            response_text = r["response_text"]
        except (KeyError, IndexError):
            response_text = None
        try:
            submenu_name = r["submenu_name"]
        except (KeyError, IndexError):
            submenu_name = None

        # [v3.5] target_menu — в какое подменю ведёт эта кнопка.
        # Это объединение:
        #   1) Динамические кнопки → submenu_name (из БД)
        #   2) Системные кнопки → CALLBACK_TO_MENU (статический маппинг)
        #   3) FAQ-кнопки (a_*) → нет подменю, но есть текст
        target_menu = submenu_name or CALLBACK_TO_MENU.get(r["value"])

        # [v3.5] has_response_text — есть ли у кнопки прикреплённый текст.
        # Динамические: response_text в БД.
        # Статические: CALLBACK_TO_TEXT[value] есть в маппинге.
        has_response = bool(response_text) or (r["value"] in CALLBACK_TO_TEXT)

        flat.append({
            "index": r["position"],
            "text": r["text"],
            "kind": r["kind"],
            "value": r["value"],
            "hidden": bool(r["hidden"]),
            "response_text": response_text,
            "submenu_name": submenu_name,
            "target_menu": target_menu,        # [v3.5] куда ведёт кнопка
            "has_response": has_response,      # [v3.5] есть ли текст-ответ
            "editable": not is_env,
            "readonly": is_env,
        })

    # items — для совместимости со старыми шаблонами
    return {
        "name": name,
        "title": title,
        "description": desc,
        "items": flat,
        "flat": flat,                       # старое имя
        "ENV_BUTTONS_COUNT": sum(1 for b in flat if b["readonly"]),
        "rows": [[b] for b in flat],        # каждая кнопка в своём ряду — для обратной совместимости
    }


def get_menu(name: str) -> dict | None:
    real = _run(_get_menu_async(name))
    if real is not None:
        return real
    # [v3.5] Виртуальные меню для просмотра — например mykey_menu
    # Бот генерит эти клавиатуры на лету в коде, в БД их нет.
    # Показываем readonly-представление чтобы оператор видел структуру.
    return _virtual_menu(name)


# [v3.5] Шаблоны виртуальных меню (для просмотра в редакторе).
# Кнопки помечаются как readonly — нельзя редактировать или удалять.
_VIRTUAL_MENUS = {
    "mykey_menu": {
        "title": "🔑 Мой ключ (динамическое)",
        "info": (
            "Это динамическое меню — клавиатура генерируется кодом бота "
            "по контексту клиента (показывает кнопку «Страница подключения» "
            "если у клиента есть активная подписка). Кнопки тут можно только "
            "посмотреть, для изменений нужна правка кода в keyboards.py."
        ),
        "buttons": [
            {"text": "🌐 Страница подключения", "kind": "url",
             "value": "(динамически)", "is_virtual": True,
             "info": "Показывается только если у клиента есть подписка"},
            {"text": "🔁 Сбросить подписку", "kind": "callback",
             "value": "mk_reset", "is_virtual": True,
             "info": "Запросить сброс через оператора"},
            {"text": "🏠 Главное меню", "kind": "callback",
             "value": "back_main", "is_virtual": True,
             "info": "Возврат в главное меню"},
        ],
    },
}


def _virtual_menu(name: str) -> dict | None:
    """Возвращает виртуальное представление меню которого нет в БД.
    Используется для системных меню которые формируются в коде.

    [v3.5] Кнопки можно скрывать (через virtual_button_hidden), но НЕ
    редактировать структурно (текст/value жёстко зашиты в код бота).
    """
    tpl = _VIRTUAL_MENUS.get(name)
    if not tpl:
        return None
    # Получаем какие кнопки скрыты в этом виртуальном меню
    try:
        from app import content_db
        hidden_set = _run(content_db.get_virtual_hidden_set(name))
    except Exception:
        hidden_set = set()
    flat = []
    for i, b in enumerate(tpl["buttons"]):
        flat.append({
            "index": i,
            "text": b["text"],
            "kind": b["kind"],
            "value": b["value"],
            "hidden": b["value"] in hidden_set,  # [v3.5] из virtual_button_hidden
            "response_text": None,
            "submenu_name": None,
            "target_menu": CALLBACK_TO_MENU.get(b["value"]),
            "has_response": False,
            "editable": False,        # текст/value redoonly (зашиты в коде)
            "readonly": True,         # для UI — нельзя удалять/менять
            "is_virtual": True,
            # [v3.5] hideable=True означает что кнопку можно ВКЛ/ВЫКЛ
            "hideable": True,
            "info": b.get("info", ""),
        })
    return {
        "name": name,
        "title": tpl["title"],
        "buttons_count": len(flat),
        "flat": flat,
        "is_virtual": True,
        "virtual_info": tpl["info"],
    }


# ============================================================
#  Запись всего меню
# ============================================================

async def _replace_menu_async(menu_name: str, buttons: list[dict]) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "DELETE FROM content_buttons WHERE menu_name = ?", (menu_name,),
        )
        for pos, btn in enumerate(buttons):
            # [v3.5] response_text и submenu_name — для динамических кнопок
            await db.execute(
                """
                INSERT INTO content_buttons
                  (menu_name, position, text, kind, value,
                   response_text, submenu_name, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                """,
                (
                    menu_name, pos,
                    btn["text"], btn["kind"], btn["value"],
                    btn.get("response_text"), btn.get("submenu_name"),
                ),
            )
        await db.commit()


def _serialize_button(b: dict) -> dict:
    """[v3.5] Полная сериализация кнопки для _replace_menu_async.

    ВАЖНО: всегда включает response_text и submenu_name! Иначе при любой
    операции (update/move/delete) эти поля у остальных кнопок ОБНУЛЯЮТСЯ —
    что ломает подменю и тексты-ответы. Это был критичный баг до v3.5.
    """
    return {
        "text": b["text"],
        "kind": b["kind"],
        "value": b["value"],
        "response_text": b.get("response_text"),
        "submenu_name": b.get("submenu_name"),
    }


# ============================================================
#  update_button — со старой сигнатурой (text, kind, value)
# ============================================================

def update_button(menu: str, index: int,
                  text: str = None, kind: str = None,
                  value: str = None) -> tuple[bool, str]:
    """
    Изменяет кнопку на позиции index.

    Поддерживает старую сигнатуру (text, kind, value) и новую (text=, value=).
    """
    m = get_menu(menu)
    if not m:
        return False, f"Меню {menu} не найдено"
    if index < 0 or index >= len(m["flat"]):
        return False, f"Кнопка с индексом {index} не существует"

    btn = dict(m["flat"][index])
    if btn["readonly"]:
        return False, (
            "Эта кнопка ссылается на URL из переменной .env, "
            "её надпись и значение менять нельзя через админку. "
            "Меняй .env на сервере."
        )

    # Применяем изменения
    if text is not None:
        if not text.strip():
            return False, "Надпись не может быть пустой"
        if len(text) > 128:
            return False, "Надпись слишком длинная (>128)"
        btn["text"] = text

    if kind is not None:
        if kind not in ("callback", "url"):
            return False, f"Тип '{kind}' не поддерживается (только callback или url)"
        btn["kind"] = kind

    if value is not None:
        if not value.strip():
            return False, "Значение не может быть пустым"
        if len(value) > 512:
            return False, "Значение слишком длинное (>512)"
        btn["value"] = value

    # Сохраняем всё меню целиком (нужно потому что в БД primary key = (menu, position))
    # [v3.5] КРИТИЧНО: используем _serialize_button чтобы НЕ потерять
    # response_text/submenu_name у остальных кнопок.
    buttons_to_save = []
    for i, it in enumerate(m["flat"]):
        if i == index:
            # Применяем изменения, но сохраняем response_text и submenu_name
            buttons_to_save.append({
                "text": btn["text"],
                "kind": btn["kind"],
                "value": btn["value"],
                "response_text": it.get("response_text"),
                "submenu_name": it.get("submenu_name"),
            })
        else:
            buttons_to_save.append(_serialize_button(it))

    try:
        _run(_replace_menu_async(menu, buttons_to_save))
        _touch_signal()
        return True, "Кнопка обновлена в БД"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


# ============================================================
#  move_button
# ============================================================

def move_button(menu: str, index: int, direction: str) -> tuple[bool, str]:
    """direction: 'up' | 'down'."""
    m = get_menu(menu)
    if not m:
        return False, f"Меню {menu} не найдено"
    items = list(m["flat"])
    if index < 0 or index >= len(items):
        return False, "Кнопка не существует"

    new_index = index - 1 if direction == "up" else index + 1
    if new_index < 0 or new_index >= len(items):
        return False, "Двигать дальше некуда"

    items[index], items[new_index] = items[new_index], items[index]

    # [v3.5] КРИТИЧНО: _serialize_button сохраняет response_text/submenu_name
    buttons_to_save = [_serialize_button(it) for it in items]
    try:
        _run(_replace_menu_async(menu, buttons_to_save))
        _touch_signal()
        return True, "Кнопка перемещена"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


# ============================================================
#  add_button — добавление новой кнопки в меню
# ============================================================

def add_button(
    menu: str, text: str, kind: str, value: str,
    response_text: str | None = None,
    submenu_name: str | None = None,
) -> tuple[bool, str]:
    """
    [v3.5] Добавляет новую кнопку в конец меню.

    kind: 'callback' | 'url'
    value: callback_data (для callback) или url (для url)
    response_text: если кнопка должна отвечать текстом при нажатии
                   (только для callback) — бот пошлёт этот текст
    submenu_name: если кнопка должна открывать подменю при нажатии
                  (только для callback) — бот откроет указанное меню

    Бот ловит динамические callback через универсальный handler и смотрит
    в БД: если есть submenu_name → открывает меню; иначе если есть
    response_text → шлёт текст; иначе вызывает статический handler.
    """
    m = get_menu(menu)
    if not m:
        return False, f"Меню {menu} не найдено"

    text = (text or "").strip()
    value = (value or "").strip()
    kind = (kind or "callback").strip().lower()
    response_text = (response_text or "").strip() or None
    submenu_name = (submenu_name or "").strip().lower() or None

    if not text:
        return False, "Надпись не может быть пустой"
    if len(text) > 128:
        return False, "Надпись слишком длинная (>128)"
    if not value:
        return False, "Значение не может быть пустым"
    if kind not in ("callback", "url"):
        return False, f"Неизвестный тип: {kind}"
    if kind == "url" and not (
        value.startswith("http://") or value.startswith("https://")
        or value.startswith("tg://")
    ):
        return False, "URL должен начинаться с http://, https:// или tg://"
    if response_text and len(response_text) > 4000:
        return False, "Текст ответа слишком длинный (>4000)"
    if submenu_name and not _MENU_NAME_RE.match(submenu_name):
        return False, (
            "Имя подменю должно быть из латинских букв/цифр/_ "
            "(например: my_submenu)"
        )

    items = list(m["flat"])
    items.append({
        "text": text, "kind": kind, "value": value,
        "response_text": response_text,
        "submenu_name": submenu_name,
    })

    # [v3.5] КРИТИЧНО: используем _serialize_button чтобы сохранить
    # response_text/submenu_name у всех кнопок (включая новую).
    buttons_to_save = [_serialize_button(it) for it in items]
    try:
        _run(_replace_menu_async(menu, buttons_to_save))
        # [v3.5] Если это submenu-кнопка и подменю ещё не существует —
        # создаём его пустым автоматически. Не требуем от админа делать
        # это вручную в два шага.
        if submenu_name:
            existing = get_menu(submenu_name)
            if existing is None:
                # Имя для отображения берём из надписи кнопки
                _run(_create_menu_async(submenu_name, text))
        _touch_signal()
        return True, "Кнопка добавлена"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


# ============================================================
#  delete_button — удаление кнопки
# ============================================================

def delete_button(menu: str, index: int) -> tuple[bool, str]:
    m = get_menu(menu)
    if not m:
        return False, f"Меню {menu} не найдено"
    items = list(m["flat"])
    if index < 0 or index >= len(items):
        return False, "Кнопка не существует"

    btn = items[index]
    if btn.get("readonly"):
        return False, (
            "Эта кнопка пришла из .env / texts.py, удалить нельзя — "
            "она нужна боту."
        )

    del items[index]
    # [v3.5] КРИТИЧНО: _serialize_button сохраняет response_text/submenu_name
    buttons_to_save = [_serialize_button(it) for it in items]
    try:
        _run(_replace_menu_async(menu, buttons_to_save))
        _touch_signal()
        return True, "Кнопка удалена"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


# ============================================================
#  Список ВСЕХ занятых callback-имён (для автоподсказки)
# ============================================================

def list_used_callbacks() -> list[str]:
    """
    Возвращает отсортированный список всех уже занятых callback-имён
    среди всех меню. Нужно для автоподсказки нового имени без повторов.
    """
    used: set[str] = set()
    try:
        menus = list_menus()
    except Exception:
        return []
    for m_info in menus:
        try:
            menu_data = get_menu(m_info["name"])
        except Exception:
            continue
        if not menu_data:
            continue
        for btn in menu_data.get("flat", []):
            if btn.get("kind") == "callback":
                val = btn.get("value", "").strip()
                if val:
                    used.add(val)
    return sorted(used)


def suggest_next_callback(used: list[str] | None = None,
                          prefix: str = "m_new") -> str:
    """
    Предлагает следующее свободное имя callback'а вида prefix+N.
    Например: m_new1, m_new2... — не возвращает уже занятое.
    """
    if used is None:
        used = list_used_callbacks()
    used_set = set(used)
    n = 1
    while f"{prefix}{n}" in used_set:
        n += 1
    return f"{prefix}{n}"


# ============================================================
#  CREATE_MENU / DELETE_MENU — управление самими меню
# ============================================================

import re as _re_menu

_MENU_NAME_RE = _re_menu.compile(r"^[a-z][a-z0-9_]{1,30}$")


async def _create_menu_async(name: str, title: str = "") -> bool:
    """Создаёт пустое меню в БД. Возвращает True если создано, False если уже было."""
    async with aiosqlite.connect(DB_PATH) as db:
        # Проверим что меню ещё не существует
        cur = await db.execute(
            "SELECT 1 FROM content_buttons WHERE menu_name=? LIMIT 1",
            (name,),
        )
        if await cur.fetchone():
            return False
        # Если меню было ранее удалено (tombstone есть) — снимаем отметку,
        # иначе при рестарте бота миграция всё равно проигнорирует это меню.
        await db.execute(
            "DELETE FROM content_tombstones WHERE kind='menu' AND key=?",
            (name,),
        )
        # Создадим первую кнопку-заглушку — иначе меню не появится в списке
        # (т.к. список строится через GROUP BY content_buttons)
        await db.execute(
            "INSERT INTO content_buttons (menu_name, position, text, kind, value) "
            "VALUES (?, 0, ?, 'callback', 'placeholder')",
            (name, "Новая кнопка"),
        )
        await db.commit()
        return True


def create_menu(name: str, title: str = "") -> tuple[bool, str]:
    """
    Создаёт новое меню с одной заглушкой-кнопкой.
    Имя должно быть в нижнем регистре: [a-z][a-z0-9_]+.

    Если в имени системное меню — это допустимо (например админ удалил
    pay_menu и теперь хочет вернуть его обратно). Проверка существования
    идёт по БД в _create_menu_async, а не по статическому списку.
    """
    name = (name or "").strip().lower()
    if not _MENU_NAME_RE.match(name):
        return False, (
            "Имя меню должно состоять из латинских букв, цифр и _ "
            "(начинаться с буквы, например: my_menu)"
        )

    try:
        created = _run(_create_menu_async(name, title))
        if not created:
            return False, f"Меню «{name}» уже существует"
        _touch_signal()
        return True, "Меню создано"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


async def _delete_menu_async(name: str) -> int:
    """
    Удаляет все кнопки меню и помечает имя меню как удалённое (tombstone),
    чтобы migrate_from_files не восстановила его при следующем рестарте.
    Также КАСКАДНО удаляет все кнопки в других меню, которые ссылались
    на это меню (например, кнопка "💳 Оплата" в main_menu с callback m_pay
    при удалении pay_menu). Иначе клиент кликнет — попадёт в пустое меню.

    Возвращает количество удалённых строк (внутри меню + ссылки).
    """
    async with aiosqlite.connect(DB_PATH) as db:
        # 1) Удаляем кнопки внутри удаляемого меню
        cur = await db.execute(
            "DELETE FROM content_buttons WHERE menu_name=?",
            (name,),
        )
        deleted_inside = cur.rowcount

        # 2) Каскад: удаляем кнопки-ссылки на это меню из других меню
        deleted_refs = 0
        ref_callback = MENU_TO_CALLBACK.get(name)
        if ref_callback:
            cur2 = await db.execute(
                "DELETE FROM content_buttons "
                "WHERE kind='callback' AND value=? AND menu_name!=?",
                (ref_callback, name),
            )
            deleted_refs = cur2.rowcount

        # 3) Tombstone — чтобы миграция не восстановила
        await db.execute(
            "INSERT OR IGNORE INTO content_tombstones(kind, key) VALUES (?, ?)",
            ("menu", name),
        )
        await db.commit()

        # 4) Если каскадно что-то удалили — переупакуем position в задетых меню,
        # чтобы порядок остался плотным (0,1,2,3 без дыр)
        if deleted_refs > 0:
            cur3 = await db.execute(
                "SELECT DISTINCT menu_name FROM content_buttons",
            )
            affected_menus = [r[0] for r in await cur3.fetchall()]
            for m in affected_menus:
                cur4 = await db.execute(
                    "SELECT rowid, position FROM content_buttons "
                    "WHERE menu_name=? ORDER BY position",
                    (m,),
                )
                rows = await cur4.fetchall()
                for new_pos, (rowid, old_pos) in enumerate(rows):
                    if new_pos != old_pos:
                        await db.execute(
                            "UPDATE content_buttons SET position=? WHERE rowid=?",
                            (new_pos, rowid),
                        )
            await db.commit()

        return deleted_inside + deleted_refs


def delete_menu(name: str) -> tuple[bool, str]:
    """
    Удаляет всё меню целиком (вместе со всеми кнопками внутри) и
    каскадно вычищает кнопки-ссылки на это меню из других меню.
    Системные меню (PROTECTED_MENUS) удалять МОЖНО, но это рискованно —
    код бота их ожидает. UI показывает предупреждение перед удалением.
    """
    name = (name or "").strip()
    if not name:
        return False, "Имя меню не указано"
    try:
        # Сначала посчитаем сколько ссылок будем удалять (для отчёта в сообщении)
        ref_callback = MENU_TO_CALLBACK.get(name)
        ref_count = 0
        if ref_callback:
            import sqlite3 as _sql
            with _sql.connect(DB_PATH) as _db:
                cur = _db.execute(
                    "SELECT COUNT(*) FROM content_buttons "
                    "WHERE kind='callback' AND value=? AND menu_name!=?",
                    (ref_callback, name),
                )
                ref_count = cur.fetchone()[0]

        deleted = _run(_delete_menu_async(name))
        if deleted == 0:
            return False, "Такого меню нет"
        _touch_signal()
        msg = f"Меню удалено (стёрто {deleted - ref_count} кнопок внутри)"
        if ref_count > 0:
            msg += f" + удалено {ref_count} ссылок на это меню в других меню"
        return True, msg
    except Exception as e:
        return False, f"Ошибка БД: {e}"
