"""
Менеджер авто-ответов через БД (content_qa).
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from pathlib import Path

import aiosqlite

DB_PATH = os.getenv("DB_PATH", "/app/data/vpn_support.db")
SIGNAL_FILE = Path(os.getenv("CONTENT_SIGNAL", "/app/data/content_reload.signal"))

KEY_RE = re.compile(r"^qa_[a-z0-9_]{1,30}$")

# Максимум фотографий к одному авто-ответу.
# Лимит выбран с запасом, но Telegram умеет рассылать sendMediaGroup
# до 10 фоток за раз — больше всё равно не имеет смысла.
MAX_PHOTOS_PER_QA = 10


def _parse_photos(raw: str | None) -> list[str]:
    """
    Парсит поле photo_path из БД. Поддерживает два формата:
    - JSON-массив: '["a.jpg","b.jpg"]' → ["a.jpg","b.jpg"]  (новый формат)
    - Просто имя файла: 'a.jpg' → ["a.jpg"]                  (старый формат)
    - NULL / пустая строка → []
    """
    if not raw:
        return []
    raw = raw.strip()
    if not raw:
        return []
    # Похоже на JSON-массив
    if raw.startswith("["):
        try:
            data = json.loads(raw)
            if isinstance(data, list):
                return [str(x).strip() for x in data if x and str(x).strip()]
        except (json.JSONDecodeError, ValueError):
            pass
    # Старый формат — одна строка
    return [raw]


def _serialize_photos(photos: list[str]) -> str | None:
    """Сериализует список путей в JSON для хранения в БД (или None если пусто)."""
    cleaned = [p.strip() for p in (photos or []) if p and p.strip()]
    if not cleaned:
        return None
    return json.dumps(cleaned, ensure_ascii=False)


def _touch_signal() -> None:
    try:
        SIGNAL_FILE.parent.mkdir(parents=True, exist_ok=True)
        SIGNAL_FILE.touch(exist_ok=True)
        os.utime(SIGNAL_FILE, None)
    except Exception:
        pass


def _run(coro):
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as ex:
                return ex.submit(asyncio.run, coro).result()
        return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


async def _list_async() -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        # [v3.5] Показываем ВСЕ ответы включая скрытые — это админская функция,
        # админу нужно видеть скрытые чтобы их вернуть/удалить.
        cur = await db.execute(
            """
            SELECT key, label, text, position, photo_path,
                   COALESCE(hidden, 0) AS hidden
            FROM content_qa
            ORDER BY position, key
            """
        )
        rows = await cur.fetchall()
    result = []
    for r in rows:
        photos = _parse_photos(r["photo_path"])
        result.append({
            "key": r["key"],
            "label": r["label"],
            "text": r["text"],
            "hidden": bool(r["hidden"]),  # [v3.5]
            # Обратная совместимость: photo_path = первая фотка (или None)
            "photo_path": photos[0] if photos else None,
            "photos": photos,
            "photos_count": len(photos),
            "length": len(r["text"]),
            "preview": r["text"][:80].replace("\n", " "),
            "has_text": True,
            "has_button": True,
            "has_photo": bool(photos),
        })
    return result


def list_answers() -> list[dict]:
    return _run(_list_async())


def get_answer(key: str) -> dict | None:
    for a in list_answers():
        if a["key"] == key:
            return a
    return None


async def _set_async(key: str, label: str, text: str,
                     position: int | None = None,
                     photo_path: str | None = None,
                     photos: list[str] | None = None) -> None:
    """
    INSERT OR UPDATE.

    Параметры:
    - photos: список путей. Если передан — сохраняется как JSON.
    - photo_path: один путь (для обратной совместимости). Если передан
      и photos=None, то записывается как одна фотка.
    - Если оба None — поле в БД НЕ трогается (частичный апдейт).
    - photo_path="" или photos=[] — СБРАСЫВАЕТ фото (NULL).
    """
    # Унификация: всегда работаем со списком
    if photos is not None:
        db_value = _serialize_photos(photos)
        touch_photo = True
    elif photo_path is not None:
        if photo_path == "":
            db_value = None
        else:
            db_value = _serialize_photos([photo_path])
        touch_photo = True
    else:
        db_value = None
        touch_photo = False

    async with aiosqlite.connect(DB_PATH) as db:
        # Если этот ключ ранее был удалён — снимаем tombstone, чтобы
        # пересозданная запись не была проигнорирована при следующем рестарте.
        await db.execute(
            "DELETE FROM content_tombstones WHERE kind='qa' AND key=?",
            (key,),
        )

        if position is None:
            cur = await db.execute(
                "SELECT COALESCE(MAX(position), -1) + 1 FROM content_qa"
            )
            row = await cur.fetchone()
            position = row[0]

        if not touch_photo:
            # Частичный апдейт — фото не трогаем
            await db.execute(
                """
                INSERT INTO content_qa (key, label, text, position, updated_at)
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(key) DO UPDATE SET
                    label = excluded.label,
                    text = excluded.text,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (key, label, text, position),
            )
        else:
            await db.execute(
                """
                INSERT INTO content_qa (key, label, text, position, photo_path, updated_at)
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(key) DO UPDATE SET
                    label = excluded.label,
                    text = excluded.text,
                    photo_path = excluded.photo_path,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (key, label, text, position, db_value),
            )
        await db.commit()


def update_text(key: str, new_text: str) -> tuple[bool, str]:
    if not KEY_RE.match(key):
        return False, "Некорректный ключ"
    if not new_text.strip():
        return False, "Текст не может быть пустым"
    if len(new_text) > 4000:
        return False, "Текст слишком длинный (>4000)"

    existing = get_answer(key)
    if not existing:
        return False, f"Ключ {key} не найден"

    try:
        _run(_set_async(key, existing["label"], new_text))
        _touch_signal()
        return True, "Текст обновлён в БД"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


def update_label(key: str, new_label: str) -> tuple[bool, str]:
    if not KEY_RE.match(key):
        return False, "Некорректный ключ"
    if not new_label or not new_label.strip():
        return False, "Надпись не может быть пустой"
    if len(new_label) > 128:
        return False, "Надпись слишком длинная (>128)"

    existing = get_answer(key)
    if not existing:
        return False, f"Ключ {key} не найден"

    try:
        _run(_set_async(key, new_label, existing["text"]))
        _touch_signal()
        return True, "Надпись обновлена в БД"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


def create_answer(key: str, label: str, text: str) -> tuple[bool, str]:
    """Создаёт новый авто-ответ в БД."""
    if not KEY_RE.match(key):
        return False, (
            "Ключ должен начинаться с qa_ и содержать только латиницу, "
            "цифры и подчёркивание"
        )
    if not label or not label.strip():
        return False, "Надпись кнопки не может быть пустой"
    if len(label) > 128:
        return False, "Надпись слишком длинная (>128)"
    if not text or not text.strip():
        return False, "Текст ответа не может быть пустым"
    if len(text) > 4000:
        return False, "Текст слишком длинный (>4000)"

    if any(a["key"] == key for a in list_answers()):
        return False, f"Авто-ответ {key} уже существует"

    try:
        _run(_set_async(key, label, text))
        _touch_signal()
        return True, f"Создан авто-ответ {key}"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


async def _delete_async(key: str) -> bool:
    """
    Удаляет авто-ответ и помечает его как удалённый (tombstone), чтобы
    миграция не восстановила его из ADMIN_ANSWERS при рестарте бота.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("DELETE FROM content_qa WHERE key = ?", (key,))
        deleted = cur.rowcount > 0
        await db.execute(
            "INSERT OR IGNORE INTO content_tombstones(kind, key) VALUES ('qa', ?)",
            (key,),
        )
        await db.commit()
        return deleted


def delete_answer(key: str) -> tuple[bool, str]:
    if not KEY_RE.match(key):
        return False, "Некорректный ключ"
    # Перед удалением — почистим ВСЕ файлы фото
    try:
        a = get_answer(key)
        if a:
            for p in (a.get("photos") or []):
                _delete_photo_file(p)
    except Exception:
        pass
    try:
        ok = _run(_delete_async(key))
        if not ok:
            return False, f"Авто-ответ {key} не найден"
        _touch_signal()
        return True, f"Авто-ответ {key} удалён"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


# ============================================================
#  УПРАВЛЕНИЕ ФОТО QA
# ============================================================
#
# Фото для авто-ответов хранятся в QA_PHOTOS_DIR. В БД хранится только
# относительный путь (имя файла) — без префикса директории.
# Это позволяет легко переносить директорию и не зависеть от абсолютных
# путей в БД.

QA_PHOTOS_DIR = Path(os.getenv("QA_PHOTOS_DIR", "/app/data/qa_photos"))
ALLOWED_PHOTO_EXT = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
MAX_PHOTO_SIZE = 8 * 1024 * 1024  # 8 МБ


def _ensure_photos_dir() -> None:
    """Создаёт директорию для QA-фоток если её нет."""
    QA_PHOTOS_DIR.mkdir(parents=True, exist_ok=True)


def get_photo_full_path(photo_path: str | None) -> Path | None:
    """
    Возвращает абсолютный путь к файлу фото или None если photo_path пустой
    либо файл не существует.
    """
    if not photo_path:
        return None
    full = QA_PHOTOS_DIR / photo_path
    if not full.exists():
        return None
    return full


def _delete_photo_file(photo_path: str | None) -> None:
    """Тихо удаляет файл фото если он существует."""
    if not photo_path:
        return
    try:
        full = QA_PHOTOS_DIR / photo_path
        if full.exists() and full.is_file():
            full.unlink()
    except Exception:
        pass


def add_photo(key: str, photo_bytes: bytes,
              original_filename: str) -> tuple[bool, str]:
    """
    Добавляет фото к авто-ответу. Если фото уже были — новое идёт в конец списка.

    Args:
        key: ключ авто-ответа
        photo_bytes: байты файла
        original_filename: оригинальное имя (для определения расширения)
    """
    import secrets
    if not KEY_RE.match(key):
        return False, "Некорректный ключ"
    if len(photo_bytes) > MAX_PHOTO_SIZE:
        return False, f"Фото больше {MAX_PHOTO_SIZE // 1024 // 1024} МБ"
    if len(photo_bytes) == 0:
        return False, "Пустой файл"

    # Определяем расширение
    ext = ".jpg"
    if "." in original_filename:
        candidate = "." + original_filename.rsplit(".", 1)[-1].lower()[:5]
        if candidate in ALLOWED_PHOTO_EXT:
            ext = candidate
        else:
            return False, (
                f"Формат не поддерживается. Допустимые: "
                f"{', '.join(sorted(ALLOWED_PHOTO_EXT))}"
            )

    # Загружаем текущую запись
    existing = get_answer(key)
    if not existing:
        return False, f"Авто-ответ {key} не найден"

    existing_photos = list(existing.get("photos") or [])
    if len(existing_photos) >= MAX_PHOTOS_PER_QA:
        return False, (
            f"Достигнут лимит {MAX_PHOTOS_PER_QA} фото на один авто-ответ. "
            "Удалите лишние перед добавлением новых."
        )

    # Создаём директорию, генерируем имя
    _ensure_photos_dir()
    new_name = f"{key}_{secrets.token_hex(6)}{ext}"
    new_path = QA_PHOTOS_DIR / new_name

    try:
        with open(new_path, "wb") as f:
            f.write(photo_bytes)
    except Exception as e:
        return False, f"Не удалось сохранить файл: {e}"

    # Добавляем новое фото в конец списка
    new_photos = existing_photos + [new_name]

    try:
        _run(_set_async(
            key, existing["label"], existing["text"],
            photos=new_photos,
        ))
        _touch_signal()
        return True, f"Фото загружено ({len(new_photos)}/{MAX_PHOTOS_PER_QA})"
    except Exception as e:
        # Откатываем
        _delete_photo_file(new_name)
        return False, f"Ошибка БД: {e}"


# Алиас для обратной совместимости: старый код может ещё звать set_photo,
# но теперь это просто добавление. Если оно действительно используется
# где-то для "замены" — там надо вызывать clear_photos + add_photo.
set_photo = add_photo


def remove_photo(key: str, photo_filename: str) -> tuple[bool, str]:
    """Удаляет ОДНО конкретное фото из списка."""
    if not KEY_RE.match(key):
        return False, "Некорректный ключ"
    existing = get_answer(key)
    if not existing:
        return False, f"Авто-ответ {key} не найден"

    existing_photos = list(existing.get("photos") or [])
    if photo_filename not in existing_photos:
        return False, "Такого фото нет в списке"

    # Удаляем файл с диска
    _delete_photo_file(photo_filename)

    # Обновляем список
    new_photos = [p for p in existing_photos if p != photo_filename]
    try:
        _run(_set_async(
            key, existing["label"], existing["text"],
            photos=new_photos,
        ))
        _touch_signal()
        if new_photos:
            return True, f"Фото удалено ({len(new_photos)} осталось)"
        return True, "Фото удалено (последнее)"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


def clear_photo(key: str) -> tuple[bool, str]:
    """Убирает ВСЕ фото с авто-ответа (файлы тоже удаляются)."""
    if not KEY_RE.match(key):
        return False, "Некорректный ключ"
    existing = get_answer(key)
    if not existing:
        return False, f"Авто-ответ {key} не найден"

    existing_photos = list(existing.get("photos") or [])
    if not existing_photos:
        return True, "Фото и так не было"

    for p in existing_photos:
        _delete_photo_file(p)

    try:
        _run(_set_async(
            key, existing["label"], existing["text"],
            photos=[],  # пустой список → NULL
        ))
        _touch_signal()
        return True, f"Удалено {len(existing_photos)} фото"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


# Алиас для нового имени
clear_photos = clear_photo
