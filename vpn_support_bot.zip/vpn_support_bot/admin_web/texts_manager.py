"""
Менеджер текстов через БД (content_texts).

Старая реализация писала в app/texts.py через AST. Сейчас все правки идут
в таблицу content_texts. Файл texts.py остаётся как источник дефолтов —
миграция при старте бота заливает оттуда ключи, которых ещё нет в БД.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

import aiosqlite

DB_PATH = os.getenv("DB_PATH", "/app/data/vpn_support.db")
SIGNAL_FILE = Path(os.getenv("CONTENT_SIGNAL", "/app/data/content_reload.signal"))


def _touch_signal() -> None:
    try:
        SIGNAL_FILE.parent.mkdir(parents=True, exist_ok=True)
        SIGNAL_FILE.touch(exist_ok=True)
        os.utime(SIGNAL_FILE, None)
    except Exception:
        pass


_TEXT_GROUPS = [
    {"id": "main", "title": "🏠 Главное меню",
     "description": "Стартовое сообщение при /start",
     "prefixes": ["WELCOME"]},
    {"id": "pay", "title": "💳 Оплата подписки",
     "description": "Раздел «Оплата»",
     "prefixes": ["PAY_"]},
    {"id": "bot", "title": "🤖 Проблема с ботом",
     "description": "Раздел «Проблема с ботом»",
     "prefixes": ["BOT_"]},
    {"id": "vpn", "title": "🛜 Работа VPN",
     "description": "Раздел «Работа VPN»",
     "prefixes": ["VPN_"]},
    {"id": "community", "title": "💬 Чат сообщества",
     "description": "Раздел «Спросить в нашем чате»",
     "prefixes": ["COMMUNITY_"]},
    {"id": "mykey", "title": "🔑 Мой ключ",
     "description": "Раздел «Мой ключ»",
     "prefixes": ["MYKEY_"]},
    {"id": "ticket", "title": "✉️ Тикеты и поддержка",
     "description": "Системные сообщения тикетной системы",
     "prefixes": ["CONTACT_", "TICKET_", "SUPPORT_", "USER_"]},
]


def _run(coro):
    """Запуск асинхронной функции из синхронного контекста FastAPI."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as ex:
                return ex.submit(asyncio.run, coro).result()
        return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


async def _list_async() -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT key, value FROM content_texts ORDER BY key"
        )
        rows = await cur.fetchall()
    return [
        {
            "name": k,
            "value": v,
            "length": len(v),
            "preview": v[:120].replace("\n", " ⏎ "),
        }
        for k, v in rows
    ]


def list_texts() -> list[dict]:
    return _run(_list_async())


def list_texts_grouped() -> list[dict]:
    all_texts = list_texts()
    used: set[str] = set()
    groups: list[dict] = []

    for group_def in _TEXT_GROUPS:
        items = []
        for t in all_texts:
            if t["name"] in used:
                continue
            for prefix in group_def["prefixes"]:
                if t["name"] == prefix or t["name"].startswith(prefix):
                    items.append(t)
                    used.add(t["name"])
                    break
        if items:
            groups.append({
                "id": group_def["id"],
                "title": group_def["title"],
                "description": group_def["description"],
                "entries": items,
            })

    other = [t for t in all_texts if t["name"] not in used]
    if other:
        groups.append({
            "id": "other",
            "title": "📦 Прочее",
            "description": "Тексты не вошедшие в разделы",
            "entries": other,
        })
    return groups


async def _get_async(name: str) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT key, value FROM content_texts WHERE key = ?", (name,),
        )
        row = await cur.fetchone()
    if not row:
        return None
    return {"name": row[0], "value": row[1]}


def get_text(name: str) -> dict | None:
    return _run(_get_async(name))


async def _set_async(name: str, value: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        # Если ключ ранее был удалён — снимаем tombstone, чтобы запись
        # сохранилась и не считалась "удалённой" после рестарта.
        await db.execute(
            "DELETE FROM content_tombstones WHERE kind='text' AND key=?",
            (name,),
        )
        await db.execute(
            """
            INSERT INTO content_texts (key, value, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(key) DO UPDATE SET
                value = excluded.value,
                updated_at = CURRENT_TIMESTAMP
            """,
            (name, value),
        )
        await db.commit()


def set_text(name: str, value: str) -> tuple[bool, str]:
    """Обновляет текст в БД."""
    if not name or not name.replace("_", "").isalnum():
        return False, "Некорректное имя"
    if value is None:
        return False, "Значение пустое"
    if len(value) > 4096:
        return False, "Текст слишком длинный (>4096)"

    try:
        _run(_set_async(name, value))
        _touch_signal()
        return True, "Сохранено в БД"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


# Алиас для обратной совместимости с роутами
update_text = set_text


async def _delete_async(name: str) -> bool:
    """
    Удаляет текст из БД и помечает его как намеренно удалённый (tombstone),
    чтобы при рестарте бота миграция не восстановила его из texts.py.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "DELETE FROM content_texts WHERE key = ?", (name,),
        )
        deleted = cur.rowcount > 0
        # Tombstone — даже если в БД ключа не было, ставим отметку
        # (на случай если он есть в texts.py и иначе восстановится).
        await db.execute(
            "INSERT OR IGNORE INTO content_tombstones(kind, key) VALUES ('text', ?)",
            (name,),
        )
        await db.commit()
        return deleted


# Защищённые ключи — их нельзя удалять из админки (использует код бота).
# Можно только редактировать. Список доступен извне (нужен для шаблона
# texts.html чтобы скрыть кнопку удаления для защищённых).
PROTECTED_TEXTS = frozenset({
    "WELCOME",
    "TICKET_CREATED", "TICKET_CLOSED",
    "SUPPORT_REPLY",
    "VPN_PLATFORM", "VPN_STEP1", "VPN_STEP2", "VPN_DESCRIBE",
    "PAYMENT_DESCRIBE",
    "CONTACT_PROMPT",
})


def delete_text(name: str) -> tuple[bool, str]:
    """
    Удаляет текст из БД. Внимание: если ключ используется в коде бота
    (например WELCOME, TICKET_CREATED), бот может упасть. Удалять
    нужно только пользовательские добавки.
    """
    if not name:
        return False, "Имя не указано"
    if name in PROTECTED_TEXTS:
        return False, (
            f"«{name}» — системный текст бота, удалять нельзя "
            "(если очень нужно — сначала уберите его из кода)."
        )
    try:
        deleted = _run(_delete_async(name))
        if not deleted:
            return False, "Такого ключа нет в БД"
        _touch_signal()
        return True, "Удалено"
    except Exception as e:
        return False, f"Ошибка БД: {e}"


def create_text(name: str, value: str) -> tuple[bool, str]:
    """
    Создаёт новый текст в БД. Если ключ уже есть — возвращает ошибку
    (используй set_text/update_text для обновления).
    """
    if not name:
        return False, "Имя не указано"
    name = name.strip().upper()
    if not name.replace("_", "").isalnum():
        return False, ("Имя должно содержать только латинские буквы, "
                       "цифры и подчёркивания")
    if len(name) > 64:
        return False, "Имя слишком длинное (>64)"
    if value is None:
        value = ""
    if len(value) > 4096:
        return False, "Текст слишком длинный (>4096)"

    # Проверяем что ещё нет
    existing = get_text(name)
    if existing:
        return False, f"Ключ «{name}» уже существует — редактируйте через список"

    try:
        _run(_set_async(name, value))
        _touch_signal()
        return True, "Создано"
    except Exception as e:
        return False, f"Ошибка БД: {e}"
