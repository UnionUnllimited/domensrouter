"""
Чтение тикетов и переписки из БД бота.

Все функции — асинхронные, читают только. Никаких изменений в БД из админки
не делаем (это работа бота).
"""

from __future__ import annotations

import os
from datetime import datetime

import aiosqlite

DB_PATH = os.getenv("DB_PATH", "/app/data/vpn_support.db")


def _ensure_messages_table_exists(db: aiosqlite.Connection) -> bool:
    """
    Возвращает True если таблица messages есть. Если бот ещё не обновлён —
    таблицы нет, в этом случае админка показывает пустой список переписки,
    а не падает с ошибкой.
    """
    # Проверка делается вызывающим — здесь просто заглушка
    return True


async def has_messages_table() -> bool:
    """Проверяет, существует ли таблица messages."""
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            cur = await db.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name='messages'"
            )
            return (await cur.fetchone()) is not None
    except Exception:
        return False


# [v3.5] Кеш чтобы не пытаться создавать индексы на каждый запрос.
# Сбрасывается при рестарте контейнера.
_PERF_INDEXES_ENSURED = False


async def _ensure_perf_indexes() -> None:
    """
    [v3.5] Создаёт индексы критичные для скорости /tickets если их ещё нет.
    Безопасно: CREATE INDEX IF NOT EXISTS, не блокирует БД на чтении.
    Выполняется один раз за время жизни процесса (через флаг в памяти).

    Покрывает:
      - messages(user_id)         — для подзапросов в by_user CTE
      - web_visitors(user_id)     — для JOIN с web_messages в msg_by_user CTE
      - web_messages(visitor_id)  — для подсчёта сообщений гостей
    """
    global _PERF_INDEXES_ENSURED
    if _PERF_INDEXES_ENSURED:
        return
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            # Проверяем что таблица messages существует — без неё индекс создать
            # нельзя. На новых установках таблица создаётся ботом при старте.
            cur = await db.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name='messages'"
            )
            if await cur.fetchone():
                await db.execute(
                    "CREATE INDEX IF NOT EXISTS idx_messages_user "
                    "ON messages(user_id)"
                )

            # web_visitors / web_messages могут отсутствовать на свежих установках
            cur = await db.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name='web_visitors'"
            )
            if await cur.fetchone():
                await db.execute(
                    "CREATE INDEX IF NOT EXISTS idx_web_visitors_user "
                    "ON web_visitors(user_id)"
                )

            cur = await db.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name='web_messages'"
            )
            if await cur.fetchone():
                # idx_web_messages_visitor уже есть в web_chat_db (visitor_id, id)
                # но дополнительно делаем простой по visitor_id для GROUP BY
                await db.execute(
                    "CREATE INDEX IF NOT EXISTS idx_web_messages_visitor_only "
                    "ON web_messages(visitor_id)"
                )

            await db.commit()
        _PERF_INDEXES_ENSURED = True
        try:
            from loguru import logger as _lg
            _lg.info("tickets_view: perf indexes ensured")
        except Exception:
            pass
    except Exception as e:
        try:
            from loguru import logger as _lg
            _lg.warning("tickets_view: ensure_perf_indexes failed: {}", e)
        except Exception:
            pass


async def list_tickets(
    *,
    status: str | None = None,
    search: str | None = None,
    limit: int = 100,
    offset: int = 0,
    source: str | None = None,  # 'tg' | 'web' | None (оба)
) -> dict:
    """
    Возвращает объединённый список ОБРАЩЕНИЙ из двух источников:
      - Telegram-тикеты (таблица tickets) — source = 'tg'
      - Веб-чаты с сайта (таблица web_visitors) — source = 'web'

    Сортируется по времени последней активности — самые свежие сверху,
    независимо от источника.

    Параметры:
      status — 'open' | 'closed' | None (для TG-тикетов; веб-чаты считаются
               открытыми если есть topic_id, закрытыми если нет)
      search — подстрока для поиска по user_id или username/email
      limit, offset — пагинация
      source — отфильтровать только один канал

    Возвращает {tickets: [...], total: int}.
    Каждый элемент имеет поле "source": "tg" | "web".
    """
    # [v3.5] При первом вызове после старта — создаём недостающие индексы.
    # Дешёвая no-op если они уже есть.
    await _ensure_perf_indexes()

    has_messages = await has_messages_table()

    items: list[dict] = []

    # === 1) TG-тикеты ===
    if source != "web":
        where_clauses = []
        params: list = []

        if status in ("open", "closed"):
            where_clauses.append("t.status = ?")
            params.append(status)

        if search:
            s = search.strip().lstrip("@")
            if s.isdigit():
                where_clauses.append("t.user_id = ?")
                params.append(int(s))
            elif s:
                where_clauses.append("u.username LIKE ?")
                params.append(f"%{s}%")

        where_sql = ""
        if where_clauses:
            where_sql = "WHERE " + " AND ".join(where_clauses)

        # [v3.5] ОПТИМИЗАЦИЯ: было N+1 (6 коррелированных подзапросов на каждую
        # строку → 30 000 подзапросов при 5000 тикетов). Стало: ОДИН проход по
        # messages с GROUP BY + LEFT JOIN. Это даёт 10-100x ускорение.
        #
        # Логика 3-уровневого fallback (ticket_id → topic_id → user_id) сохранена,
        # но реализована через 3 параллельных CTE которые потом сливаются через
        # COALESCE. Каждый CTE — один полный проход по таблице с GROUP BY.
        if has_messages:
            msg_aggregates_cte = """
              -- Агрегаты сообщений в 3 разрезах: по ticket_id, topic_id, user_id.
              -- COALESCE на этапе SELECT берёт первый ненулевой источник.
              by_ticket AS (
                SELECT ticket_id, COUNT(*) AS cnt, MAX(created_at) AS last_at
                FROM messages
                WHERE ticket_id IS NOT NULL
                GROUP BY ticket_id
              ),
              by_topic AS (
                SELECT topic_id, COUNT(*) AS cnt, MAX(created_at) AS last_at
                FROM messages
                WHERE topic_id IS NOT NULL
                GROUP BY topic_id
              ),
              by_user AS (
                SELECT user_id, COUNT(*) AS cnt, MAX(created_at) AS last_at
                FROM messages
                WHERE user_id IS NOT NULL
                GROUP BY user_id
              )
            """
            msg_count_sql = """
              COALESCE(
                NULLIF(bt.cnt, 0),
                NULLIF(btop.cnt, 0),
                buser.cnt,
                0
              )
            """
            last_msg_sql = """
              COALESCE(bt.last_at, btop.last_at, buser.last_at)
            """
            join_msg_sql = """
              LEFT JOIN by_ticket  bt    ON bt.ticket_id  = t.id
              LEFT JOIN by_topic   btop  ON btop.topic_id = t.topic_id
              LEFT JOIN by_user    buser ON buser.user_id = t.user_id
            """
        else:
            msg_aggregates_cte = ""
            msg_count_sql = "0"
            last_msg_sql = "NULL"
            join_msg_sql = ""

        if msg_aggregates_cte:
            sql_tg = f"""
                WITH {msg_aggregates_cte}
                SELECT
                    t.id           AS id,
                    t.user_id      AS user_id,
                    t.topic_id     AS topic_id,
                    t.status       AS status,
                    t.created_at   AS created_at,
                    u.username     AS username,
                    {msg_count_sql} AS messages_count,
                    {last_msg_sql}  AS last_message_at
                FROM tickets t
                LEFT JOIN users u ON u.id = t.user_id
                {join_msg_sql}
                {where_sql}
                ORDER BY t.id DESC
            """
        else:
            sql_tg = f"""
                SELECT
                    t.id           AS id,
                    t.user_id      AS user_id,
                    t.topic_id     AS topic_id,
                    t.status       AS status,
                    t.created_at   AS created_at,
                    u.username     AS username,
                    0 AS messages_count,
                    NULL AS last_message_at
                FROM tickets t
                LEFT JOIN users u ON u.id = t.user_id
                {where_sql}
                ORDER BY t.id DESC
            """

        try:
            async with aiosqlite.connect(DB_PATH) as db:
                db.row_factory = aiosqlite.Row
                cur = await db.execute(sql_tg, params)
                rows = await cur.fetchall()
                for r in rows:
                    items.append({
                        "source": "tg",
                        "id": r["id"],
                        "url_id": f"tg-{r['id']}",  # для ссылки
                        "user_id": r["user_id"],
                        "topic_id": r["topic_id"],
                        "status": r["status"],
                        "created_at": r["created_at"],
                        "username": r["username"],
                        "email": None,
                        "messages_count": r["messages_count"] or 0,
                        "last_message_at": r["last_message_at"] or r["created_at"],
                    })
        except Exception:
            pass

    # === 2) Веб-чаты ===
    if source != "tg":
        try:
            async with aiosqlite.connect(DB_PATH) as db:
                db.row_factory = aiosqlite.Row
                # Проверяем что таблица существует
                cur = await db.execute(
                    "SELECT name FROM sqlite_master "
                    "WHERE type='table' AND name='web_visitors'"
                )
                if await cur.fetchone():
                    # [v3.5] АВТОМИГРАЦИЯ: гарантируем что колонка status есть.
                    # Если бот не перезапускали — колонка ещё не создана,
                    # делаем её прямо здесь чтобы админка работала корректно.
                    # Проверяем через SELECT (работает на любой версии SQLite,
                    # в отличие от pragma_table_info как table-valued function).
                    has_status_col = False
                    try:
                        await db.execute("SELECT status FROM web_visitors LIMIT 1")
                        has_status_col = True
                    except Exception:
                        has_status_col = False
                    if not has_status_col:
                        try:
                            await db.execute(
                                "ALTER TABLE web_visitors ADD COLUMN "
                                "status TEXT DEFAULT 'closed'"
                            )
                            await db.commit()
                            # [v3.5] SQLite применяет DEFAULT и к существующим
                            # записям при ADD COLUMN — статус у всех станет
                            # 'closed'. Для тех у кого был оператор — ставим 'open'.
                            await db.execute(
                                "UPDATE web_visitors SET status = 'open' "
                                "WHERE COALESCE(operator_joined, 0) = 1 "
                                "AND topic_id IS NOT NULL"
                            )
                            await db.commit()
                            has_status_col = True
                        except Exception:
                            pass

                    web_where: list[str] = []
                    web_params: list = []

                    # [v3.5] Статус веб-чата теперь хранится в отдельной колонке.
                    # Старая логика (по topic_id) сломана: с ghost-topic logic
                    # topic создаётся СРАЗУ при первом сообщении, что давало
                    # ложный 'open'.
                    if status == "open":
                        if has_status_col:
                            web_where.append("COALESCE(v.status, 'closed') = 'open'")
                        else:
                            web_where.append("v.topic_id IS NOT NULL")
                    elif status == "closed":
                        if has_status_col:
                            web_where.append("COALESCE(v.status, 'closed') = 'closed'")
                        else:
                            web_where.append("v.topic_id IS NULL")

                    if search:
                        s = search.strip().lstrip("@")
                        if s.isdigit():
                            web_where.append("v.user_id = ?")
                            web_params.append(int(s))
                        elif "@" in s:
                            web_where.append("v.user_email LIKE ?")
                            web_params.append(f"%{s}%")
                        elif s:
                            web_where.append(
                                "(v.user_name LIKE ? OR v.user_email LIKE ?)"
                            )
                            web_params.extend([f"%{s}%", f"%{s}%"])

                    web_where_sql = (
                        ("WHERE " + " AND ".join(web_where)) if web_where else ""
                    )

                    # [v3.5] Включаем колонку status в выборку (если есть)
                    status_select = (
                        "COALESCE(v.status, 'closed') AS v_status"
                        if has_status_col
                        else "(CASE WHEN v.topic_id IS NOT NULL THEN 'open' ELSE 'closed' END) AS v_status"
                    )
                    # [v3.5] A+C: фильтр + группировка по user_id (если есть)
                    # - Скрываем посетителей сайта без переписки и без идентификации
                    #   (это просто "открыл сайт и закрыл")
                    # - У одного user_id может быть несколько visitor (разные сессии
                    #   браузера) — оставляем только самую свежую как представителя
                    # - Считаем сообщения по всем visitor_id данного user_id
                    # [v3.5] ОПТИМИЗАЦИЯ: было N+1 с подзапросом JOIN на каждую
                    # строку (10к visitors × подзапрос с JOIN = очень медленно).
                    # Стало: пре-агрегация web_messages один раз через CTE +
                    # JOIN в основном запросе. Прирост 10-100x.
                    #
                    # Идея: для visitors с user_id считаем сумму по user_id
                    # (объединяет все сессии одного клиента), для гостей —
                    # по visitor_id. Делаем 2 CTE и LEFT JOIN их обе.
                    sql_web = f"""
                        WITH
                          -- Кол-во сообщений сгруппированных по user_id
                          -- (все visitor_id одного клиента сложатся вместе)
                          msg_by_user AS (
                            SELECT v2.user_id, COUNT(*) AS cnt
                            FROM web_messages m
                            JOIN web_visitors v2 ON v2.visitor_id = m.visitor_id
                            WHERE v2.user_id IS NOT NULL
                            GROUP BY v2.user_id
                          ),
                          -- Кол-во сообщений по visitor_id (для гостей без user_id)
                          msg_by_visitor AS (
                            SELECT visitor_id, COUNT(*) AS cnt
                            FROM web_messages
                            GROUP BY visitor_id
                          ),
                          grouped AS (
                            SELECT
                              v.visitor_id,
                              v.user_id,
                              v.user_name,
                              v.user_email,
                              v.topic_id,
                              v.created_at,
                              v.last_active_at,
                              {status_select},
                              ROW_NUMBER() OVER (
                                PARTITION BY COALESCE(CAST(v.user_id AS TEXT), v.visitor_id)
                                ORDER BY v.last_active_at DESC
                              ) AS rn,
                              CASE
                                WHEN v.user_id IS NOT NULL THEN COALESCE(mu.cnt, 0)
                                ELSE COALESCE(mv.cnt, 0)
                              END AS messages_count
                            FROM web_visitors v
                            LEFT JOIN msg_by_user    mu ON mu.user_id    = v.user_id
                            LEFT JOIN msg_by_visitor mv ON mv.visitor_id = v.visitor_id
                            {web_where_sql}
                          )
                        SELECT * FROM grouped
                        WHERE rn = 1
                          AND messages_count > 0
                        ORDER BY last_active_at DESC
                    """
                    cur = await db.execute(sql_web, web_params)
                    web_rows = await cur.fetchall()
                    # [v3.5] DEBUG: логируем что реально вернулось из БД
                    try:
                        from loguru import logger as _lg
                        _lg.info(
                            "tickets_view web: has_status_col={}, found={} rows, "
                            "first_status={!r}",
                            has_status_col, len(web_rows),
                            web_rows[0]["v_status"] if web_rows else None,
                        )
                    except Exception:
                        pass
                    for r in web_rows:
                        items.append({
                            "source": "web",
                            "id": r["visitor_id"],
                            "url_id": f"web-{r['visitor_id']}",
                            "user_id": r["user_id"],
                            "topic_id": r["topic_id"],
                            # [v3.5] Статус из колонки status (а не по topic_id)
                            "status": r["v_status"],
                            "created_at": r["created_at"],
                            "username": r["user_name"],
                            "email": r["user_email"],
                            "messages_count": r["messages_count"] or 0,
                            "last_message_at": r["last_active_at"] or r["created_at"],
                        })
        except Exception:
            pass

    # [v3.5] Сортировка ВСЕГДА по последней активности (новые сверху).
    # Используем datetime, парсим строку из БД для точного сравнения.
    from datetime import datetime as _dt

    def _sort_ts(x: dict):
        # Берём максимум из last_message_at и created_at
        candidates = [
            x.get("last_message_at"),
            x.get("last_active_at"),
            x.get("created_at"),
        ]
        best = None
        for c in candidates:
            if not c:
                continue
            try:
                # Поддерживаем "YYYY-MM-DD HH:MM:SS" и ISO с T
                s = str(c).replace("T", " ").split(".")[0]
                ts = _dt.fromisoformat(s)
            except (ValueError, TypeError):
                continue
            if best is None or ts > best:
                best = ts
        # Если совсем ничего нет — id (для TG это число, для web — строка)
        return best or _dt.min

    items.sort(key=_sort_ts, reverse=True)
    total = len(items)
    sliced = items[offset:offset + limit]

    return {"tickets": sliced, "total": total}


async def get_ticket(ticket_id: int) -> dict | None:
    """Возвращает один тикет с полной перепиской."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        cur = await db.execute(
            """
            SELECT t.id, t.user_id, t.topic_id, t.status, t.created_at,
                   u.username
            FROM tickets t
            LEFT JOIN users u ON u.id = t.user_id
            WHERE t.id = ?
            """,
            (ticket_id,),
        )
        ticket = await cur.fetchone()
        if not ticket:
            return None

        ticket_dict = {
            "id": ticket["id"],
            "user_id": ticket["user_id"],
            "topic_id": ticket["topic_id"],
            "status": ticket["status"],
            "created_at": ticket["created_at"],
            "username": ticket["username"],
            "messages": [],
        }

        if not await has_messages_table():
            return ticket_dict

        # Сообщения, привязанные к этому ticket_id напрямую
        cur = await db.execute(
            """
            SELECT id, direction, kind, text,
                   operator_id, operator_name, created_at
            FROM messages
            WHERE ticket_id = ?
            ORDER BY id ASC
            """,
            (ticket_id,),
        )
        rows = await cur.fetchall()

        # Если по ticket_id пусто — пробуем найти по topic_id
        # (на случай если в save_message не передавался ticket_id)
        if not rows and ticket["topic_id"]:
            cur = await db.execute(
                """
                SELECT id, direction, kind, text,
                       operator_id, operator_name, created_at
                FROM messages
                WHERE topic_id = ?
                ORDER BY id ASC
                """,
                (ticket["topic_id"],),
            )
            rows = await cur.fetchall()

        # [v3.5] ПОСЛЕДНИЙ fallback — по user_id. Покрывает случаи:
        #   - архивные тикеты до миграции на модель "1 клиент = 1 тикет"
        #   - тикеты у которых обнулился topic_id (старый удалённый топик)
        #   - сообщения сохранённые с другим ticket_id (например из старой
        #     версии где у клиента было несколько тикетов)
        # Показываем всю историю клиента — для архива это полезнее чем
        # пустой список.
        if not rows and ticket["user_id"]:
            cur = await db.execute(
                """
                SELECT id, direction, kind, text,
                       operator_id, operator_name, created_at
                FROM messages
                WHERE user_id = ?
                ORDER BY id ASC
                """,
                (ticket["user_id"],),
            )
            rows = await cur.fetchall()

        for r in rows:
            ticket_dict["messages"].append({
                "id": r["id"],
                "direction": r["direction"],
                "kind": r["kind"],
                "text": r["text"] or "",
                "operator_name": r["operator_name"],
                "created_at": r["created_at"],
            })

    return ticket_dict