"""
Менеджер массовой рассылки от имени бота.

Workflow:
  1. /news — страница с двумя заготовками + полем редактирования + фото
  2. POST /news/preview — формируется превью + token, показ ПИНа
  3. POST /news/send — применяется ПИН, запускается фоновая рассылка
  4. GET /news/progress/<id> — JSON со статусом отправки

Защиты:
  - ПИН-подтверждение (4 цифры, 90 секунд)
  - Кулдаун: 10 минут между рассылками
  - Rate-limit: 30 сообщений в секунду (Telegram API)
  - Сбор статистики: отправлено, заблокировали бота, ошибки
"""

from __future__ import annotations

import asyncio
import os
import secrets
import time
from datetime import datetime
from pathlib import Path

import aiohttp


DB_PATH = os.getenv("DB_PATH", "/app/data/vpn_support.db")
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
UPLOADS_DIR = Path(os.getenv("BROADCAST_UPLOADS", "/app/data/broadcast"))

# Заготовленные шаблоны (дружеская стилистика)
TEMPLATES = {
    "tech_start": (
        "🔧 <b>Технические работы</b>\n\n"
        "Привет! Мы немного шаманим над сервером — "
        "VPN может работать с перебоями или временно "
        "отключиться.\n\n"
        "⏱ Постараемся закончить как можно быстрее. "
        "Спасибо за понимание!\n\n"
        "Следите за новостями в канале: {NEWS_CHANNEL_URL}"
    ),
    "tech_end": (
        "✅ <b>Технические работы завершены</b>\n\n"
        "Всё снова работает. Спасибо, что подождали!\n\n"
        "Если VPN ведёт себя странно — перезапустите "
        "приложение Happ. Не работает после этого? "
        "Напишите нам через «✉️ Связаться с поддержкой» "
        "в меню бота.\n\n"
        "Хорошего сёрфинга 🌊"
    ),
}


# In-memory state
_pending_broadcasts: dict[str, dict] = {}  # {token: {text, photo_path, pin, expires_at}}
_progress: dict[str, dict] = {}             # {broadcast_id: {sent, failed, blocked, total, started_at}}
_last_broadcast_at: float = 0.0             # для кулдауна

PIN_TTL = 90
BROADCAST_COOLDOWN = 10 * 60  # 10 минут между рассылками
MAX_TEXT_LEN = 4096
MAX_CAPTION_LEN = 1024
MAX_PHOTO_SIZE = 10 * 1024 * 1024  # 10 МБ
RATE_LIMIT_DELAY = 0.035  # ~30 msg/sec


def _apply_env_links(text: str) -> str:
    """Подставляет {NEWS_CHANNEL_URL}, {COMMUNITY_CHAT_URL}, {MAIN_BOT}."""
    links = {
        "MAIN_BOT": (os.getenv("MAIN_BOT_USERNAME") or os.getenv("MAIN_BOT") or "").lstrip("@"),
        "COMMUNITY_CHAT_URL": os.getenv("COMMUNITY_CHAT_URL", "https://t.me/your_vpn_chat"),
        "NEWS_CHANNEL_URL": os.getenv("NEWS_CHANNEL_URL", "https://t.me/your_vpn_news"),
    }
    try:
        return text.format(**links)
    except (KeyError, IndexError, ValueError):
        return text


def get_template(name: str) -> str:
    """Возвращает заготовку, подставив env-переменные."""
    raw = TEMPLATES.get(name, "")
    return _apply_env_links(raw)


def cooldown_left() -> int:
    """Сколько секунд до конца кулдауна. 0 если можно слать."""
    if _last_broadcast_at == 0:
        return 0
    left = int(BROADCAST_COOLDOWN - (time.time() - _last_broadcast_at))
    return max(0, left)


async def count_recipients() -> int:
    """Сколько пользователей в БД получат рассылку (не забаненные)."""
    import aiosqlite
    if not os.path.exists(DB_PATH):
        return 0
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("PRAGMA table_info(users)")
        cols = {r[1] for r in await cur.fetchall()}
        sql = "SELECT COUNT(*) FROM users"
        if "banned" in cols:
            sql += " WHERE banned = 0 OR banned IS NULL"
        cur = await db.execute(sql)
        row = await cur.fetchone()
    return row[0] if row else 0


async def prepare_broadcast(text: str, photo_bytes: bytes | None,
                            photo_filename: str | None) -> tuple[bool, str, str | None]:
    """
    Сохраняет фото на диск, создаёт токен с превью.
    Возвращает (ok, message, token).
    """
    text = text.strip()
    if not text:
        return False, "Текст не может быть пустым", None

    # Длина — зависит от наличия фото
    if photo_bytes:
        if len(text) > MAX_CAPTION_LEN:
            return False, (
                f"С фото текст должен быть до {MAX_CAPTION_LEN} символов "
                f"(сейчас {len(text)}). Без фото лимит {MAX_TEXT_LEN}."
            ), None
    else:
        if len(text) > MAX_TEXT_LEN:
            return False, (
                f"Текст слишком длинный: {len(text)} зн. (макс {MAX_TEXT_LEN})"
            ), None

    photo_path = None
    if photo_bytes:
        if len(photo_bytes) > MAX_PHOTO_SIZE:
            return False, (
                f"Фото слишком большое ({len(photo_bytes)//1024//1024} МБ, "
                f"макс {MAX_PHOTO_SIZE//1024//1024} МБ)"
            ), None
        UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        ext = ".jpg"
        if photo_filename:
            for e in (".jpg", ".jpeg", ".png", ".webp"):
                if photo_filename.lower().endswith(e):
                    ext = e
                    break
        photo_path = UPLOADS_DIR / f"news_{stamp}{ext}"
        photo_path.write_bytes(photo_bytes)

    token = secrets.token_urlsafe(24)
    pin = f"{secrets.randbelow(10000):04d}"
    _pending_broadcasts[token] = {
        "text": text,
        "photo_path": str(photo_path) if photo_path else None,
        "pin": pin,
        "expires_at": time.time() + PIN_TTL,
        "created_at": time.time(),
    }
    return True, "Готово к отправке", token


def get_pending(token: str) -> dict | None:
    """Возвращает данные ожидающей рассылки (без ПИНа)."""
    info = _pending_broadcasts.get(token)
    if not info:
        return None
    if time.time() > info["expires_at"]:
        _drop(token)
        return None
    return {
        "text": info["text"],
        "photo_path": info["photo_path"],
        "pin": info["pin"],
        "expires_in": int(info["expires_at"] - time.time()),
    }


def _drop(token: str, *, keep_file: bool = False) -> None:
    """
    Удаляет токен из pending. По умолчанию также удаляет файл фото.
    Если keep_file=True — файл оставляем (его подхватит _run_broadcast).
    """
    info = _pending_broadcasts.pop(token, None)
    if info and info.get("photo_path") and not keep_file:
        try:
            Path(info["photo_path"]).unlink(missing_ok=True)
        except Exception:
            pass


def cancel(token: str) -> bool:
    if token in _pending_broadcasts:
        _drop(token)
        return True
    return False


async def confirm_and_start(token: str, pin: str) -> tuple[bool, str, str | None]:
    """Проверяет ПИН и стартует рассылку в фоне. Возвращает (ok, message, broadcast_id)."""
    info = _pending_broadcasts.get(token)
    if not info:
        return False, "Рассылка не найдена или истекла", None
    if time.time() > info["expires_at"]:
        _drop(token)
        return False, "Время ПИНа истекло. Создай рассылку заново.", None
    if pin.strip() != info["pin"]:
        return False, "Неверный ПИН", None

    if cooldown_left() > 0:
        return False, (
            f"Слишком частые рассылки. Подожди ещё {cooldown_left()} сек."
        ), None

    # Стартуем
    broadcast_id = secrets.token_urlsafe(12)
    text = info["text"]
    photo_path = info["photo_path"]
    # ВАЖНО: keep_file=True — фото нужно _run_broadcast, удалит само в finally
    _drop(token, keep_file=True)

    global _last_broadcast_at
    _last_broadcast_at = time.time()

    _progress[broadcast_id] = {
        "sent": 0,
        "failed": 0,
        "blocked": 0,
        "total": 0,
        "status": "starting",
        "started_at": time.time(),
        "finished_at": None,
        "error": None,
    }

    # Запускаем в фоне
    asyncio.create_task(_run_broadcast(broadcast_id, text, photo_path))
    return True, "Рассылка запущена", broadcast_id


def get_progress(broadcast_id: str) -> dict | None:
    return _progress.get(broadcast_id)


async def _send_one(session: aiohttp.ClientSession, user_id: int,
                    text: str, photo_path: str | None) -> str:
    """Возвращает 'ok' | 'blocked' | 'failed'."""
    base_url = f"https://api.telegram.org/bot{BOT_TOKEN}"

    try:
        if photo_path:
            with open(photo_path, "rb") as f:
                photo_bytes = f.read()
            data = aiohttp.FormData()
            data.add_field("chat_id", str(user_id))
            data.add_field("caption", text)
            data.add_field("parse_mode", "HTML")
            data.add_field("photo", photo_bytes,
                          filename=os.path.basename(photo_path),
                          content_type="image/jpeg")
            url = f"{base_url}/sendPhoto"
            async with session.post(url, data=data, timeout=aiohttp.ClientTimeout(total=15)) as r:
                body = await r.json()
        else:
            url = f"{base_url}/sendMessage"
            async with session.post(url, json={
                "chat_id": user_id,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": False,
            }, timeout=aiohttp.ClientTimeout(total=15)) as r:
                body = await r.json()
    except (aiohttp.ClientError, asyncio.TimeoutError):
        return "failed"

    if body.get("ok"):
        return "ok"

    # Бот заблокирован пользователем
    desc = (body.get("description") or "").lower()
    if "blocked" in desc or "chat not found" in desc or "user is deactivated" in desc:
        return "blocked"
    return "failed"


async def _run_broadcast(broadcast_id: str, text: str, photo_path: str | None) -> None:
    """Фоновая задача рассылки."""
    import aiosqlite

    progress = _progress[broadcast_id]
    progress["status"] = "running"

    try:
        # Получаем список user_id
        recipients: list[int] = []
        if os.path.exists(DB_PATH):
            async with aiosqlite.connect(DB_PATH) as db:
                cur = await db.execute("PRAGMA table_info(users)")
                cols = {r[1] for r in await cur.fetchall()}
                if "banned" in cols:
                    cur = await db.execute(
                        "SELECT id FROM users WHERE banned = 0 OR banned IS NULL"
                    )
                else:
                    cur = await db.execute("SELECT id FROM users")
                recipients = [r[0] for r in await cur.fetchall()]

        progress["total"] = len(recipients)

        if not recipients:
            progress["status"] = "done"
            progress["finished_at"] = time.time()
            return

        async with aiohttp.ClientSession() as session:
            for uid in recipients:
                result = await _send_one(session, uid, text, photo_path)
                if result == "ok":
                    progress["sent"] += 1
                elif result == "blocked":
                    progress["blocked"] += 1
                else:
                    progress["failed"] += 1
                # Rate-limit
                await asyncio.sleep(RATE_LIMIT_DELAY)

        progress["status"] = "done"
        progress["finished_at"] = time.time()
    except Exception as e:
        progress["status"] = "error"
        progress["error"] = str(e)
        progress["finished_at"] = time.time()
    finally:
        # Удаляем фото — оно больше не нужно
        if photo_path:
            try:
                Path(photo_path).unlink(missing_ok=True)
            except Exception:
                pass
