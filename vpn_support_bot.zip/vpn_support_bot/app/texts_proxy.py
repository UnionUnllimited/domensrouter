"""
Прокси-объект для текстов. Drop-in замена для `from app import texts as T`.

Когда бот делает T.WELCOME — прокси сначала смотрит в кеш content_cache,
а если там нет ключа — фолбэк на оригинальный модуль app.texts
(значение по умолчанию из кода).

Также поддерживает подстановку env-плейсхолдеров {MAIN_BOT}, {COMMUNITY_CHAT_URL},
{NEWS_CHANNEL_URL} в тексты из БД — пользователь может оставить эти плейсхолдеры
в своих правках, и они будут раскрываться так же как в дефолтах из texts.py.
"""

from __future__ import annotations

import os
from typing import Any

from app import texts as _default_texts
from app import content_cache


_LINK_KEYS = {
    "BRAND_NAME": os.getenv("BRAND_NAME", "VPN").strip(),
    "MAIN_BOT": (os.getenv("MAIN_BOT_USERNAME", "your_vpn_bot").lstrip("@").strip()),
    "COMMUNITY_CHAT_URL": os.getenv(
        "COMMUNITY_CHAT_URL", "https://t.me/your_vpn_chat",
    ).strip(),
    "NEWS_CHANNEL_URL": os.getenv(
        "NEWS_CHANNEL_URL", "https://t.me/your_vpn_news",
    ).strip(),
}


def _apply_links(s: str) -> str:
    """Подставляет {BRAND_NAME}, {MAIN_BOT}, {COMMUNITY_CHAT_URL}, {NEWS_CHANNEL_URL}."""
    if not s or "{" not in s:
        return s
    try:
        return s.format(**_LINK_KEYS)
    except (KeyError, IndexError, ValueError):
        return s


class _TextsProxy:
    """Объект-прокси для T.WELCOME, T.PAY_MENU и т.п."""

    def __getattr__(self, name: str) -> Any:
        # 1) Пробуем взять из кеша БД
        cached = content_cache.get_text(name, default=None) if hasattr(
            content_cache, "get_text"
        ) else None
        if cached is None:
            # get_text возвращает default — пробуем явно
            cached = content_cache._texts.get(name) if hasattr(content_cache, "_texts") else None

        if cached is not None:
            return _apply_links(cached)

        # 2) Фолбэк на оригинальный модуль app.texts
        if hasattr(_default_texts, name):
            return getattr(_default_texts, name)

        raise AttributeError(f"Текст {name!r} не найден ни в БД, ни в texts.py")


# Singleton — заменяет `from app import texts as T`
T = _TextsProxy()
