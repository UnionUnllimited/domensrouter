"""
Кеш редактируемого контента в памяти.

Бот использует тексты, кнопки и авто-ответы СИНХРОННО — мы не можем
await на каждый T.WELCOME. Поэтому при старте бота вычитываем всё из БД
в память. Когда админка меняет что-то в БД — она ещё дёргает reload() через
файл-сигнал в data/, и бот перечитывает кеш.

Файл-сигнал: data/content_reload.signal — пустой файл с mtime последнего
изменения. Бот раз в N секунд проверяет mtime и при изменении перечитывает.
"""

from __future__ import annotations

import asyncio
import os
import threading
import time
from pathlib import Path
from typing import Any

from loguru import logger

from app import content_db


# ============================================================
#  СИГНАЛЬНЫЙ ФАЙЛ для синхронизации админка ↔ бот
# ============================================================

_SIGNAL_FILE = Path(content_db.DB_PATH).parent / "content_reload.signal"


def touch_signal() -> None:
    """Сообщает боту что нужно перечитать кеш. Вызывает админка."""
    try:
        _SIGNAL_FILE.parent.mkdir(parents=True, exist_ok=True)
        _SIGNAL_FILE.touch(exist_ok=True)
        # Обновляем mtime
        os.utime(_SIGNAL_FILE, None)
    except Exception as e:
        logger.warning("touch_signal failed: {}", e)


def _signal_mtime() -> float:
    try:
        return _SIGNAL_FILE.stat().st_mtime
    except FileNotFoundError:
        return 0.0


# ============================================================
#  КЕШ
# ============================================================

_lock = threading.RLock()

_texts: dict[str, str] = {}
_menus: dict[str, list[dict]] = {}
_qa_list: list[dict] = []
_qa_map: dict[str, dict] = {}
# [v3.5] Скрытые кнопки виртуальных меню: {menu_name: {button_value, ...}}
_virtual_hidden: dict[str, set[str]] = {}
_last_signal_mtime: float = 0.0


async def reload_cache() -> None:
    """Полностью перечитывает кеш из БД."""
    global _last_signal_mtime
    texts = await content_db.get_all_texts()
    menus_list = await content_db.list_menus()
    menus = {name: await content_db.get_menu_buttons(name) for name in menus_list}
    qa = await content_db.list_qa()

    # [v3.5] Виртуальные скрытые кнопки — для mykey_menu и т.п.
    virt_hidden: dict[str, set[str]] = {}
    try:
        for vmenu in ("mykey_menu",):  # список виртуальных меню
            virt_hidden[vmenu] = await content_db.get_virtual_hidden_set(vmenu)
    except Exception as e:
        logger.warning("reload_cache: virtual_hidden failed: {}", e)

    with _lock:
        _texts.clear()
        _texts.update(texts)
        _menus.clear()
        _menus.update(menus)
        _qa_list.clear()
        _qa_list.extend(qa)
        _qa_map.clear()
        for q in qa:
            _qa_map[q["key"]] = q
        _virtual_hidden.clear()
        _virtual_hidden.update(virt_hidden)
        _last_signal_mtime = _signal_mtime()


async def init_cache_with_migration() -> None:
    """
    Вызывается ОДИН РАЗ при старте бота:
    1) создаёт таблицы content_db
    2) мигрирует дефолты из texts.py/keyboards.py
    3) загружает кеш
    """
    await content_db.init_content_db()
    stats = await content_db.migrate_from_files()
    logger.info(
        "Контент-БД готова: добавлено {} текстов, {} меню, {} авто-ответов",
        stats["texts_added"], stats["buttons_added_menus"], stats["qa_added"],
    )
    await reload_cache()


# ============================================================
#  WATCHER — слушает сигнальный файл
# ============================================================

async def _watcher(interval: float = 2.0) -> None:
    """Фоновая задача: проверяет сигнальный файл и перечитывает кеш."""
    while True:
        await asyncio.sleep(interval)
        try:
            mtime = _signal_mtime()
            if mtime > _last_signal_mtime and mtime > 0:
                logger.info("Сигнал контента обновился, перечитываю кеш")
                await reload_cache()
        except Exception as e:
            logger.warning("content watcher error: {}", e)


def start_watcher(loop: asyncio.AbstractEventLoop | None = None) -> None:
    """Запускает watcher как фоновую корутину."""
    if loop is None:
        loop = asyncio.get_event_loop()
    loop.create_task(_watcher())


# ============================================================
#  СИНХРОННЫЕ АКСЕССОРЫ ДЛЯ БОТА
# ============================================================

def get_text(key: str, default: str = "") -> str:
    """Синхронное чтение текста из кеша."""
    with _lock:
        return _texts.get(key, default)


def get_menu(name: str) -> list[dict]:
    """Синхронное чтение кнопок меню из кеша."""
    with _lock:
        return list(_menus.get(name, []))


def get_qa_list() -> list[dict]:
    with _lock:
        return list(_qa_list)


def get_qa_by_key(key: str) -> dict | None:
    with _lock:
        return _qa_map.get(key)


def get_qa_text(key: str) -> str | None:
    """Возвращает текст авто-ответа по ключу (для обработчика в боте)."""
    q = get_qa_by_key(key)
    return q["text"] if q else None


# [v3.5] Синхронный доступ к скрытию виртуальных кнопок (mykey_menu).
def is_virtual_button_hidden_cached(menu_name: str, button_value: str) -> bool:
    """Скрыта ли кнопка виртуального меню (синхронно из кеша)."""
    with _lock:
        hidden = _virtual_hidden.get(menu_name, set())
        return button_value in hidden
