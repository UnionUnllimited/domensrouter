"""
[v3.5] Безопасность и лимиты бота YaponchikVPN.

Содержит:
- Защита от prompt injection (фильтр сообщений клиента перед передачей AI)
- Rate limiting (защита от спама в виджете и в TG)
- Настройки SLA для тикетов (пороги «жёлтый/красный»)

Все настройки хранятся в таблице security_settings (key-value, TEXT).
Значения парсятся как int с дефолтами. Изменения применяются мгновенно
без перезапуска (читаются при каждом запросе с лёгким кешем).
"""
import os
import re
import time
from collections import defaultdict, deque
from typing import Optional

import aiosqlite
from loguru import logger

DB_PATH = os.getenv("DB_PATH", "vpn_bot.db")


# ============================================================
#  ДЕФОЛТЫ
# ============================================================

DEFAULTS = {
    # Защита от prompt injection
    "injection_protection_enabled": "1",  # 0/1

    # Rate limiting (per visitor/user)
    "rl_messages_per_minute": "20",   # сообщений за 60 сек
    "rl_messages_per_hour": "100",    # сообщений за час
    "rl_uploads_per_minute": "5",     # фото за 60 сек

    # SLA для тикетов (минуты)
    "sla_yellow_minutes": "5",        # больше → жёлтый
    "sla_red_minutes": "30",          # больше → красный
}


# ============================================================
#  ИНИЦИАЛИЗАЦИЯ БД
# ============================================================

async def init_db() -> None:
    """Создаёт таблицу security_settings если её нет."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS security_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # Заполняем дефолты для отсутствующих ключей
        for k, v in DEFAULTS.items():
            await db.execute(
                "INSERT OR IGNORE INTO security_settings(key, value) VALUES (?, ?)",
                (k, v),
            )
        await db.commit()


# ============================================================
#  ЧТЕНИЕ/ЗАПИСЬ НАСТРОЕК
# ============================================================

_settings_cache: dict[str, str] = {}
_settings_cache_ts: float = 0.0
_CACHE_TTL = 5.0  # секунд


async def _load_settings() -> dict[str, str]:
    """Подгружает настройки из БД (с TTL-кешем)."""
    global _settings_cache, _settings_cache_ts
    now = time.time()
    if _settings_cache and (now - _settings_cache_ts) < _CACHE_TTL:
        return _settings_cache
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            cur = await db.execute("SELECT key, value FROM security_settings")
            rows = await cur.fetchall()
        _settings_cache = {k: v for k, v in rows}
        _settings_cache_ts = now
    except Exception as e:
        logger.warning("security: load settings failed: {}", e)
        _settings_cache = dict(DEFAULTS)
    return _settings_cache


async def get_setting(key: str, default: Optional[str] = None) -> str:
    """Получить значение настройки (с fallback на DEFAULTS)."""
    s = await _load_settings()
    return s.get(key, default if default is not None else DEFAULTS.get(key, ""))


async def get_int(key: str) -> int:
    """Получить настройку как int."""
    try:
        return int(await get_setting(key))
    except (ValueError, TypeError):
        return int(DEFAULTS.get(key, "0"))


async def get_bool(key: str) -> bool:
    """Получить настройку как bool (0/1)."""
    v = await get_setting(key)
    return v not in ("0", "", "false", "False", "no", "off")


async def set_setting(key: str, value: str) -> None:
    """Сохранить настройку."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO security_settings(key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, "
            "updated_at=CURRENT_TIMESTAMP",
            (key, str(value)),
        )
        await db.commit()
    # Сбрасываем кеш
    global _settings_cache_ts
    _settings_cache_ts = 0.0


async def get_all_settings() -> dict[str, str]:
    """Все настройки для админки (с заполнением дефолтов)."""
    s = await _load_settings()
    # Объединяем с дефолтами на случай если каких-то ключей нет
    result = dict(DEFAULTS)
    result.update(s)
    return result


# ============================================================
#  ЗАЩИТА ОТ PROMPT INJECTION
# ============================================================

# Паттерны типичных prompt-injection попыток.
# Список консервативный — ловим явные техники, не блокируем нормальные вопросы.
_INJECTION_PATTERNS = [
    # Английские классические
    r"\bignore\s+(all\s+)?(previous|prior|above|preceding)\s+instructions?\b",
    r"\bdisregard\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?)\b",
    r"\bforget\s+(all\s+|everything\s+|your\s+)?(previous|prior|instructions?|prompts?|rules?)\b",
    r"\byou\s+are\s+now\s+\w+",
    r"\bact\s+as\s+(an?\s+)?(developer|admin|root|jailbreak|DAN|unrestricted)\b",
    r"\b(DAN|jailbreak|developer\s+mode)\b",
    r"\bsystem\s+prompt\b",
    r"\bnew\s+instructions?:",
    r"###\s*new\s+instructions?",
    r"\[INST\]|\[/INST\]",
    r"<\|im_start\|>|<\|im_end\|>",
    r"<\|system\|>|<\|assistant\|>|<\|user\|>",
    # Русские
    r"\bигнорируй\s+(все\s+)?(предыдущие|прежние|вышестоящие|выше)\s+(инструкции|указания|команды)\b",
    r"\bпроигнорируй\s+(все\s+)?(предыдущие|прежние|инструкции|правила)\b",
    r"\bзабудь\s+(все\s+|всё\s+|свои\s+)?(предыдущие|прежние|правила|инструкции)\b",
    r"\bты\s+теперь\s+\w+",
    r"\bпредставь\s+(что\s+)?ты\b",
    r"\bвыдай\s+(мне\s+)?(промокод|секретн|пароль|api[\s\-_]?key|админ)",
    r"\bдай\s+(мне\s+)?(\d+\s+)?(промокод|промокодов|бесплатн|год|месяц)\b",
    r"\bсделай\s+(меня\s+)?(админ|оператор)",
    # Раскрытие системного промпта
    r"\b(show|reveal|print|display|repeat)\s+(your\s+|the\s+)?(system\s+)?(prompt|instructions|rules)\b",
    r"\b(покажи|раскрой|напечатай|повтори)\s+(свой\s+|твой\s+|системный)\s*(промпт|инструкции|правила)\b",
    # Просьбы вывести длинные блоки или вставить «специальные» команды
    r"\brole\s*:\s*(system|admin|developer)\b",
]

_INJECTION_RE = re.compile(
    "|".join(_INJECTION_PATTERNS), re.IGNORECASE | re.UNICODE
)


def detect_injection(text: str) -> Optional[str]:
    """
    Возвращает совпавший паттерн если найдена попытка инъекции, иначе None.
    """
    if not text:
        return None
    m = _INJECTION_RE.search(text)
    return m.group(0) if m else None


async def sanitize_user_input(text: str) -> tuple[str, Optional[str]]:
    """
    Очищает ввод клиента от потенциальных prompt-injection команд.

    Возвращает:
        (cleaned_text, reason)
        - cleaned_text — текст после очистки (можно передать в AI)
        - reason — None если всё ок, иначе строка-причина что было найдено

    Если защита выключена в админке — возвращаем текст без изменений.
    """
    if not text:
        return text, None
    if not await get_bool("injection_protection_enabled"):
        return text, None

    found = detect_injection(text)
    if not found:
        return text, None

    # Логируем, но не блокируем — заменяем подозрительные паттерны
    logger.warning(
        "security: prompt-injection попытка обнаружена: {!r}", found,
    )
    # Заменяем найденные паттерны на безопасный плейсхолдер
    cleaned = _INJECTION_RE.sub("[удалено: попытка изменить инструкции]", text)
    return cleaned, f"найден паттерн: {found!r}"


# ============================================================
#  RATE LIMITING
# ============================================================

# In-memory хранилище временных меток последних запросов.
# Ключ — visitor_id (для веба) или str(tg_user_id) (для TG).
# Значение — deque от старых к новым timestamp'ам.
_msg_timestamps: dict[str, deque[float]] = defaultdict(deque)
_upload_timestamps: dict[str, deque[float]] = defaultdict(deque)


def _trim_old(timestamps: deque[float], window_seconds: float) -> None:
    """Удаляет timestamp'ы старше окна."""
    now = time.time()
    cutoff = now - window_seconds
    while timestamps and timestamps[0] < cutoff:
        timestamps.popleft()


async def check_message_rate(user_key: str) -> tuple[bool, Optional[str]]:
    """
    Проверяет можно ли пользователю отправить новое сообщение.

    Возвращает:
        (allowed, reason)
        - allowed=True — разрешено, можно фиксировать timestamp
        - allowed=False — превышен лимит, reason описывает какой

    Лимиты берутся из БД (rl_messages_per_minute, rl_messages_per_hour).
    """
    if not user_key:
        return True, None

    limit_min = await get_int("rl_messages_per_minute")
    limit_hour = await get_int("rl_messages_per_hour")

    ts = _msg_timestamps[user_key]
    _trim_old(ts, 3600.0)  # храним в памяти час

    # Считаем сколько за минуту
    now = time.time()
    count_min = sum(1 for t in ts if t >= now - 60.0)
    if limit_min > 0 and count_min >= limit_min:
        return False, f"слишком много сообщений ({count_min}/{limit_min} в минуту)"
    if limit_hour > 0 and len(ts) >= limit_hour:
        return False, f"слишком много сообщений ({len(ts)}/{limit_hour} в час)"

    return True, None


async def record_message(user_key: str) -> None:
    """Фиксирует timestamp отправки сообщения для rate limit'а."""
    if user_key:
        _msg_timestamps[user_key].append(time.time())


async def check_upload_rate(user_key: str) -> tuple[bool, Optional[str]]:
    """То же что check_message_rate, но для загрузки фото."""
    if not user_key:
        return True, None

    limit = await get_int("rl_uploads_per_minute")
    ts = _upload_timestamps[user_key]
    _trim_old(ts, 60.0)

    if limit > 0 and len(ts) >= limit:
        return False, f"слишком много фото ({len(ts)}/{limit} в минуту)"
    return True, None


async def record_upload(user_key: str) -> None:
    """Фиксирует timestamp загрузки фото."""
    if user_key:
        _upload_timestamps[user_key].append(time.time())


# ============================================================
#  SLA для тикетов
# ============================================================

async def get_sla_thresholds() -> tuple[int, int]:
    """
    Возвращает (yellow_minutes, red_minutes) для тикетов.
    Используется для подсветки списка тикетов в админке.
    """
    yellow = await get_int("sla_yellow_minutes")
    red = await get_int("sla_red_minutes")
    return yellow, red


def sla_status(age_minutes: float, yellow: int, red: int) -> str:
    """
    Определяет статус тикета по возрасту:
        'green' — < yellow минут
        'yellow' — yellow ≤ age < red
        'red' — ≥ red минут
    """
    if age_minutes >= red:
        return "red"
    if age_minutes >= yellow:
        return "yellow"
    return "green"
