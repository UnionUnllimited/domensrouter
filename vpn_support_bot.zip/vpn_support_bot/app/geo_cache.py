"""
Геолокация по IP с кешем в БД (чтобы не дёргать внешний API повторно).

Использует бесплатный ip-api.com — лимит 45 req/min с одного IP.
Кеш в таблице ip_geo_cache: ip → city, country, resolved_at.

Если внешний API недоступен — возвращает {"city": "—", "country": "—"}.
"""

from __future__ import annotations

import asyncio
import aiohttp
import aiosqlite
from loguru import logger

DB_PATH = "/app/data/vpn_support.db"

# Лимиты: если за минуту мы упёрлись в rate-limit, не дёргаем повторно
_resolve_lock = asyncio.Lock()
_recent_failures = 0
_failure_reset_at = 0.0


async def init_geo_cache_table() -> None:
    """Создаёт таблицу если её нет."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS ip_geo_cache (
                ip TEXT PRIMARY KEY,
                city TEXT,
                country TEXT,
                country_code TEXT,
                resolved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.commit()


async def get_geo_cached(ip: str) -> dict | None:
    """Возвращает {city, country, country_code} из кеша или None."""
    if not ip:
        return None
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT city, country, country_code FROM ip_geo_cache WHERE ip = ?",
            (ip,),
        )
        row = await cur.fetchone()
        if row:
            return {
                "city": row["city"] or "—",
                "country": row["country"] or "—",
                "country_code": row["country_code"] or "",
            }
    return None


async def save_geo(ip: str, city: str, country: str, cc: str) -> None:
    """Сохраняет результат в кеш."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT OR REPLACE INTO ip_geo_cache
               (ip, city, country, country_code, resolved_at)
               VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)""",
            (ip, city, country, cc),
        )
        await db.commit()


async def resolve_ip(ip: str, *, timeout: float = 3.0) -> dict:
    """
    Возвращает {city, country, country_code} для IP.
    Сначала проверяет кеш, потом дёргает ip-api.com.
    Никогда не падает — всегда возвращает dict (может с прочерками).
    """
    if not ip or ip in ("127.0.0.1", "::1", "localhost"):
        return {"city": "—", "country": "—", "country_code": ""}

    # Убираем порт если есть
    ip = ip.split(":")[0].strip()

    # Пропускаем приватные диапазоны
    if (
        ip.startswith("10.")
        or ip.startswith("192.168.")
        or ip.startswith("172.16.")
        or ip.startswith("172.17.")
        or ip.startswith("172.18.")
        or ip.startswith("172.19.")
        or ip.startswith("172.2")
        or ip.startswith("172.3")
    ):
        return {"city": "локальный", "country": "—", "country_code": ""}

    # Сначала кеш
    cached = await get_geo_cached(ip)
    if cached:
        return cached

    # API вызов
    try:
        url = (
            f"http://ip-api.com/json/{ip}"
            "?fields=status,country,countryCode,city,query"
        )
        timeout_obj = aiohttp.ClientTimeout(total=timeout)
        async with aiohttp.ClientSession(timeout=timeout_obj) as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    logger.warning("geo_cache: ip-api вернул {}", resp.status)
                    return {"city": "—", "country": "—", "country_code": ""}
                data = await resp.json()

        if data.get("status") != "success":
            # rate-limit или невалидный IP
            logger.debug("geo_cache: ip-api ответ {} для {}",
                         data.get("message"), ip)
            # Кешируем неудачу чтобы не дёргать повторно
            await save_geo(ip, "—", "—", "")
            return {"city": "—", "country": "—", "country_code": ""}

        result = {
            "city": data.get("city") or "—",
            "country": data.get("country") or "—",
            "country_code": data.get("countryCode") or "",
        }
        await save_geo(ip, result["city"], result["country"],
                       result["country_code"])
        return result
    except asyncio.TimeoutError:
        logger.debug("geo_cache: timeout для {}", ip)
        return {"city": "—", "country": "—", "country_code": ""}
    except Exception as e:
        logger.warning("geo_cache: ошибка {} для {}", e, ip)
        return {"city": "—", "country": "—", "country_code": ""}


async def resolve_many(ips: list[str]) -> dict[str, dict]:
    """
    Резолвит много IP параллельно (но не больше 10 одновременно
    чтобы не упереться в rate-limit). Возвращает {ip: {city, country}}.
    """
    if not ips:
        return {}

    unique_ips = list({ip for ip in ips if ip})
    result: dict[str, dict] = {}

    # Чтобы не упереться в rate-limit, обрабатываем партиями по 10
    batch_size = 10
    for i in range(0, len(unique_ips), batch_size):
        batch = unique_ips[i:i + batch_size]
        tasks = [resolve_ip(ip) for ip in batch]
        batch_results = await asyncio.gather(*tasks, return_exceptions=True)
        for ip, res in zip(batch, batch_results):
            if isinstance(res, Exception):
                result[ip] = {"city": "—", "country": "—", "country_code": ""}
            else:
                result[ip] = res
        # Между батчами небольшая пауза чтобы не флудить API
        if i + batch_size < len(unique_ips):
            await asyncio.sleep(0.5)

    return result
