"""
Хранилище веб-чата.

Таблицы:
  web_visitors  — каждый гость с сайта (visitor_id, опционально user_id и др.)
  web_messages  — сообщения в обоих направлениях

Каждый visitor получает свой топик в группе поддержки (с тегом #web)
для удобства оператора — отличаются от Telegram-тикетов.
"""

from __future__ import annotations

import secrets
from datetime import datetime, timedelta

import aiosqlite

from app.database import DB_PATH


_SCHEMA_TABLES = """
CREATE TABLE IF NOT EXISTS web_visitors (
    visitor_id TEXT PRIMARY KEY,
    user_id INTEGER,                   -- если сайт идентифицировал пользователя
    user_name TEXT,                    -- имя клиента (опционально)
    user_email TEXT,                   -- email (опционально)
    user_agent TEXT,                   -- браузер
    referer TEXT,                      -- откуда пришёл
    ip_address TEXT,                   -- IP с которого подключился (для географии)
    topic_id INTEGER,                  -- топик в Telegram-группе
    last_topic_id INTEGER,             -- предыдущий topic_id если чат был закрыт (для переоткрытия)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    operator_joined INTEGER DEFAULT 0, -- AI: оператор уже вмешался → AI молчит
    status TEXT DEFAULT 'closed'       -- [v3.5] open/closed; 'open' = есть эскалация
);

CREATE TABLE IF NOT EXISTS web_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    visitor_id TEXT NOT NULL,
    direction TEXT NOT NULL,           -- 'in' = от клиента, 'out' = от оператора
    sender TEXT,                       -- имя оператора (для 'out')
    text TEXT,
    attachment_url TEXT,               -- путь к файлу (фото) если есть
    attachment_kind TEXT,              -- 'photo' | null
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    delivered INTEGER DEFAULT 0,       -- доставлено ли клиенту (только для 'out')
    notified_offline INTEGER DEFAULT 0,-- уведомили ли оператора что клиент не увидел
    FOREIGN KEY (visitor_id) REFERENCES web_visitors(visitor_id)
);
"""

# Индексы создаются ОТДЕЛЬНО — после миграций колонок, чтобы partial-index
# не падал на отсутствующих в старых БД полях.
_SCHEMA_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_web_messages_visitor ON web_messages(visitor_id, id);
CREATE INDEX IF NOT EXISTS idx_web_visitors_topic ON web_visitors(topic_id);
CREATE INDEX IF NOT EXISTS idx_web_visitors_active ON web_visitors(last_active_at DESC);
-- Для inactivity_watcher: ищем delivered=0 + notified=0 + старые out-сообщения.
-- Без этого индекса при каждом тике (раз в минуту) идёт полный seq scan
-- по всей web_messages — это лочит запись новых сообщений из виджета.
CREATE INDEX IF NOT EXISTS idx_web_messages_undelivered
    ON web_messages(direction, delivered, notified_offline, created_at)
    WHERE direction = 'out' AND delivered = 0;
"""


async def init_web_chat_db() -> None:
    """Создаёт таблицы. Безопасно вызывать многократно."""
    async with aiosqlite.connect(DB_PATH) as db:
        # WAL-режим: чтение не блокирует запись. Критично — иначе фоновый
        # inactivity_watcher лочит БД и виджет тормозит при /session,
        # /identify и /poll.
        try:
            await db.execute("PRAGMA journal_mode=WAL")
            await db.execute("PRAGMA synchronous=NORMAL")
            await db.execute("PRAGMA busy_timeout=3000")
        except Exception:
            pass

        # 1. Сначала только CREATE TABLE — без индексов и без колонок,
        #    которые могут отсутствовать в старых БД.
        await db.executescript(_SCHEMA_TABLES)

        # 2. Миграция: добавляем колонки если их ещё нет (для существующих БД)
        for col, ddl in [
            # web_messages — старые колонки
            ("created_at_m",
             "ALTER TABLE web_messages ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
            ("attachment_url", "ALTER TABLE web_messages ADD COLUMN attachment_url TEXT"),
            ("attachment_kind", "ALTER TABLE web_messages ADD COLUMN attachment_kind TEXT"),
            ("sender_m", "ALTER TABLE web_messages ADD COLUMN sender TEXT"),
            ("delivered_m",
             "ALTER TABLE web_messages ADD COLUMN delivered INTEGER DEFAULT 0"),
            ("notified_offline",
             "ALTER TABLE web_messages ADD COLUMN notified_offline INTEGER DEFAULT 0"),
            # web_visitors — старые колонки
            ("user_id_v", "ALTER TABLE web_visitors ADD COLUMN user_id INTEGER"),
            ("user_name_v", "ALTER TABLE web_visitors ADD COLUMN user_name TEXT"),
            ("user_email_v", "ALTER TABLE web_visitors ADD COLUMN user_email TEXT"),
            ("user_agent_v", "ALTER TABLE web_visitors ADD COLUMN user_agent TEXT"),
            ("referer_v", "ALTER TABLE web_visitors ADD COLUMN referer TEXT"),
            ("ip_address", "ALTER TABLE web_visitors ADD COLUMN ip_address TEXT"),
            ("topic_id_v", "ALTER TABLE web_visitors ADD COLUMN topic_id INTEGER"),
            ("last_topic_id",
             "ALTER TABLE web_visitors ADD COLUMN last_topic_id INTEGER"),
            ("created_at_v",
             "ALTER TABLE web_visitors ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
            ("last_active_at",
             "ALTER TABLE web_visitors ADD COLUMN last_active_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
            # AI: пометка что оператор хоть раз ответил визитёру.
            # Если operator_joined=1 → AI больше не отвечает в этом чате.
            ("operator_joined_v",
             "ALTER TABLE web_visitors ADD COLUMN operator_joined INTEGER DEFAULT 0"),
            # [v3.5] Статус тикета веб-чата: closed (AI работает) / open (эскалация).
            # При первом сообщении создаётся со status='closed'. При эскалации
            # AI меняется на 'open'. При закрытии оператором → 'closed'.
            ("status_v",
             "ALTER TABLE web_visitors ADD COLUMN status TEXT DEFAULT 'closed'"),
        ]:
            try:
                await db.execute(ddl)
            except Exception:
                pass  # колонка уже есть
        await db.commit()

        # 3. Теперь когда все колонки точно есть — создаём индексы
        try:
            await db.executescript(_SCHEMA_INDEXES)
        except Exception as e:
            # Не критично — индексы это про производительность
            import sys
            print(f"[warn] не удалось создать индексы: {e}", file=sys.stderr)

        # Запечатываем «стариков»: всё что старше 1 часа и ещё не уведомлено —
        # помечаем как «уже уведомили». Это идемпотентно — при повторных
        # запусках ничего не происходит (нет новых старых сообщений).
        # Спасает от спама уведомлений по исторической переписке.
        await db.execute(
            """
            UPDATE web_messages
            SET notified_offline = 1
            WHERE direction = 'out'
              AND delivered = 0
              AND COALESCE(notified_offline, 0) = 0
              AND datetime(created_at) < datetime('now', '-1 hours')
            """,
        )
        await db.commit()


# ============================================================
#  ВИЗИТЁРЫ
# ============================================================

def new_visitor_id() -> str:
    """Генерирует свежий visitor_id (24 символа URL-safe)."""
    return secrets.token_urlsafe(18)


async def create_visitor(visitor_id: str,
                         user_agent: str | None = None,
                         referer: str | None = None) -> None:
    """Создаёт нового анонимного гостя.
    [v3.5] Явно ставим status='closed' чтобы не зависеть от DEFAULT.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        # Сначала пробуем с колонкой status (если миграция применилась)
        try:
            await db.execute(
                """
                INSERT OR IGNORE INTO web_visitors
                  (visitor_id, user_agent, referer, last_active_at, status)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP, 'closed')
                """,
                (visitor_id, user_agent, referer),
            )
        except Exception:
            # Колонки status ещё нет — старая схема
            await db.execute(
                """
                INSERT OR IGNORE INTO web_visitors
                  (visitor_id, user_agent, referer, last_active_at)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                """,
                (visitor_id, user_agent, referer),
            )
        await db.commit()


async def visitor_exists(visitor_id: str) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT 1 FROM web_visitors WHERE visitor_id = ? LIMIT 1",
            (visitor_id,),
        )
        return (await cur.fetchone()) is not None


async def get_visitor(visitor_id: str) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM web_visitors WHERE visitor_id = ?", (visitor_id,),
        )
        row = await cur.fetchone()
    return dict(row) if row else None


async def set_visitor_topic(visitor_id: str, topic_id: int) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE web_visitors SET topic_id = ? WHERE visitor_id = ?",
            (topic_id, visitor_id),
        )
        await db.commit()


async def set_visitor_ip(visitor_id: str, ip: str) -> None:
    """Записывает IP-адрес визитёра (для географии)."""
    if not ip:
        return
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE web_visitors SET ip_address = ? WHERE visitor_id = ?",
            (ip, visitor_id),
        )
        await db.commit()


async def mark_operator_joined(visitor_id: str) -> None:
    """
    Помечает что оператор хоть раз ответил визитёру.
    После этого AI больше не отвечает в этом чате (даже если включён).

    [v3.5] Также переводит status в 'open' — оператор активен.
    Раньше статус оставался 'closed' (AI-режим) → в админке/TG это
    выглядело несоответствующе: AI молчит, но тикет «архив».
    """
    async with aiosqlite.connect(DB_PATH) as db:
        # Пытаемся обновить обе колонки одновременно (если status есть)
        try:
            await db.execute(
                "UPDATE web_visitors SET operator_joined = 1, status = 'open' "
                "WHERE visitor_id = ?",
                (visitor_id,),
            )
        except Exception:
            # Старая схема без колонки status
            await db.execute(
                "UPDATE web_visitors SET operator_joined = 1 "
                "WHERE visitor_id = ?",
                (visitor_id,),
            )
        await db.commit()


async def is_operator_joined(visitor_id: str) -> bool:
    """Подключался ли оператор хоть раз к этому чату?"""
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT operator_joined FROM web_visitors WHERE visitor_id = ?",
            (visitor_id,),
        )
        row = await cur.fetchone()
        return bool(row[0]) if row else False


async def did_ai_respond_to_visitor(visitor_id: str, ai_sender_name: str) -> bool:
    """[v3.5] Был ли хотя бы один ответ AI этому визитёру.

    Используется чтобы показывать уведомление «AI больше не отвечает»
    ТОЛЬКО когда AI реально работал. AI ответы сохраняются с sender =
    имя ассистента (ai_settings.get_assistant_name()).
    """
    if not visitor_id or not ai_sender_name:
        return False
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT 1 FROM web_messages "
            "WHERE visitor_id = ? AND direction = 'out' AND sender = ? "
            "LIMIT 1",
            (visitor_id, ai_sender_name),
        )
        return await cur.fetchone() is not None


async def did_human_respond_to_visitor(visitor_id: str,
                                       ai_sender_name: str) -> bool:
    """[v3.5] Был ли хотя бы один ответ ЖИВОГО оператора этому визитёру.

    Используется для определения «клиент вернулся после закрытия
    оператором». operator_joined может быть уже сброшен в 0 при reset_*,
    но в истории сообщений остаются out-сообщения с sender != AI.

    Возвращает True если есть хотя бы одно out-сообщение с sender != AI.
    """
    if not visitor_id:
        return False
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT 1 FROM web_messages "
            "WHERE visitor_id = ? AND direction = 'out' "
            "AND sender IS NOT NULL AND sender != ? "
            "LIMIT 1",
            (visitor_id, ai_sender_name or ""),
        )
        return await cur.fetchone() is not None


async def reset_operator_joined(visitor_id: str) -> None:
    """
    [v3.5] Сбрасывает флаг operator_joined в 0 + status='closed'.
    Вызывается при закрытии чата оператором — после этого если клиент
    снова напишет, AI сможет ему отвечать (как с чистого листа).
    """
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            await db.execute(
                "UPDATE web_visitors SET operator_joined = 0, status = 'closed' "
                "WHERE visitor_id = ?",
                (visitor_id,),
            )
        except Exception:
            await db.execute(
                "UPDATE web_visitors SET operator_joined = 0 "
                "WHERE visitor_id = ?",
                (visitor_id,),
            )
        await db.commit()


async def detach_topic(visitor_id: str) -> None:
    """
    [v3.5] Открепляет от визитёра текущий topic_id (сохраняя его в last_topic_id).
    Используется при закрытии чата — после этого новое сообщение клиента
    создаст НОВЫЙ топик, а не «прилипнет» к старому закрытому.

    Это решает баг «AI отвечает в виджете, но переписка дублируется в старом
    TG-топике»: после открепления у визитёра topic_id=NULL → ничего не зеркалится.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE web_visitors SET last_topic_id = topic_id, "
            "topic_id = NULL WHERE visitor_id = ?",
            (visitor_id,),
        )
        await db.commit()


async def detach_visitor_identity(visitor_id: str) -> None:
    """
    Разрывает связку visitor → user_id / email. Используется при закрытии чата
    клиентом, чтобы identify не восстановил его старый разговор.
    История сообщений и сам visitor остаются — просто identify по user_id/email
    больше не указывает на него.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE web_visitors SET user_id = NULL, user_email = NULL "
            "WHERE visitor_id = ?",
            (visitor_id,),
        )
        await db.commit()


async def touch_visitor(visitor_id: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE web_visitors SET last_active_at = CURRENT_TIMESTAMP "
            "WHERE visitor_id = ?",
            (visitor_id,),
        )
        await db.commit()


async def identify_visitor(visitor_id: str,
                           user_id: int | None = None,
                           name: str | None = None,
                           email: str | None = None) -> None:
    """Сайт говорит «этот гость — user 12345 / Иван / ivan@mail.ru»."""
    # Обновляем только непустые поля
    sets = []
    args: list = []
    if user_id is not None:
        sets.append("user_id = ?")
        args.append(user_id)
    if name:
        sets.append("user_name = ?")
        args.append(name[:120])
    if email:
        sets.append("user_email = ?")
        args.append(email[:120])
    if not sets:
        return

    args.append(visitor_id)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            f"UPDATE web_visitors SET {', '.join(sets)} WHERE visitor_id = ?",
            args,
        )
        await db.commit()


async def get_visitor_by_topic(topic_id: int) -> dict | None:
    """Когда оператор пишет в топике — находим visitor_id по topic_id."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM web_visitors WHERE topic_id = ? LIMIT 1", (topic_id,),
        )
        row = await cur.fetchone()
    return dict(row) if row else None


async def get_visitor_by_user_id(user_id: int) -> dict | None:
    """
    Восстанавливаем чат по user_id. Возвращает САМОГО НОВОГО visitor
    с этим user_id. Приоритет:
      1) visitor с topic_id (есть реальный диалог в Telegram)
      2) самый недавний по last_active_at
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        # Сначала ищем visitor с topic_id — это реальный диалог
        cur = await db.execute(
            """
            SELECT * FROM web_visitors
            WHERE user_id = ? AND topic_id IS NOT NULL
            ORDER BY last_active_at DESC
            LIMIT 1
            """,
            (user_id,),
        )
        row = await cur.fetchone()
        if row:
            return dict(row)

        # Если нет с topic_id — возвращаем самого свежего
        cur = await db.execute(
            """
            SELECT * FROM web_visitors
            WHERE user_id = ?
            ORDER BY last_active_at DESC
            LIMIT 1
            """,
            (user_id,),
        )
        row = await cur.fetchone()
    return dict(row) if row else None


async def get_visitor_by_email(email: str) -> dict | None:
    """
    Fallback восстановление: если у клиента нет Telegram-id, но известен email,
    можно восстановить его чат по email.
    """
    if not email:
        return None
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT * FROM web_visitors
            WHERE user_email = ?
            ORDER BY last_active_at DESC
            LIMIT 1
            """,
            (email,),
        )
        row = await cur.fetchone()
    return dict(row) if row else None


async def detach_all_visitors_by_user_id(user_id: int) -> None:
    """
    При обнаружении хардкода в HTML сайта (когда один user_id присваивается
    разным клиентам) — отвязываем всех visitor с этим user_id. История
    сообщений сохраняется, топики остаются — просто identify по user_id
    больше не найдёт «общего» visitor.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE web_visitors SET user_id = NULL WHERE user_id = ?",
            (user_id,),
        )
        await db.commit()


async def count_distinct_visitors_for_user(user_id: int, minutes: int = 60) -> int:
    """
    Считает сколько РАЗНЫХ visitor_id привязалось к этому user_id за последние N минут.
    Используется для детекции «хардкод-id»: если за час 5+ разных visitor_id
    утверждают что они — user 123, то 123 наверняка захардкожен в HTML, а не
    реальный ID клиента.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            f"""
            SELECT COUNT(DISTINCT visitor_id) FROM web_visitors
            WHERE user_id = ?
              AND datetime(last_active_at) > datetime('now', '-{int(minutes)} minutes')
            """,
            (user_id,),
        )
        row = await cur.fetchone()
    return row[0] if row else 0


async def list_visitors(limit: int = 100) -> list[dict]:
    """Список всех гостей в порядке последней активности."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT v.*,
                   (SELECT COUNT(*) FROM web_messages m
                    WHERE m.visitor_id = v.visitor_id) AS messages_count,
                   (SELECT text FROM web_messages m
                    WHERE m.visitor_id = v.visitor_id
                    ORDER BY id DESC LIMIT 1) AS last_message
            FROM web_visitors v
            ORDER BY last_active_at DESC
            LIMIT ?
            """,
            (limit,),
        )
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


# ============================================================
#  СООБЩЕНИЯ
# ============================================================

async def add_message(visitor_id: str, direction: str, text: str,
                      sender: str | None = None,
                      attachment_url: str | None = None,
                      attachment_kind: str | None = None) -> int:
    """Сохраняет сообщение, возвращает id."""
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO web_messages
              (visitor_id, direction, sender, text, attachment_url, attachment_kind, delivered)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (visitor_id, direction, sender, text,
             attachment_url, attachment_kind,
             1 if direction == "in" else 0),
        )
        await db.commit()
        # Заодно — обновим last_active гостя
        await db.execute(
            "UPDATE web_visitors SET last_active_at = CURRENT_TIMESTAMP "
            "WHERE visitor_id = ?",
            (visitor_id,),
        )
        await db.commit()
        return cur.lastrowid


async def get_messages_since(visitor_id: str, last_id: int) -> list[dict]:
    """Возвращает сообщения с id > last_id (для polling)."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, direction, sender, text, attachment_url, attachment_kind, created_at
            FROM web_messages
            WHERE visitor_id = ? AND id > ?
            ORDER BY id
            """,
            (visitor_id, last_id),
        )
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def get_all_messages(visitor_id: str, limit: int = 200) -> list[dict]:
    """История чата (для админки).

    [v3.5] Если у visitor есть user_id, а сообщений на самом visitor_id
    нет — возвращаем messages со ВСЕХ visitor_id этого user_id. Это
    показывает всю историю клиента, а не одной случайной сессии браузера.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row

        # 1. Прямой запрос по visitor_id
        cur = await db.execute(
            """
            SELECT id, direction, sender, text,
                   attachment_url, attachment_kind, created_at
            FROM web_messages
            WHERE visitor_id = ?
            ORDER BY id
            LIMIT ?
            """,
            (visitor_id, limit),
        )
        rows = await cur.fetchall()

        # 2. [v3.5] Если пусто — fallback по user_id (вся история клиента
        # со всех его сессий браузера, не только этой)
        if not rows:
            cur = await db.execute(
                "SELECT user_id FROM web_visitors WHERE visitor_id = ?",
                (visitor_id,),
            )
            v_row = await cur.fetchone()
            if v_row and v_row["user_id"]:
                cur = await db.execute(
                    """
                    SELECT m.id, m.direction, m.sender, m.text,
                           m.attachment_url, m.attachment_kind, m.created_at
                    FROM web_messages m
                    JOIN web_visitors v ON v.visitor_id = m.visitor_id
                    WHERE v.user_id = ?
                    ORDER BY m.id
                    LIMIT ?
                    """,
                    (v_row["user_id"], limit),
                )
                rows = await cur.fetchall()

    return [dict(r) for r in rows]


async def mark_delivered(message_ids: list[int]) -> None:
    """Помечает что эти 'out'-сообщения дошли до клиента."""
    if not message_ids:
        return
    placeholders = ",".join("?" for _ in message_ids)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            f"UPDATE web_messages SET delivered = 1 WHERE id IN ({placeholders})",
            message_ids,
        )
        await db.commit()


# ============================================================
#  RATE LIMIT
# ============================================================

async def count_recent_messages(visitor_id: str, minutes: int = 60) -> int:
    """Сообщений от этого гостя за последние N минут (для rate-limit)."""
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """
            SELECT COUNT(*) FROM web_messages
            WHERE visitor_id = ?
              AND direction = 'in'
              AND datetime(created_at) > datetime('now', '-' || ? || ' minutes')
            """,
            (visitor_id, minutes),
        )
        row = await cur.fetchone()
    return row[0] if row else 0

# ============================================================
#  УВЕДОМЛЕНИЯ О ТОМ ЧТО КЛИЕНТ НЕ УВИДЕЛ ОТВЕТ
# ============================================================

async def get_undelivered_for_visitor(visitor_id: str) -> list[dict]:
    """
    Возвращает out-сообщения, которые клиент ещё НЕ забрал через /poll
    и для которых ещё не слалось уведомление в топик.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, text, attachment_url, attachment_kind,
                   sender, created_at
            FROM web_messages
            WHERE visitor_id = ?
              AND direction = 'out'
              AND delivered = 0
              AND COALESCE(notified_offline, 0) = 0
            ORDER BY id ASC
            """,
            (visitor_id,),
        )
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


async def mark_notified_offline(message_ids: list[int]) -> None:
    """Помечает сообщения как «уведомление уже отправлено в топик»."""
    if not message_ids:
        return
    placeholders = ",".join("?" for _ in message_ids)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            f"UPDATE web_messages SET notified_offline = 1 "
            f"WHERE id IN ({placeholders})",
            message_ids,
        )
        await db.commit()


async def find_inactive_undelivered(
    inactive_minutes: int = 2,
    max_age_hours: int = 24,
) -> list[dict]:
    """
    Ищет визитёров у которых:
      - есть out-сообщения с delivered=0 и notified_offline=0
      - last_active_at был раньше чем inactive_minutes назад
      - есть topic_id (куда уведомлять)
      - хотя бы одно из этих сообщений старше inactive_minutes
        (чтобы не тревожить оператора сразу же)
      - НО сообщение не старше max_age_hours (старые игнорируем —
        нет смысла уведомлять про сообщения многомесячной давности)
    Возвращает: [{visitor_id, topic_id, user_name, user_id, msg_ids: [...]}]
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            f"""
            SELECT v.visitor_id, v.topic_id, v.user_name, v.user_id,
                   v.last_active_at,
                   GROUP_CONCAT(m.id) AS msg_ids,
                   COUNT(m.id) AS msg_count,
                   MIN(m.created_at) AS oldest_msg_at
            FROM web_visitors v
            JOIN web_messages m ON m.visitor_id = v.visitor_id
            WHERE v.topic_id IS NOT NULL
              AND m.direction = 'out'
              AND m.delivered = 0
              AND COALESCE(m.notified_offline, 0) = 0
              AND datetime(m.created_at) <
                  datetime('now', '-{int(inactive_minutes)} minutes')
              AND datetime(m.created_at) >
                  datetime('now', '-{int(max_age_hours)} hours')
              AND datetime(v.last_active_at) <
                  datetime('now', '-{int(inactive_minutes)} minutes')
            GROUP BY v.visitor_id
            """,
        )
        rows = await cur.fetchall()
    result = []
    for r in rows:
        ids_str = r["msg_ids"] or ""
        try:
            ids = [int(x) for x in ids_str.split(",") if x]
        except Exception:
            ids = []
        if not ids:
            continue
        result.append({
            "visitor_id": r["visitor_id"],
            "topic_id": r["topic_id"],
            "user_name": r["user_name"],
            "user_id": r["user_id"],
            "msg_ids": ids,
            "msg_count": r["msg_count"],
            "oldest_msg_at": r["oldest_msg_at"],
        })
    return result


# ============================================================
#  [v3.5] УПРАВЛЕНИЕ СТАТУСОМ ТИКЕТА ВЕБ-ЧАТА
# ============================================================

async def set_visitor_status(visitor_id: str, status: str) -> None:
    """[v3.5] Меняет статус тикета веб-чата: 'closed' / 'open'.

    closed — AI работает с клиентом, оператор не нужен
    open — была эскалация, оператор подключён
    """
    if status not in ("closed", "open"):
        return
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE web_visitors SET status = ? WHERE visitor_id = ?",
            (status, visitor_id),
        )
        await db.commit()


async def get_visitor_status(visitor_id: str) -> str:
    """[v3.5] Возвращает статус тикета веб-чата ('closed' по умолчанию)."""
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT status FROM web_visitors WHERE visitor_id = ?",
            (visitor_id,),
        )
        row = await cur.fetchone()
        if not row:
            return "closed"
        return row[0] or "closed"
