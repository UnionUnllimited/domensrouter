"""
HTTP API для веб-чата.

Запускается рядом с aiogram-диспетчером в том же процессе бота.
Слушает на 0.0.0.0:8090 (внутренний порт, наружу проксирует Caddy).

Эндпоинты:
  POST /api/chat/session   — создать visitor_id или принять существующий
  POST /api/chat/message   — гость пишет сообщение → летит в Telegram-топик
  GET  /api/chat/poll      — гость опрашивает новые сообщения
  POST /api/chat/identify  — сайт говорит «гость = user 12345»
  GET  /api/chat/widget.js — отдача JS-файла виджета
  GET  /api/chat/health    — пинг

CORS:
  Сейчас разрешены ВСЕ origins (для отладки).
  В Ответе 1B сузим до whitelist (moremore.pro).
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from datetime import datetime

from aiogram import Bot
from aiohttp import web
from loguru import logger

from app import web_chat_db
from app import widget_settings


# Конфигурация
WEB_CHAT_PORT = int(os.getenv("WEB_CHAT_PORT", "8090"))
SUPPORT_CHAT_ID = int(os.getenv("SUPPORT_CHAT_ID", "0"))

# Глобальная ссылка на aiogram-Bot — сохраняется при start_web_chat_server()
# и используется фоновыми задачами (inactivity watcher, beacon /leave).
# Так избегаем циклического импорта `from app.main import bot`.
_bot_instance = None

# Лимиты
MAX_MESSAGE_LENGTH = 2000
MAX_MESSAGES_PER_HOUR = 30
MAX_NAME_LENGTH = 80
MAX_EMAIL_LENGTH = 120


# ============================================================
#  Имя топика для веб-визитёра
# ============================================================

def _build_web_topic_name(visitor: dict) -> str:
    """
    [v3.5] Имя форум-топика для веб-клиента.
    Префикс 🌐 (всегда) + имя визитёра / email / tg_user_id /
    "Гость {visitor_id[:8]}".
    Telegram имя топика ограничено 128 символами.
    """
    name = (visitor.get("name") or "").strip()
    if name:
        return f"🌐 {name}"[:128]
    email = (visitor.get("email") or "").strip()
    if email:
        return f"🌐 {email}"[:128]
    tg_uid = visitor.get("user_id")
    if tg_uid:
        return f"🌐 {tg_uid}"
    visitor_id = visitor.get("visitor_id") or ""
    return f"🌐 Гость {visitor_id[:8]}" if visitor_id else "🌐 Гость"


# Регексы для валидации
_VISITOR_ID_RE = re.compile(r"^[A-Za-z0-9_\-]{12,64}$")
_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def _cors_headers(request: web.Request) -> dict:
    """CORS-заголовки. Origin берётся из настроек виджета в БД."""
    origin = request.headers.get("Origin", "")
    # Получаем текущие настройки
    try:
        settings = widget_settings.get_settings_sync()
    except Exception:
        settings = widget_settings.DEFAULT_SETTINGS

    if widget_settings.is_origin_allowed(origin, settings):
        allow = origin
    elif "*" in settings.get("allowed_origins", []):
        allow = "*"
    else:
        # Origin не в whitelist — всё равно вернём CORS-заголовки, но с пустым
        # Allow-Origin (тогда браузер заблокирует ответ сам).
        allow = ""

    return {
        "Access-Control-Allow-Origin": allow,
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": (
            "Content-Type, X-Visitor-Id, Accept, Origin, "
            "X-Requested-With, Cache-Control"
        ),
        "Access-Control-Max-Age": "3600",
        "Vary": "Origin",
    }


def _json_response(request: web.Request, data: dict, status: int = 200) -> web.Response:
    return web.json_response(data, status=status, headers=_cors_headers(request))


def _error(request: web.Request, message: str, status: int = 400) -> web.Response:
    return _json_response(request, {"ok": False, "error": message}, status=status)


# ============================================================
#  CORS preflight
# ============================================================

async def cors_preflight(request: web.Request) -> web.Response:
    return web.Response(status=200, headers=_cors_headers(request))


# ============================================================
#  POST /api/chat/session
# ============================================================

async def create_session(request: web.Request) -> web.Response:
    """
    Гость заходит на сайт. Если у него уже есть visitor_id в localStorage —
    шлёт его в Header X-Visitor-Id. Если нет — сервер выдаёт новый.

    Body (опционально): {referer: "..."}
    Headers (опционально): X-Visitor-Id, User-Agent

    Returns: {ok: true, visitor_id: "...", is_new: bool}
    """
    try:
        body = await request.json()
    except Exception:
        body = {}

    incoming_id = request.headers.get("X-Visitor-Id", "").strip()
    user_agent = request.headers.get("User-Agent", "")[:300]
    referer = body.get("referer") or request.headers.get("Referer", "")
    referer = (referer or "")[:300]

    # IP клиента (учитываем что мы за Caddy proxy → X-Forwarded-For)
    client_ip = _extract_client_ip(request)

    is_new = False
    if incoming_id and _VISITOR_ID_RE.match(incoming_id):
        if not await web_chat_db.visitor_exists(incoming_id):
            # ID был у клиента, но БД его не помнит (новая БД, переехали и т.п.)
            await web_chat_db.create_visitor(incoming_id, user_agent, referer)
            is_new = True
        else:
            await web_chat_db.touch_visitor(incoming_id)
        visitor_id = incoming_id
    else:
        visitor_id = web_chat_db.new_visitor_id()
        await web_chat_db.create_visitor(visitor_id, user_agent, referer)
        is_new = True

    # Сохраняем IP — нужен для географии
    if client_ip:
        try:
            await web_chat_db.set_visitor_ip(visitor_id, client_ip)
        except Exception as e:
            logger.debug("set_visitor_ip failed: {}", e)

    return _json_response(request, {
        "ok": True,
        "visitor_id": visitor_id,
        "is_new": is_new,
    })


def _extract_client_ip(request: web.Request) -> str:
    """
    Извлекает реальный IP клиента из запроса.
    Учитывает X-Forwarded-For / X-Real-IP (от Caddy).
    Игнорирует приватные сети (10/8, 172.16/12, 192.168/16) которые
    могут оказаться в forwarded заголовке.
    """
    # X-Forwarded-For может быть списком: "client, proxy1, proxy2"
    xff = request.headers.get("X-Forwarded-For", "")
    if xff:
        for ip in [p.strip() for p in xff.split(",")]:
            if ip and not _is_private_ip(ip):
                return ip
    # Fallback на X-Real-IP
    real_ip = request.headers.get("X-Real-IP", "").strip()
    if real_ip and not _is_private_ip(real_ip):
        return real_ip
    # Прямое подключение
    peer = request.remote or ""
    if peer and not _is_private_ip(peer):
        return peer
    return ""


def _is_private_ip(ip: str) -> bool:
    """Возвращает True если IP в приватной сети (не для географии)."""
    if not ip:
        return True
    # IPv6 loopback / link-local — пропускаем
    if ip.startswith("::1") or ip.startswith("fe80:") or ip.startswith("fc"):
        return True
    parts = ip.split(".")
    if len(parts) != 4:
        return False  # IPv6 — оставляем
    try:
        a, b = int(parts[0]), int(parts[1])
    except ValueError:
        return True
    # 10.0.0.0/8
    if a == 10:
        return True
    # 172.16.0.0/12
    if a == 172 and 16 <= b <= 31:
        return True
    # 192.168.0.0/16
    if a == 192 and b == 168:
        return True
    # 127.0.0.0/8
    if a == 127:
        return True
    return False


# ============================================================
#  POST /api/chat/identify
# ============================================================

async def identify(request: web.Request) -> web.Response:
    """
    Сайт сообщает: «этот гость — user 12345 (Иван, ivan@mail.ru)».

    ВАЖНО: если у нас уже есть visitor с этим user_id (клиент терял
    localStorage / cookies / переключал устройство), мы возвращаем СТАРЫЙ
    visitor_id. Клиент сохранит его и продолжит в том же топике в Telegram.
    Это критическая защита от потери истории чата.

    Body: {visitor_id: ..., user_id?: int, name?: str, email?: str}
    Returns: {ok, visitor_id} — может ОТЛИЧАТЬСЯ от того что прислали!
    """
    try:
        body = await request.json()
    except Exception:
        return _error(request, "Невалидный JSON")

    visitor_id = (body.get("visitor_id") or "").strip()
    if not _VISITOR_ID_RE.match(visitor_id):
        return _error(request, "Невалидный visitor_id")
    if not await web_chat_db.visitor_exists(visitor_id):
        return _error(request, "Сессия не найдена", status=404)

    user_id = body.get("user_id")
    raw_user_id = user_id  # сохраним для лога
    if user_id is not None:
        try:
            user_id = int(user_id)
            if user_id <= 0 or user_id > 10**12:
                return _error(request, "Невалидный user_id")
        except (TypeError, ValueError):
            return _error(request, "user_id должен быть числом")

    name = (body.get("name") or "").strip()[:MAX_NAME_LENGTH] or None
    email = (body.get("email") or "").strip()[:MAX_EMAIL_LENGTH] or None
    if email and not _EMAIL_RE.match(email):
        return _error(request, "Невалидный email")

    # Подробный лог входа — на debug, в обычных условиях не нужен.
    # Финальный лог результата идёт в конце функции на INFO.
    logger.debug(
        "WEB_CHAT identify ВХОД: visitor={} body={!r} → "
        "user_id={!r} name={!r} email={!r}",
        visitor_id, body, user_id, name, email,
    )

    # === МОНИТОРИНГ user_id (только лог, без блокировки) ===
    # Если за последний час 3+ РАЗНЫХ visitor_id привязались к одному
    # user_id — это подозрительно (возможно хардкод в HTML). Логируем
    # как warning, но НЕ блокируем. Реальный клиент может иметь несколько
    # сессий, и блокировка здесь была бы ложной тревогой.
    if user_id is not None:
        try:
            distinct_count = await web_chat_db.count_distinct_visitors_for_user(
                user_id, minutes=60,
            )
            if distinct_count >= 3:
                logger.warning(
                    "WEB_CHAT identify: user_id={} привязан к {} разным "
                    "visitor_id за час — возможен хардкод в HTML сайта "
                    "(если все клиенты получают один user_id). Проверьте "
                    "View Source страницы кабинета для разных клиентов.",
                    user_id, distinct_count,
                )
        except Exception as e:
            logger.warning("Не удалось проверить distinct visitors: {}", e)

    # КЛЮЧЕВАЯ ЛОГИКА: проверяем нет ли уже visitor с этим user_id
    canonical_visitor_id = visitor_id
    if user_id is not None:
        existing = await web_chat_db.get_visitor_by_user_id(user_id)
        if existing and existing["visitor_id"] != visitor_id:
            # Есть старый visitor для этого user_id — используем его
            canonical_visitor_id = existing["visitor_id"]
            # Обновляем имя/email если переданы
            if name or email:
                await web_chat_db.identify_visitor(
                    canonical_visitor_id, user_id=user_id,
                    name=name, email=email,
                )
            else:
                # Просто трогаем активность
                await web_chat_db.touch_visitor(canonical_visitor_id)
            logger.info(
                "WEB_CHAT identify: восстановил visitor для user_id={}: "
                "{} → {} (старый сбросится)",
                user_id, visitor_id, canonical_visitor_id,
            )
            return _json_response(request, {
                "ok": True,
                "visitor_id": canonical_visitor_id,
                "restored": True,
            })
    elif email:
        # Fallback: нет user_id, но есть email — ищем по email
        existing = await web_chat_db.get_visitor_by_email(email)
        if existing and existing["visitor_id"] != visitor_id:
            canonical_visitor_id = existing["visitor_id"]
            if name:
                await web_chat_db.identify_visitor(
                    canonical_visitor_id, name=name, email=email,
                )
            else:
                await web_chat_db.touch_visitor(canonical_visitor_id)
            logger.info(
                "WEB_CHAT identify: восстановил visitor для email={!r}: "
                "{} → {} (старый сбросится)",
                email, visitor_id, canonical_visitor_id,
            )
            return _json_response(request, {
                "ok": True,
                "visitor_id": canonical_visitor_id,
                "restored": True,
            })

    # Иначе — обычный identify.
    # Но сначала проверяем: не сидит ли на этом visitor_id ДРУГОЙ user_id?
    # Если да — значит на одном устройстве/браузере поменялся клиент.
    # Создаём новый visitor_id чтобы новый клиент не получил переписку старого.
    if user_id is not None:
        try:
            current = await web_chat_db.get_visitor(visitor_id)
        except Exception:
            current = None
        if current and current.get("user_id") and current["user_id"] != user_id:
            old_user_id = current["user_id"]
            new_vid = web_chat_db.new_visitor_id()
            await web_chat_db.create_visitor(
                new_vid,
                user_agent=request.headers.get("User-Agent", "")[:300],
                referer=request.headers.get("Referer", "")[:300],
            )
            await web_chat_db.identify_visitor(
                new_vid, user_id=user_id, name=name, email=email,
            )
            logger.warning(
                "WEB_CHAT identify: на visitor={} был user_id={}, теперь пришёл "
                "user_id={} — создал новый visitor_id={} (старая переписка "
                "сохранена, новый клиент будет отдельным топиком)",
                visitor_id, old_user_id, user_id, new_vid,
            )
            return _json_response(request, {
                "ok": True,
                "visitor_id": new_vid,
                "restored": False,
                "rotated": True,
            })

    # Обычный identify — обновляем данные текущего visitor
    await web_chat_db.identify_visitor(
        visitor_id, user_id=user_id, name=name, email=email,
    )

    logger.info("WEB_CHAT identify {}: user_id={} name={!r} email={!r}",
                visitor_id, user_id, name, email)
    return _json_response(request, {
        "ok": True,
        "visitor_id": canonical_visitor_id,
        "restored": False,
    })


# ============================================================
#  POST /api/chat/message
# ============================================================

# [v3.5] Маркеры ошибок Telegram «topic невалиден». Когда зеркалирование
# в ghost-topic падает с такой ошибкой — пересоздаём topic и переносим
# историю клиента из БД (web_messages) в новый.
_TOPIC_INVALID_MARKERS = (
    "topic_deleted", "topic deleted",
    "topic_not_found", "topic not found",
    "thread not found", "thread_not_found",
    "message thread not found",
    "topic was deleted",
)


def _is_topic_invalid_error(exc: Exception) -> bool:
    """[v3.5] Проверяет — ошибка ли это «топик удалён/недоступен».

    Возвращает True для ВСЕХ ошибок кроме явных TOPIC_NOT_MODIFIED.
    Это безопаснее чем гадать маркеры — текст ошибки от TG меняется,
    а молча отправлять в General нельзя.
    """
    err = str(exc).lower()
    # Известные маркеры удалённого topic
    if any(m in err for m in _TOPIC_INVALID_MARKERS):
        return True
    # TOPIC_NOT_MODIFIED — это не «удалён», это «нет изменений» → ok
    if "topic_not_modified" in err or "topic not modified" in err:
        return False
    # Иначе — считаем что topic недоступен, лучше пересоздать
    # (чем рисковать отправкой в General topic группы).
    return True


async def _recreate_ghost_topic_with_history(
    bot: "Bot",
    visitor: dict,
    visitor_id: str,
    history_limit: int = 30,
) -> int | None:
    """[v3.5] Создаёт НОВЫЙ ghost-topic в TG и переносит туда:
       1) Шапку «♻️ Топик пересоздан» (с предупреждением)
       2) Полную шапку клиента (инфа из 3xUIStore, кнопки)
       3) Последние N сообщений из БД (web_messages)
       4) Закрывает новый topic (AI-режим)

    Возвращает новый topic_id или None при ошибке.
    """
    # [v3.5] quiet_send: для всех сообщений в новый ghost-topic
    quiet_send = (visitor.get("status", "closed") != "open")
    try:
        tg_uid = visitor.get("user_id")
        topic_name = _build_web_topic_name(visitor)
        # [v3.5] Создаём с иконкой по статусу:
        #   open → "web" (💻 — активный диалог)
        #   closed → "closed" (✅ — AI-режим, форум-топик потом закроем)
        try:
            from app import topic_icons
            initial_role = "web" if visitor.get("status") == "open" else "closed"
            _, icon_id = topic_icons.get_icon_id(initial_role)
        except Exception:
            icon_id = None
        kwargs = {"chat_id": SUPPORT_CHAT_ID, "name": topic_name}
        if icon_id:
            kwargs["icon_custom_emoji_id"] = icon_id
        topic = await bot.create_forum_topic(**kwargs)
        new_topic_id = topic.message_thread_id

        # Обновляем topic_id в БД
        await web_chat_db.set_visitor_topic(visitor_id, new_topic_id)
        logger.info(
            "WEB_CHAT ghost-topic пересоздан: visitor={} новый topic={}",
            visitor_id, new_topic_id,
        )

        # 1) Шапка «топик восстановлен»
        try:
            await bot.send_message(
                chat_id=SUPPORT_CHAT_ID,
                message_thread_id=new_topic_id,
                text=(
                    "♻️ <b>Топик пересоздан</b>\n"
                    "<i>(старый topic был удалён, но история клиента "
                    "сохранена в БД и восстановлена ниже)</i>"
                ),
                parse_mode="HTML",
                disable_notification=True,  # [v3.5] тихо
            )
        except Exception as e:
            logger.warning("WEB_CHAT recreate: header msg failed: {}", e)

        # 2) Полная шапка клиента с данными подписки + кнопки админа
        try:
            header = await _build_visitor_header(visitor)
            reply_markup = None
            # [v3.5] Гость без TG user_id → web_guest_keyboard
            try:
                if tg_uid:
                    from app.keyboards import ticket_admin_keyboard
                    import os as _os
                    admin_url = _os.getenv(
                        "ADMIN_PANEL_URL",
                        "https://ltefreemore.online/FixPakapassFGg_g34/users/",
                    )
                    reply_markup = ticket_admin_keyboard(
                        int(tg_uid), admin_url,
                    )
                else:
                    from app.keyboards import web_guest_keyboard
                    reply_markup = web_guest_keyboard()
            except Exception:
                pass
            await bot.send_message(
                chat_id=SUPPORT_CHAT_ID,
                message_thread_id=new_topic_id,
                text=header,
                parse_mode="HTML",
                reply_markup=reply_markup,
                disable_notification=True,  # [v3.5] шапка тикета — всегда тихо
            )
        except Exception as e:
            logger.warning("WEB_CHAT recreate: visitor header failed: {}", e)

        # 3) История переписки из web_messages
        try:
            messages = await web_chat_db.get_all_messages(
                visitor_id, limit=history_limit,
            )
            if messages:
                # Формируем единое сообщение-историю
                lines = [
                    "📜 <b>История переписки</b> "
                    f"(последние {len(messages)} сообщ.):\n"
                ]
                for m in messages:
                    direction = m.get("direction", "")
                    sender = m.get("sender") or "—"
                    text = (m.get("text") or "")[:500]
                    ts = m.get("created_at", "")
                    if direction == "in":
                        prefix = "💬 <b>Клиент:</b>"
                    else:
                        prefix = f"🤖 <b>{html_escape(sender)}:</b>"
                    lines.append(
                        f"{prefix} <i>({ts})</i>\n{html_escape(text)}"
                    )
                full_history = "\n\n".join(lines)
                # Telegram лимит на сообщение 4096 — режем при необходимости
                if len(full_history) > 4000:
                    full_history = (
                        full_history[:4000]
                        + "\n\n<i>...история обрезана</i>"
                    )
                await bot.send_message(
                    chat_id=SUPPORT_CHAT_ID,
                    message_thread_id=new_topic_id,
                    text=full_history,
                    parse_mode="HTML",
                    disable_notification=True,  # [v3.5] тихо
                )
                logger.info(
                    "WEB_CHAT recreate: восстановлено {} сообщ. в topic {}",
                    len(messages), new_topic_id,
                )
        except Exception as e:
            logger.warning("WEB_CHAT recreate: history failed: {}", e)

        # 4) Закрываем новый topic (AI-режим если статус 'closed')
        try:
            current_status = visitor.get("status", "closed")
            if current_status == "closed":
                await bot.close_forum_topic(
                    chat_id=SUPPORT_CHAT_ID,
                    message_thread_id=new_topic_id,
                )
                logger.info(
                    "WEB_CHAT recreate: новый topic {} закрыт (AI-режим)",
                    new_topic_id,
                )
        except Exception as e:
            logger.warning("WEB_CHAT recreate: close failed: {}", e)

        return new_topic_id
    except Exception as e:
        logger.exception("WEB_CHAT recreate ghost-topic failed: {}", e)
        return None


async def send_message(request: web.Request) -> web.Response:
    """
    Гость пишет сообщение. Сохраняем в БД и отправляем в Telegram-топик.

    Body: {visitor_id: ..., text: ...}
    """
    try:
        body = await request.json()
    except Exception:
        return _error(request, "Невалидный JSON")

    visitor_id = (body.get("visitor_id") or "").strip()
    if not _VISITOR_ID_RE.match(visitor_id):
        return _error(request, "Невалидный visitor_id")

    text = (body.get("text") or "").strip()
    if not text:
        return _error(request, "Пустое сообщение")
    if len(text) > MAX_MESSAGE_LENGTH:
        return _error(request, f"Сообщение слишком длинное (>{MAX_MESSAGE_LENGTH} символов)")

    visitor = await web_chat_db.get_visitor(visitor_id)
    if not visitor:
        return _error(request, "Сессия не найдена. Перезагрузите страницу.", status=404)

    # [v3.5] Rate-limit через настраиваемый модуль security
    from app import security
    allowed, rl_reason = await security.check_message_rate(visitor_id)
    if not allowed:
        logger.info("WEB_CHAT rate-limit visitor={}: {}", visitor_id, rl_reason)
        return _error(
            request, "⏱ Слишком часто. Попробуйте через минуту.",
            status=429,
        )
    await security.record_message(visitor_id)

    # [v3.5] Защита от prompt injection
    text, injection_reason = await security.sanitize_user_input(text)
    if injection_reason:
        logger.warning(
            "WEB_CHAT prompt-injection visitor={}: {}",
            visitor_id, injection_reason,
        )

    # Сохраняем в БД
    msg_id = await web_chat_db.add_message(visitor_id, "in", text)

    # Получаем bot (его кладём в app['bot'] при старте)
    bot: Bot | None = request.app.get("bot")
    if bot is None or not SUPPORT_CHAT_ID:
        logger.warning("WEB_CHAT нет bot или SUPPORT_CHAT_ID — сообщение только в БД")
        return _json_response(request, {"ok": True, "message_id": msg_id})

    # [v3.5] Создаём ghost-topic СРАЗУ при первом сообщении (даже если
    # клиент пока общается только с AI). Это позволяет операторам видеть
    # переписку с самого начала.
    ghost_topic_id: int | None = visitor.get("topic_id")

    # [v3.5] quiet_send — глобальная переменная функции:
    # True (тихо) если visitor.status='closed' (AI работает / закрытый тикет)
    # False (звук) если visitor.status='open' (оператор активен)
    # Определяем ОДИН РАЗ в начале — потом используется во всех bot.send_message.
    quiet_send = (visitor.get("status", "closed") != "open")

    # [v3.5] КРИТИЧНО: определяем «возврат клиента после закрытия оператором».
    # Сценарий:
    #   1. Оператор отвечал клиенту (out-сообщения с sender != AI)
    #   2. Оператор закрыл тикет (status='closed', operator_joined может
    #      быть сброшен в 0 через reset_operator_joined)
    #   3. Клиент пишет снова → нужно переоткрыть topic и дать ЗВУК
    #
    # ВАЖНО: срабатывает ТОЛЬКО когда AI глобально выключен. Если AI
    # включён — он попробует ответить молча в AI-режиме (тикет остаётся
    # закрытым, всё тихо). Если AI справится → отлично. Если AI не
    # справится или escalate → стандартная логика эскалации сама
    # откроет тикет со звуком. Дополнительный шум здесь не нужен.
    is_returning_client = False
    try:
        from admin_web import ai_settings as _ais
        _ai_globally_on = _ais.is_enabled()
        _ai_name = _ais.get_assistant_name() or ""
    except Exception:
        _ai_globally_on = False
        _ai_name = ""

    if (not _ai_globally_on
            and ghost_topic_id is not None
            and visitor.get("status", "closed") == "closed"):
        # AI отключён глобально → есть смысл проверять «возврат клиента»
        try:
            had_human = await web_chat_db.did_human_respond_to_visitor(
                visitor_id, _ai_name,
            )
            is_returning_client = had_human
        except Exception as e:
            logger.warning("did_human_respond check failed: {}", e)

    if is_returning_client:
        quiet_send = False  # ЗВУК — клиент вернулся
        logger.warning(
            "🔔 WEB_CHAT клиент вернулся после закрытия (AI off): "
            "visitor={} topic={}",
            visitor_id, ghost_topic_id,
        )
        # Переводим статус обратно в 'open' — оператор должен ответить
        try:
            await web_chat_db.set_visitor_status(visitor_id, "open")
        except Exception as e:
            logger.warning("set_visitor_status open failed: {}", e)

    # [v3.5] Если topic_id уже есть (вечный тикет) — проверяем что он жив,
    # но НЕ переоткрываем если AI-режим (status='closed'). Топик должен
    # оставаться закрытым пока AI работает. Раньше тут было unconditional
    # reopen + меняли иконку на 💻 — топик визуально становился «активным»
    # при каждом новом сообщении, хотя AI всё ещё отвечает.
    if ghost_topic_id and bot:
        current_status = visitor.get("status", "closed")
        # [v3.5] При возврате клиента — тоже открываем topic + меняем иконку
        if current_status == "open" or is_returning_client:
            # Оператор взял управление — переоткрываем как раньше
            try:
                try:
                    await bot.reopen_forum_topic(
                        chat_id=SUPPORT_CHAT_ID,
                        message_thread_id=ghost_topic_id,
                    )
                except Exception as e:
                    if "TOPIC_NOT_MODIFIED" not in str(e):
                        raise
                # При возврате — иконку обратно на 💻 web (источник — виджет)
                if is_returning_client:
                    try:
                        from app import topic_icons
                        await topic_icons.set_topic_icon(
                            bot, SUPPORT_CHAT_ID,
                            ghost_topic_id, "web",
                        )
                    except Exception as e:
                        logger.debug("set icon web on return: {}", e)
                    # Яркое уведомление в топик со звуком
                    try:
                        await bot.send_message(
                            chat_id=SUPPORT_CHAT_ID,
                            message_thread_id=ghost_topic_id,
                            text=(
                                "🔔 <b>Клиент вернулся в чат</b>\n"
                                "<i>Тикет был закрыт — переоткрыт. "
                                "Ответьте клиенту.</i>"
                            ),
                            parse_mode="HTML",
                            disable_notification=False,  # СО ЗВУКОМ
                        )
                    except Exception as e:
                        logger.warning("notify return failed: {}", e)
            except Exception as e:
                logger.warning(
                    "WEB_CHAT topic {} невалиден (удалён?): {} — пересоздаю",
                    ghost_topic_id, e,
                )
                ghost_topic_id = None
        else:
            # [v3.5] AI-режим (status='closed'). Топик должен оставаться
            # закрытым. РАНЬШЕ тут вызывался `close_forum_topic` каждый раз
            # для проверки существования topic — но это публиковало TG
            # service-message "Topic closed by Bot" со звуком при каждом
            # сообщении клиента после закрытия тикета.
            #
            # Теперь — НЕ делаем проактивную проверку. Полагаемся на
            # реактивную обработку ошибки при зеркалировании ниже:
            # если topic удалён, send_message упадёт с
            # MESSAGE_THREAD_NOT_FOUND → _is_topic_invalid_error поймает
            # → _recreate_ghost_topic_with_history пересоздаст с историей.
            pass

    if not ghost_topic_id:
        # [v3.5] ЖЁСТКАЯ ТИШИНА при создании нового тикета:
        # quiet_send = True ВСЕГДА, независимо от AI on/off.
        # Создание тикета — это служебное событие, оно НЕ должно звенеть.
        # Звук появляется только при ПОСЛЕДУЮЩИХ сообщениях клиента
        # после эскалации (когда оператор активен).
        quiet_send = True  # жёстко тихо при создании
        try:
            # Пробуем переоткрыть старый topic (из last_topic_id)
            last_topic = visitor.get("last_topic_id")
            if last_topic:
                try:
                    await bot.reopen_forum_topic(
                        chat_id=SUPPORT_CHAT_ID,
                        message_thread_id=last_topic,
                    )
                    # Проверяем что topic существует — пробным сообщением
                    await bot.send_message(
                        chat_id=SUPPORT_CHAT_ID,
                        message_thread_id=last_topic,
                        text="🔓 <b>Клиент вернулся</b>",
                        parse_mode="HTML",
                        disable_notification=True,  # [v3.5] тихо
                    )
                    ghost_topic_id = last_topic
                except Exception:
                    ghost_topic_id = None

            # Если переоткрытия не получилось — создаём новый topic
            if not ghost_topic_id:
                tg_uid = visitor.get("user_id")
                topic_name = _build_web_topic_name(visitor)
                from app import topic_icons
                icon_id = None
                try:
                    _, icon_id = topic_icons.get_icon_id("web")
                except Exception:
                    pass
                kwargs = {"name": topic_name}
                if icon_id:
                    kwargs["icon_custom_emoji_id"] = icon_id
                topic = await bot.create_forum_topic(
                    chat_id=SUPPORT_CHAT_ID, **kwargs,
                )
                ghost_topic_id = topic.message_thread_id

                # [v3.5] ПОЛНАЯ шапка тикета с данными подписки из 3xUIStore.
                # Используем готовую функцию _build_visitor_header — она
                # вызывает admin_panel.build_ticket_info_block() и подтягивает
                # все данные клиента (подписка, лимит устройств, и т.п.).
                try:
                    ghost_header = await _build_visitor_header(visitor)
                except Exception as e:
                    logger.warning("WEB_CHAT ghost _build_visitor_header: {}", e)
                    # Fallback на минимальную шапку
                    ghost_header = (
                        f"🌐🤖 <b>Веб-чат #{visitor_id[:8]}</b>\n"
                        f"<b>Visitor ID:</b> <code>{visitor_id}</code>"
                    )
                # Префикс что это AI-режим (а не активный с оператором)
                ghost_header = (
                    "🤖 <b>AI-режим</b> — клиент общается с AI. "
                    "Если AI не справится — статус автоматически станет "
                    "'open'.\n\n" + ghost_header
                )

                # Клавиатура с кнопками админа (бан/закрыть/админ-панель)
                # [v3.5] Гость без user_id → web_guest_keyboard
                reply_markup = None
                try:
                    if tg_uid:
                        from app.keyboards import ticket_admin_keyboard
                        admin_url_env = os.getenv(
                            "ADMIN_PANEL_URL",
                            "https://ltefreemore.online/FixPakapassFGg_g34/users/",
                        )
                        reply_markup = ticket_admin_keyboard(
                            int(tg_uid), admin_url_env,
                        )
                    else:
                        from app.keyboards import web_guest_keyboard
                        reply_markup = web_guest_keyboard()
                except Exception as e:
                    logger.warning("WEB_CHAT ghost keyboard build: {}", e)

                try:
                    await bot.send_message(
                        chat_id=SUPPORT_CHAT_ID,
                        message_thread_id=ghost_topic_id,
                        text=ghost_header,
                        parse_mode="HTML",
                        reply_markup=reply_markup,
                        disable_notification=True,  # [v3.5] шапка тикета — всегда тихо
                    )
                except Exception as e:
                    logger.warning("WEB_CHAT ghost header failed: {}", e)

            # Сохраняем topic_id в БД
            await web_chat_db.set_visitor_topic(visitor_id, ghost_topic_id)
            # [v3.5] Статус и режим топика зависят от того, включён ли AI:
            #  - AI включён → status='closed', topic закрывается (AI-режим)
            #  - AI отключён → status='open', topic ОСТАЁТСЯ открытым
            #    (оператор сразу видит активный тикет, без AI-прослойки)
            ai_is_on = True
            try:
                from admin_web import ai_settings as _ais
                ai_is_on = _ais.is_enabled()
            except Exception:
                pass
            initial_status = "closed" if ai_is_on else "open"
            # [v3.5] quiet_send: True если status='closed' (тихо)
            quiet_send = (initial_status == "closed")
            try:
                await web_chat_db.set_visitor_status(visitor_id, initial_status)
                logger.info(
                    "WEB_CHAT ghost: visitor {} → status='{}' (AI {})",
                    visitor_id, initial_status,
                    "включён" if ai_is_on else "ОТКЛЮЧЁН",
                )
            except Exception as e:
                logger.warning(
                    "WEB_CHAT set status='{}' failed: {}",
                    initial_status, e,
                )
            # Чистим last_topic_id если был использован
            if visitor.get("last_topic_id"):
                try:
                    import aiosqlite
                    from app.database import DB_PATH as _DB
                    async with aiosqlite.connect(_DB) as db:
                        await db.execute(
                            "UPDATE web_visitors SET last_topic_id=NULL "
                            "WHERE visitor_id=?", (visitor_id,),
                        )
                        await db.commit()
                except Exception:
                    pass
            logger.info(
                "WEB_CHAT ghost-topic {} создан для visitor {}",
                ghost_topic_id, visitor_id,
            )
            # [v3.5] Закрываем topic в TG ТОЛЬКО если AI включён.
            # Если AI отключён → топик остаётся открытым в TG, потому что
            # клиент общается напрямую с оператором без AI-прослойки.
            if ai_is_on:
                # topic в группе помечается как «🔒 Закрытый», уезжает в архив
                # списка топиков. Когда AI эскалирует — переоткроем reopenForumTopic.
                try:
                    await bot.close_forum_topic(
                        chat_id=SUPPORT_CHAT_ID,
                        message_thread_id=ghost_topic_id,
                    )
                    # Иконка тоже на 'closed' (✅) — нейтральная
                    try:
                        from app import topic_icons
                        await topic_icons.set_topic_icon(
                            bot, SUPPORT_CHAT_ID, ghost_topic_id, "closed",
                        )
                    except Exception:
                        pass
                    logger.info(
                        "WEB_CHAT ghost-topic {} закрыт в TG (AI-режим)",
                        ghost_topic_id,
                    )
                except Exception as e:
                    logger.warning("WEB_CHAT не смог закрыть ghost-topic в TG: {}", e)
            else:
                # AI отключён → топик открытый, иконка 'web' (💻 — источник виджет)
                # Оператор сразу видит «нужно ответить клиенту»
                try:
                    from app import topic_icons
                    await topic_icons.set_topic_icon(
                        bot, SUPPORT_CHAT_ID, ghost_topic_id, "web",
                    )
                except Exception:
                    pass
                # Уведомление операторам что AI отключён
                try:
                    await bot.send_message(
                        chat_id=SUPPORT_CHAT_ID,
                        message_thread_id=ghost_topic_id,
                        text=(
                            "⚠️ <b>AI отключён</b> — клиент общается "
                            "напрямую с оператором.\n"
                            "<i>Тикет открыт сразу, ответы пишите в этот топик.</i>"
                        ),
                        parse_mode="HTML",
                        disable_notification=True,  # [v3.5] тихо
                    )
                except Exception as e:
                    logger.debug("WEB_CHAT AI-off notify: {}", e)
                logger.info(
                    "WEB_CHAT ghost-topic {} открытый (AI отключён)",
                    ghost_topic_id,
                )
        except Exception as e:
            logger.warning("WEB_CHAT не смог создать ghost-topic: {}", e)

    # [v3.5] Зеркалим сообщение клиента в ghost-topic.
    # Если topic удалён вручную — пересоздаём с историей и шлём в новый.
    if ghost_topic_id:
        try:
            await bot.send_message(
                chat_id=SUPPORT_CHAT_ID,
                message_thread_id=ghost_topic_id,
                text=f"💬 <b>Клиент:</b>\n{text[:3500]}",
                parse_mode="HTML",
                disable_notification=quiet_send,
            )
        except Exception as e:
            if _is_topic_invalid_error(e):
                # Topic был удалён вручную из TG — пересоздаём с историей
                logger.warning(
                    "WEB_CHAT mirror: topic {} удалён (visitor={}), "
                    "пересоздаю с историей",
                    ghost_topic_id, visitor_id,
                )
                new_id = await _recreate_ghost_topic_with_history(
                    bot, visitor, visitor_id,
                )
                if new_id:
                    ghost_topic_id = new_id
                    # Повторное зеркалирование текущего сообщения в новый topic
                    try:
                        await bot.send_message(
                            chat_id=SUPPORT_CHAT_ID,
                            message_thread_id=new_id,
                            text=f"💬 <b>Клиент:</b>\n{text[:3500]}",
                            parse_mode="HTML",
                disable_notification=quiet_send,
            )
                    except Exception as e2:
                        logger.warning(
                            "WEB_CHAT mirror в новый topic failed: {}", e2,
                        )
                else:
                    logger.error(
                        "WEB_CHAT mirror: не смог пересоздать topic для {}",
                        visitor_id,
                    )
            else:
                logger.warning("WEB_CHAT mirror client msg failed: {}", e)

    # ============================================================
    #  AI: пробуем ответить автоматически ДО создания топика
    # ============================================================
    # Условия чтобы дать AI шанс ответить:
    #   1) AI включён глобально
    #   2) Оператор ещё не подключался к этому визитёру
    #   3) Текст не слишком длинный
    # Если AI отвечает успешно (без escalate) — записываем ответ в БД,
    # зеркалируем в топик для контекста (если есть) и возвращаем ok.
    # Если AI эскалирует — продолжаем обычный flow ниже.
    ai_handled = False
    ai_response_text: str | None = None
    try:
        from admin_web import ai_settings
        if ai_settings.is_enabled() and len(text) <= 2000:
            operator_already_joined = False
            try:
                operator_already_joined = await web_chat_db.is_operator_joined(visitor_id)
            except Exception as e:
                logger.warning("WEB_CHAT is_operator_joined failed: {}", e)

            if not operator_already_joined:
                from app import ai_assistant
                # Достаём реальный tg user_id визитёра — для tools
                # (без него AI не сможет получить персональные данные).
                tg_uid = None
                try:
                    raw_uid = visitor.get("user_id")
                    if raw_uid:
                        tg_uid = int(raw_uid)
                except (TypeError, ValueError):
                    tg_uid = None
                logger.info(
                    "WEB_CHAT AI: пробую ответить visitor={} tg_user={}",
                    visitor_id, tg_uid or "—",
                )
                # source='webchat' → AI получит инструкции для веб-канала. [v3.5]
                result = await ai_assistant.ask(
                    visitor_id, text,
                    tg_user_id=tg_uid,
                    source="webchat",
                )
                # Имя ассистента которое клиент увидит в виджете.
                # Настраивается в админке /ai → блок «Имя ассистента».
                ai_sender = ai_settings.get_assistant_name()
                if result.ok and not result.escalate:
                    # AI справился — сохраняем ответ как сообщение от AI
                    ai_response_text = result.text
                    try:
                        await web_chat_db.add_message(
                            visitor_id, "out", ai_response_text,
                            sender=ai_sender,
                        )
                    except Exception as e:
                        logger.warning("WEB_CHAT не смог сохранить ответ AI: {}", e)

                    # [v3.5] Зеркало ответа AI в ghost-topic.
                    # При удалении topic — пересоздаём с историей.
                    if ghost_topic_id:
                        try:
                            await bot.send_message(
                                chat_id=SUPPORT_CHAT_ID,
                                message_thread_id=ghost_topic_id,
                                text=f"🤖 <b>AI:</b>\n{ai_response_text[:3500]}",
                                parse_mode="HTML",
                                disable_notification=quiet_send,
                            )
                        except Exception as e:
                            if _is_topic_invalid_error(e):
                                logger.warning(
                                    "WEB_CHAT AI mirror: topic {} удалён, "
                                    "пересоздаю с историей",
                                    ghost_topic_id,
                                )
                                new_id = await _recreate_ghost_topic_with_history(
                                    bot, visitor, visitor_id,
                                )
                                if new_id:
                                    ghost_topic_id = new_id
                                    try:
                                        await bot.send_message(
                                            chat_id=SUPPORT_CHAT_ID,
                                            message_thread_id=new_id,
                                            text=f"🤖 <b>AI:</b>\n"
                                                 f"{ai_response_text[:3500]}",
                                            parse_mode="HTML",
                                            disable_notification=quiet_send,
                                        )
                                    except Exception as e2:
                                        logger.warning(
                                            "WEB_CHAT AI mirror в новый: {}", e2,
                                        )
                            else:
                                logger.warning(
                                    "WEB_CHAT ghost-topic mirror AI failed: {}",
                                    e,
                                )

                    # [v3.5] Если AI указал маркер [PHOTO:qa_key] — копируем
                    # фото в папку визитёра и шлём ссылкой в виджет.
                    if result.photo_keys:
                        await _send_qa_photos_to_widget(
                            visitor_id, result.photo_keys, ai_sender,
                        )

                    ai_handled = True
                    logger.info(
                        "WEB_CHAT AI ответил visitor={} ({} tokens, photos={})",
                        visitor_id, result.tokens_in + result.tokens_out,
                        ",".join(result.photo_keys) if result.photo_keys else "—",
                    )
                else:
                    # [v3.5] Подробный лог: что именно случилось.
                    # result.ok=False означает ошибку провайдера (timeout/api).
                    # result.escalate=True — AI сам решил или force-keyword.
                    logger.warning(
                        "WEB_CHAT AI НЕ обработал visitor={}: ok={} escalate={} "
                        "error={!r} text={!r:.100}",
                        visitor_id, result.ok, result.escalate,
                        result.error, result.text,
                    )
                    # AI эскалирует. Если у него есть осмысленный текст
                    # (например "К сожалению по этому вопросу нужен оператор...")
                    # — отправим его клиенту перед эскалацией, чтобы он
                    # не остался без ответа.
                    if result.text and result.text.strip():
                        try:
                            await web_chat_db.add_message(
                                visitor_id, "out", result.text.strip(),
                                sender=ai_sender,
                            )
                            logger.info(
                                "WEB_CHAT AI escalate с текстом visitor={}: {!r:.60}",
                                visitor_id, result.text,
                            )
                        except Exception as e:
                            logger.warning(
                                "WEB_CHAT не смог сохранить текст AI при escalate: {}",
                                e,
                            )

                    # [v3.5] ЭСКАЛАЦИЯ: переключаем статус 'closed' → 'open' И
                    # ставим operator_joined=1 — AI больше НЕ отвечает.
                    # AI вернётся только после reset_operator_joined() при
                    # закрытии тикета оператором.
                    try:
                        await web_chat_db.set_visitor_status(visitor_id, "open")
                        # КЛЮЧЕВОЕ: блокируем AI до закрытия тикета
                        await web_chat_db.mark_operator_joined(visitor_id)
                        logger.info(
                            "WEB_CHAT тикет visitor={} переключён в 'open' "
                            "(эскалация) + AI заблокирован (operator_joined=1)",
                            visitor_id,
                        )
                    except Exception as e:
                        logger.warning("WEB_CHAT set_visitor_status failed: {}", e)

                    # Уведомление в ghost-topic — оператор видит «нужно вмешаться»
                    if ghost_topic_id and bot:
                        try:
                            # [v3.5] Переоткрываем topic в TG (был закрытый в AI-режиме)
                            try:
                                await bot.reopen_forum_topic(
                                    chat_id=SUPPORT_CHAT_ID,
                                    message_thread_id=ghost_topic_id,
                                )
                            except Exception as e:
                                if "TOPIC_NOT_MODIFIED" not in str(e):
                                    logger.warning(
                                        "WEB_CHAT reopen ghost-topic: {}", e,
                                    )
                            escalate_notif = (
                                "🚨 <b>AI запросил помощь оператора</b>\n\n"
                                "<i>Причина:</i> AI не смог самостоятельно "
                                "решить запрос.\n"
                                "<i>Статус тикета:</i> <code>open</code>\n\n"
                                "Ответьте в этом топике — клиент получит "
                                "сообщение в виджете на сайте."
                            )
                            await bot.send_message(
                                chat_id=SUPPORT_CHAT_ID,
                                message_thread_id=ghost_topic_id,
                                text=escalate_notif,
                                parse_mode="HTML",
                                disable_notification=True,  # [v3.5] тихо
                            )
                            # Меняем иконку на 'web' (💻 — источник виджет, нужен оператор)
                            try:
                                from app import topic_icons
                                await topic_icons.set_topic_icon(
                                    bot, SUPPORT_CHAT_ID, ghost_topic_id, "web",
                                )
                            except Exception:
                                pass
                        except Exception as e:
                            logger.warning("WEB_CHAT escalate notify: {}", e)

                    logger.info(
                        "WEB_CHAT AI escalate visitor={} (error={})",
                        visitor_id, result.error,
                    )
    except Exception as e:
        # Любая ошибка AI не должна сломать обработку сообщения
        logger.exception("WEB_CHAT AI block failed: {}", e)

    # [v3.5] Если AI справился — топик НЕ трогаем вообще.
    # Переписка с AI хранится в БД (web_messages), оператор её видит
    # в админке /webchats/{visitor_id}. В TG-топик AI-диалог зеркалится
    # ТОЛЬКО при эскалации (когда создаётся новый тикет с историей).
    # Раньше тут было зеркалирование при существующем topic_id — но это
    # засоряло старый топик после закрытия диалога и выглядело как
    # дублирование сообщений в TG.
    if ai_handled:
        logger.info(
            "WEB_CHAT AI handled полностью, в TG не зеркалим (visitor={})",
            visitor_id,
        )
        return _json_response(request, {"ok": True, "message_id": msg_id})

    # === ЗАЩИТА ОТ guest_xxx ===
    # Если visitor пока анонимный (нет user_id и email), но он только что
    # создан (за последние 5 сек) — есть шанс что identify ещё в пути.
    # Ждём до 3 сек чтобы дать identify прийти. После этого пере-загружаем
    # visitor — возможно identify уже сохранил данные.
    topic_id = visitor.get("topic_id")
    if not topic_id and not visitor.get("user_id") and not visitor.get("user_email"):
        try:
            # Сколько secunds назад создан visitor?
            from datetime import datetime as _dt
            created = visitor.get("created_at", "")
            if created:
                if isinstance(created, str):
                    try:
                        created_dt = _dt.fromisoformat(created.replace("Z", ""))
                    except Exception:
                        created_dt = _dt.utcnow()
                else:
                    created_dt = created
                age_seconds = (_dt.utcnow() - created_dt).total_seconds()
            else:
                age_seconds = 0

            # visitor "молодой" — ждём identify
            if age_seconds < 5:
                logger.info(
                    "WEB_CHAT send_message: visitor {} анонимный и молодой "
                    "(age={}s), жду identify до 3 сек...",
                    visitor_id, int(age_seconds),
                )
                for i in range(15):  # 15 * 200ms = 3 секунды
                    await asyncio.sleep(0.2)
                    refreshed = await web_chat_db.get_visitor(visitor_id)
                    if refreshed and (refreshed.get("user_id") or refreshed.get("user_email")):
                        visitor = refreshed
                        logger.info(
                            "WEB_CHAT identify пришёл за {}s, visitor={} user_id={} email={}",
                            (i+1)*0.2, visitor_id,
                            visitor.get("user_id"), visitor.get("user_email"),
                        )
                        break
                else:
                    logger.warning(
                        "WEB_CHAT identify НЕ пришёл за 3 сек для {}, "
                        "создаю топик как анонимный",
                        visitor_id,
                    )
        except Exception as e:
            logger.warning("WEB_CHAT wait-identify failed: {}", e)

    # [v3.5] Старый код "if is_first_message: header + history + клиент"
    # УБРАН — теперь всё зеркалится в реальном времени при создании ghost-topic:
    #   - шапка с инфой и кнопками админа (строки ~540-580)
    #   - сообщение клиента (строка ~619)
    #   - ответ AI (строка ~668)
    # Эскалация шлёт своё уведомление (строки ~743-780).
    # Никакого дополнительного зеркалирования здесь не нужно.

    return _json_response(request, {"ok": True, "message_id": msg_id})


def _format_topic_name(visitor: dict) -> str:
    """Имя топика для группы поддержки."""
    parts = ["🌐"]
    if visitor.get("user_id"):
        parts.append(f"user_{visitor['user_id']}")
    if visitor.get("user_name"):
        parts.append(visitor["user_name"][:30])
    if (not visitor.get("user_id")
            and not visitor.get("user_name")
            and visitor.get("user_email")):
        # Только email — используем его как идентификатор
        email = visitor["user_email"]
        local = email.split("@")[0][:20]
        parts.append(local)
    if (not visitor.get("user_id")
            and not visitor.get("user_name")
            and not visitor.get("user_email")):
        # Полностью анонимный — берём короткий хеш от visitor_id
        parts.append(f"guest_{visitor['visitor_id'][:6]}")
    return " ".join(parts)[:64]


async def _build_visitor_header(visitor: dict) -> str:
    """Шапка первого сообщения в топике с инфой о госте."""
    lines = ["🌐 <b>Новый чат с сайта</b>", ""]

    if visitor.get("user_id"):
        uid = int(visitor["user_id"])
        lines.append(f"👤 ID клиента: <code>{uid}</code>")
        # Ссылка на этого клиента в админке 3xUIStore
        admin_url = os.getenv(
            "ADMIN_PANEL_URL",
            "https://ltefreemore.online/FixPakapassFGg_g34/users/",
        )
        lines.append(f"🛠 <a href=\"{admin_url}{uid}\">Открыть в админке</a>")
    if visitor.get("user_name"):
        lines.append(f"📝 Имя: {visitor['user_name']}")
    if visitor.get("user_email"):
        lines.append(f"📧 Email: <code>{visitor['user_email']}</code>")
    lines.append(f"🔑 Visitor ID: <code>{visitor['visitor_id']}</code>")
    # Реферер показываем мелким шрифтом и только если он реально информативен —
    # не дублируем реф-ссылку которая ничего полезного оператору не даёт
    if visitor.get("referer"):
        ref = visitor['referer']
        # Чистим реф-параметры
        if "?ref=" in ref:
            ref = ref.split("?ref=")[0]
        elif "?" in ref:
            # Оставляем только path без query — query обычно засоряет
            ref_clean = ref.split("?")[0]
            if len(ref_clean) > 15:
                ref = ref_clean
        lines.append(f"<i>📄 С страницы: {ref[:100]}</i>")
    if visitor.get("user_agent"):
        ua = visitor['user_agent']
        ua_short = ua[:80] + ("..." if len(ua) > 80 else "")
        lines.append(f"<i>💻 Браузер: {ua_short}</i>")

    # === ПОДГРУЗКА ДАННЫХ ИЗ 3xUIStore ===
    # Если у нас есть user_id (Telegram ID) — подтягиваем полный профиль
    # с подпиской, провайдером, лимитом устройств и т.д.
    # build_ticket_info_block работает асинхронно и сама ходит в админку 3xUIStore.
    if visitor.get("user_id"):
        try:
            from app import admin_panel
            uid = int(visitor["user_id"])
            extra = await admin_panel.build_ticket_info_block(uid)
            if extra:
                lines.append("")
                lines.append(extra)
                logger.info(
                    "web_chat: подгрузил данные 3xUIStore для user_id={} "
                    "({} символов)", uid, len(extra),
                )
            else:
                # Пустая строка = клиент не найден или ADMIN_PASSWORD пуст
                logger.warning(
                    "web_chat: 3xUIStore вернул пустой блок для user_id={} — "
                    "проверь ADMIN_BASE_URL и есть ли этот клиент в админке",
                    uid,
                )
                lines.append("")
                lines.append(
                    "⚠️ <i>Клиент не найден в 3xUIStore "
                    f"(<code>{uid}</code>). Возможно неверный ADMIN_BASE_URL "
                    "или клиент только что зарегистрирован.</i>"
                )
        except Exception as e:
            logger.exception("web_chat: failed to build admin info block: {}", e)
            lines.append("")
            lines.append(f"⚠️ <i>Ошибка подгрузки данных: {str(e)[:80]}</i>")

    lines.append("")
    lines.append("<i>↩ Отвечайте в этом топике — ваши сообщения уйдут клиенту "
                 "прямо на сайт.</i>")
    return "\n".join(lines)


# ============================================================
#  GET /api/chat/poll
# ============================================================

async def poll_messages(request: web.Request) -> web.Response:
    """
    Гость опрашивает новые сообщения.
    GET /api/chat/poll?visitor_id=...&since=N

    Returns: {ok, messages: [{id, direction, text, created_at, sender?}]}
    """
    visitor_id = request.query.get("visitor_id", "").strip()
    if not _VISITOR_ID_RE.match(visitor_id):
        return _error(request, "Невалидный visitor_id")

    try:
        since = int(request.query.get("since", "0"))
    except ValueError:
        since = 0

    if not await web_chat_db.visitor_exists(visitor_id):
        return _error(request, "Сессия не найдена", status=404)

    # Touch — это видим что клиент жив
    await web_chat_db.touch_visitor(visitor_id)

    messages = await web_chat_db.get_messages_since(visitor_id, since)

    # Пометим out-сообщения как доставленные
    out_ids = [m["id"] for m in messages if m["direction"] == "out"]
    if out_ids:
        await web_chat_db.mark_delivered(out_ids)

    return _json_response(request, {"ok": True, "messages": messages})


# ============================================================
#  GET /api/chat/health
# ============================================================

async def health(request: web.Request) -> web.Response:
    return _json_response(request, {"ok": True, "ts": datetime.utcnow().isoformat()})


# ============================================================
#  POST /api/chat/leave — клиент закрыл вкладку (beacon)
# ============================================================

async def leave_chat(request: web.Request) -> web.Response:
    """
    Клиент закрыл вкладку с виджетом. Вызывается через
    navigator.sendBeacon('/api/chat/leave', ...). Если у клиента
    есть недоставленные сообщения от оператора — уведомляем оператора
    в TG-топик что клиент ушёл и НЕ увидел ответ.

    Сам диалог НЕ закрываем — клиент может вернуться, visitor_id
    остаётся, история переписки сохраняется.

    Beacon-запросы не возвращают ответ клиенту — отвечаем 204 No Content.
    """
    # Beacon шлёт application/json или text/plain — пробуем оба
    try:
        body = await request.json()
    except Exception:
        try:
            raw = await request.text()
            import json as _json
            body = _json.loads(raw) if raw else {}
        except Exception:
            body = {}

    visitor_id = (body.get("visitor_id") or "").strip()
    if not _VISITOR_ID_RE.match(visitor_id):
        return web.Response(status=204)

    try:
        await _notify_topic_about_offline(visitor_id, reason="closed_tab")
    except Exception as e:
        logger.warning("leave_chat: notify failed for {}: {}", visitor_id, e)

    return web.Response(status=204)


async def _notify_topic_about_offline(
    visitor_id: str,
    reason: str = "closed_tab",
) -> None:
    """
    Шлёт уведомление в TG-топик если у визитёра есть недоставленные
    out-сообщения. Помечает их как notified_offline=1 чтобы не слать
    повторно.

    reason:
      'closed_tab' — клиент закрыл вкладку (beacon)
      'inactive'   — клиент неактивен N минут (фоновая задача)
    """
    visitor = await web_chat_db.get_visitor(visitor_id)
    if not visitor or not visitor.get("topic_id"):
        return

    undelivered = await web_chat_db.get_undelivered_for_visitor(visitor_id)
    if not undelivered:
        return  # клиент всё видел или мы уже уведомляли

    topic_id = visitor["topic_id"]
    msg_ids = [m["id"] for m in undelivered]

    if reason == "closed_tab":
        header = (
            "👋 <b>Клиент закрыл вкладку</b>\n"
            "Он не успел увидеть твой ответ."
        )
    else:
        header = (
            "💤 <b>Клиент не активен на сайте</b>\n"
            "Он не увидел твой ответ уже больше 2 минут."
        )

    parts = [header, ""]
    parts.append(f"Не доставлено сообщений: <b>{len(undelivered)}</b>")
    # Покажем краткую сводку текстов
    for m in undelivered[:3]:
        text = (m.get("text") or "").strip()
        kind = m.get("attachment_kind") or ""
        if kind == "photo":
            preview = "📷 [фото]" + (f" — {text[:60]}" if text else "")
        else:
            preview = text[:80] if text else "—"
        parts.append(f"• <i>{html_escape(preview)}</i>")
    if len(undelivered) > 3:
        parts.append(f"… ещё {len(undelivered) - 3}")

    parts.append("")
    parts.append(
        "<i>Сообщения сохранены — когда клиент откроет виджет снова, "
        "он их увидит.</i>"
    )
    text_to_send = "\n".join(parts)

    # Шлём через aiogram-bot (сохранён при старте сервера)
    try:
        if _bot_instance is None:
            logger.warning("_notify_topic_about_offline: bot не инициализирован")
            return
        await _bot_instance.send_message(
            chat_id=SUPPORT_CHAT_ID,
            message_thread_id=topic_id,
            text=text_to_send,
            parse_mode="HTML",
            disable_notification=True,  # [v3.5] тихо
        )
        await web_chat_db.mark_notified_offline(msg_ids)
        logger.info(
            "OFFLINE_NOTIFY sent: visitor={} topic={} msgs={} reason={}",
            visitor_id, topic_id, len(msg_ids), reason,
        )
    except Exception as e:
        logger.warning(
            "_notify_topic_about_offline send failed: visitor={} {}",
            visitor_id, e,
        )


def html_escape(s: str) -> str:
    return (
        (s or "")
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


# ============================================================
#  POST /api/chat/close — клиент завершает диалог
# ============================================================

async def close_chat(request: web.Request) -> web.Response:
    """
    Клиент жмёт «Завершить диалог» в виджете.
    Новая логика (v3.0):
    1) Уведомляем оператора в Telegram-топик
    2) Архивируем топик (close_forum_topic)
    3) Привязка user_id/email СОХРАНЯЕТСЯ — чтобы при возвращении
       клиента мы открыли ТОТ ЖЕ топик (через reopen), а не новый
    4) Локально клиент получает новый visitor_id (виджет полностью
       перезапускается), но при identify через user_id мы найдём его
       старого visitor и направим в его же топик.

    Если оператор хочет полной отвязки — это делается отдельной
    кнопкой «Закрыть диспут» в Telegram-топике (cb_close_ticket).
    """
    try:
        body = await request.json()
    except Exception:
        return _error(request, "Невалидный JSON")

    visitor_id = (body.get("visitor_id") or "").strip()
    if not _VISITOR_ID_RE.match(visitor_id):
        return _error(request, "Невалидный visitor_id")

    visitor = await web_chat_db.get_visitor(visitor_id)
    if not visitor:
        return _error(request, "Сессия не найдена", status=404)

    topic_id = visitor.get("topic_id")
    bot: Bot | None = request.app.get("bot")

    if topic_id and bot and SUPPORT_CHAT_ID:
        try:
            await bot.send_message(
                chat_id=SUPPORT_CHAT_ID,
                message_thread_id=topic_id,
                text="🔒 <i>Клиент завершил диалог в виджете.</i>",
                parse_mode="HTML",
                disable_notification=True,  # [v3.5] тихо
            )
        except Exception as e:
            logger.warning("close_chat: send notification failed: {}", e)

        try:
            await bot.close_forum_topic(
                chat_id=SUPPORT_CHAT_ID,
                message_thread_id=topic_id,
            )
            logger.info(
                "WEB_CHAT close (client): топик {} архивирован для visitor {} "
                "(привязка user_id сохранена)",
                topic_id, visitor_id,
            )
        except Exception as e:
            logger.warning("close_chat: close_forum_topic failed: {}", e)

    # Сообщение в БД для истории
    await web_chat_db.add_message(
        visitor_id, "out", "[Диалог завершён клиентом]",
        sender="система",
    )

    # [v3.5] КЛЮЧЕВОЕ: сбрасываем status='closed' + operator_joined=0
    # Иначе если до этого была эскалация (status='open'), то когда клиент
    # вернётся и напишет — все сообщения в TG будут со звуком.
    # И AI бы не отвечал (operator_joined=1).
    try:
        await web_chat_db.reset_operator_joined(visitor_id)
        from app import ai_assistant
        await ai_assistant.clear_history(visitor_id)
        logger.info(
            "WEB_CHAT close_chat: visitor {} → status='closed', "
            "operator_joined=0, AI history cleared",
            visitor_id,
        )
    except Exception as e:
        logger.warning("close_chat: reset state failed: {}", e)

    # ВАЖНО: НЕ сбрасываем topic_id и НЕ отвязываем user_id.
    # При возврате клиента (новый identify) сервер найдёт того же visitor
    # по user_id, увидит сохранённый topic_id, попробует переоткрыть его.

    return _json_response(request, {"ok": True})


# ============================================================
#  POST /api/chat/upload — приём фото от гостя
# ============================================================

UPLOAD_DIR_NAME = "web_uploads"
UPLOAD_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "data", UPLOAD_DIR_NAME,
)
os.makedirs(UPLOAD_DIR, exist_ok=True)

MAX_PHOTO_SIZE = 8 * 1024 * 1024  # 8 МБ
ALLOWED_PHOTO_EXT = {".jpg", ".jpeg", ".png", ".gif", ".webp"}


async def _send_qa_photos_to_widget(
    visitor_id: str,
    qa_keys: list[str],
    ai_sender: str,
) -> None:
    """
    [v3.5] Копирует фото из QA в папку визитёра и сохраняет как
    сообщения с attachment_url. Виджет автоматически их отрисует.
    Лимит — 5 фото на ответ (защита от спама).
    """
    import shutil
    import uuid

    from app import ai_assistant

    visitor_dir = os.path.join(UPLOAD_DIR, visitor_id)
    os.makedirs(visitor_dir, exist_ok=True)

    photos_sent = 0
    for qa_key in qa_keys:
        try:
            src_paths = await ai_assistant.get_qa_photo_paths(qa_key)
            if not src_paths:
                logger.info(
                    "WEB_CHAT AI запросил [PHOTO:{}] но фото нет", qa_key,
                )
                continue
            for src_path in src_paths:
                if photos_sent >= 5:
                    logger.info("WEB_CHAT лимит 5 фото на ответ AI достигнут")
                    return
                if not os.path.isfile(src_path):
                    logger.warning(
                        "WEB_CHAT фото {} из QA {} не существует",
                        src_path, qa_key,
                    )
                    continue
                # Копируем файл в папку визитёра под новым именем
                ext = os.path.splitext(src_path)[1].lower() or ".jpg"
                file_id = uuid.uuid4().hex[:16]
                dst_path = os.path.join(visitor_dir, file_id + ext)
                try:
                    shutil.copyfile(src_path, dst_path)
                except Exception as e:
                    logger.warning(
                        "WEB_CHAT не смог скопировать фото {}: {}",
                        src_path, e,
                    )
                    continue
                rel_url = f"/api/chat/file/{visitor_id}/{file_id}{ext}"
                try:
                    await web_chat_db.add_message(
                        visitor_id, "out", "",
                        sender=ai_sender,
                        attachment_url=rel_url,
                        attachment_kind="photo",
                    )
                    photos_sent += 1
                except Exception as e:
                    logger.warning(
                        "WEB_CHAT не смог сохранить сообщение с фото: {}", e,
                    )
        except Exception as e:
            logger.warning(
                "WEB_CHAT ошибка отправки фото [PHOTO:{}]: {}", qa_key, e,
            )


async def upload_photo(request: web.Request) -> web.Response:
    """
    Гость отправляет фото через multipart.
    Form fields: visitor_id (text), file (binary)

    Returns: {ok, message_id, url, kind}
    """
    logger.info("WEB_CHAT upload_photo: запрос принят, "
                "content-type={!r}, content-length={!r}",
                request.content_type, request.content_length)
    try:
        reader = await request.multipart()
    except Exception as e:
        logger.exception("WEB_CHAT upload: multipart parse failed: {}", e)
        return _error(request, f"Не удалось прочитать multipart: {e}")

    visitor_id = None
    file_bytes = None
    file_ext = None
    file_name = None
    caption = ""  # [v3.5] подпись к фото

    while True:
        part = await reader.next()
        if part is None:
            break
        if part.name == "visitor_id":
            visitor_id = (await part.text()).strip()
        elif part.name == "caption":
            # [v3.5] Текстовая подпись к фото (опционально)
            caption = (await part.text()).strip()[:1000]
        elif part.name == "file":
            file_name = (part.filename or "").lower()
            # Размер контролируем по мере чтения
            buf = bytearray()
            while True:
                chunk = await part.read_chunk(1024 * 64)
                if not chunk:
                    break
                buf.extend(chunk)
                if len(buf) > MAX_PHOTO_SIZE:
                    return _error(request, "Файл слишком большой (>8 МБ)", status=413)
            file_bytes = bytes(buf)

    # Валидация
    if not visitor_id or not _VISITOR_ID_RE.match(visitor_id):
        return _error(request, "Невалидный visitor_id")
    if not await web_chat_db.visitor_exists(visitor_id):
        return _error(request, "Сессия не найдена", status=404)
    if not file_bytes:
        return _error(request, "Файл не получен")

    # [v3.5] Rate-limit на загрузку фото — отдельно от текста
    from app import security
    allowed, rl_reason = await security.check_upload_rate(visitor_id)
    if not allowed:
        logger.info("WEB_CHAT upload rate-limit visitor={}: {}", visitor_id, rl_reason)
        return _error(
            request, "⏱ Слишком много фото подряд. Попробуйте через минуту.",
            status=429,
        )
    await security.record_upload(visitor_id)

    # [v3.5] Защита от prompt injection в подписи к фото
    if caption:
        caption, _inj_reason = await security.sanitize_user_input(caption)
        if _inj_reason:
            logger.warning(
                "WEB_CHAT upload injection visitor={}: {}",
                visitor_id, _inj_reason,
            )

    # Расширение
    if file_name:
        for ext in ALLOWED_PHOTO_EXT:
            if file_name.endswith(ext):
                file_ext = ext
                break
    if not file_ext:
        # По magic bytes
        if file_bytes[:3] == b"\xff\xd8\xff":
            file_ext = ".jpg"
        elif file_bytes[:8] == b"\x89PNG\r\n\x1a\n":
            file_ext = ".png"
        elif file_bytes[:6] in (b"GIF87a", b"GIF89a"):
            file_ext = ".gif"
        elif file_bytes[:4] == b"RIFF" and file_bytes[8:12] == b"WEBP":
            file_ext = ".webp"
        else:
            return _error(request, "Неподдерживаемый формат файла")

    # Rate-limit: используем общий счётчик сообщений
    recent_count = await web_chat_db.count_recent_messages(visitor_id, minutes=60)
    if recent_count >= MAX_MESSAGES_PER_HOUR:
        return _error(
            request,
            f"Слишком много сообщений. Подождите час (лимит: {MAX_MESSAGES_PER_HOUR}/ч)",
            status=429,
        )

    # Сохраняем
    import secrets as _secrets
    visitor_dir = os.path.join(UPLOAD_DIR, visitor_id)
    os.makedirs(visitor_dir, exist_ok=True)
    file_id = _secrets.token_urlsafe(12)
    file_path = os.path.join(visitor_dir, file_id + file_ext)
    with open(file_path, "wb") as f:
        f.write(file_bytes)

    # URL для виджета — относительный, виджет добавит base
    rel_url = f"/api/chat/file/{visitor_id}/{file_id}{file_ext}"

    # [v3.5] В БД сохраняем фото с подписью (если есть caption)
    msg_id = await web_chat_db.add_message(
        visitor_id, "in", caption or "",
        attachment_url=rel_url,
        attachment_kind="photo",
    )

    # Telegram-топик
    visitor = await web_chat_db.get_visitor(visitor_id)

    # [v3.5] Создаём ghost-topic СРАЗУ (даже если AI справится) и зеркалим
    # туда фото клиента. Топик с пометкой «🌐🤖 Веб-чат» — оператор видит
    # переписку в реальном времени, даже когда работает только AI.
    bot: Bot | None = request.app.get("bot")
    ghost_topic_id: int | None = visitor.get("topic_id") if visitor else None
    # [v3.5] quiet_send: глобальная переменная функции (см. send_message)
    quiet_send = True
    if visitor:
        quiet_send = (visitor.get("status", "closed") != "open")
    if bot and SUPPORT_CHAT_ID and visitor and not ghost_topic_id:
        # [v3.5] ЖЁСТКАЯ ТИШИНА при создании нового тикета:
        # quiet_send = True ВСЕГДА, независимо от AI on/off.
        quiet_send = True  # жёстко тихо при создании
        try:
            last_topic_id = visitor.get("last_topic_id")
            if last_topic_id:
                # Пробуем переоткрыть старый
                try:
                    try:
                        await bot.reopen_forum_topic(
                            chat_id=SUPPORT_CHAT_ID,
                            message_thread_id=last_topic_id,
                        )
                    except Exception as e:
                        if "TOPIC_NOT_MODIFIED" not in str(e):
                            raise
                    # Пробное сообщение — если топик удалён, упадёт
                    await bot.send_message(
                        chat_id=SUPPORT_CHAT_ID,
                        message_thread_id=last_topic_id,
                        text="🔓 <b>Клиент вернулся</b> (с фото)",
                        parse_mode="HTML",
                        disable_notification=True,  # [v3.5] тихо
                    )
                    ghost_topic_id = last_topic_id
                except Exception:
                    ghost_topic_id = None
            # Если переоткрыть не удалось — создаём новый
            if not ghost_topic_id:
                tg_uid = visitor.get("user_id")
                topic_name = _build_web_topic_name(visitor)
                from app import topic_icons
                icon_id = None
                try:
                    _, icon_id = topic_icons.get_icon_id("web")
                except Exception:
                    pass
                kw = {"name": topic_name}
                if icon_id:
                    kw["icon_custom_emoji_id"] = icon_id
                topic = await bot.create_forum_topic(
                    chat_id=SUPPORT_CHAT_ID, **kw,
                )
                ghost_topic_id = topic.message_thread_id

                # [v3.5] ПОЛНАЯ шапка с данными подписки (через _build_visitor_header
                # которая вызывает admin_panel.build_ticket_info_block)
                try:
                    ghost_header = await _build_visitor_header(visitor)
                except Exception as e:
                    logger.warning("WEB_CHAT upload ghost _build_visitor_header: {}", e)
                    ghost_header = (
                        f"🌐🤖 <b>Веб-чат #{visitor_id[:8]}</b>\n"
                        f"<b>Visitor ID:</b> <code>{visitor_id}</code>"
                    )
                # Префикс что это AI-режим
                ghost_header = (
                    "🤖 <b>AI-режим</b> — клиент общается с AI. "
                    "Если AI не справится — статус автоматически станет "
                    "'open'.\n\n" + ghost_header
                )

                # Клавиатура с кнопками админа
                # [v3.5] Для гостя без TG user_id — упрощённая клавиатура
                # (только закрыть/тихо/авто-ответы).
                reply_markup_ghost = None
                try:
                    if tg_uid:
                        from app.keyboards import ticket_admin_keyboard
                        admin_url_env = os.getenv(
                            "ADMIN_PANEL_URL",
                            "https://ltefreemore.online/FixPakapassFGg_g34/users/",
                        )
                        reply_markup_ghost = ticket_admin_keyboard(
                            int(tg_uid), admin_url_env,
                        )
                    else:
                        from app.keyboards import web_guest_keyboard
                        reply_markup_ghost = web_guest_keyboard()
                except Exception as e:
                    logger.warning("WEB_CHAT upload ghost keyboard: {}", e)

                try:
                    await bot.send_message(
                        chat_id=SUPPORT_CHAT_ID,
                        message_thread_id=ghost_topic_id,
                        text=ghost_header,
                        parse_mode="HTML",
                        reply_markup=reply_markup_ghost,
                        disable_notification=True,  # [v3.5] шапка тикета — всегда тихо
                    )
                except Exception as e:
                    logger.warning("WEB_CHAT upload ghost header: {}", e)
            await web_chat_db.set_visitor_topic(visitor_id, ghost_topic_id)
            # [v3.5] Статус зависит от AI: включён → 'closed', отключён → 'open'
            ai_is_on = True
            try:
                from admin_web import ai_settings as _ais
                ai_is_on = _ais.is_enabled()
            except Exception:
                pass
            initial_status = "closed" if ai_is_on else "open"
            # [v3.5] quiet_send: True если status='closed' (тихо)
            quiet_send = (initial_status == "closed")
            try:
                await web_chat_db.set_visitor_status(visitor_id, initial_status)
                logger.info(
                    "WEB_CHAT upload ghost: visitor {} → status='{}' (AI {})",
                    visitor_id, initial_status,
                    "включён" if ai_is_on else "ОТКЛЮЧЁН",
                )
            except Exception as e:
                logger.warning(
                    "WEB_CHAT upload set status='{}': {}",
                    initial_status, e,
                )
            # Очищаем last_topic_id
            try:
                import aiosqlite as _aio
                from app.database import DB_PATH as _DB
                async with _aio.connect(_DB) as db:
                    await db.execute(
                        "UPDATE web_visitors SET last_topic_id=NULL "
                        "WHERE visitor_id=?", (visitor_id,),
                    )
                    await db.commit()
            except Exception:
                pass
            logger.info(
                "WEB_CHAT upload: ghost-topic {} создан для visitor {}",
                ghost_topic_id, visitor_id,
            )
            # [v3.5] Закрываем topic только если AI включён
            if ai_is_on:
                try:
                    await bot.close_forum_topic(
                        chat_id=SUPPORT_CHAT_ID,
                        message_thread_id=ghost_topic_id,
                    )
                    try:
                        from app import topic_icons
                        await topic_icons.set_topic_icon(
                            bot, SUPPORT_CHAT_ID, ghost_topic_id, "closed",
                        )
                    except Exception:
                        pass
                    logger.info(
                        "WEB_CHAT upload ghost-topic {} закрыт в TG (AI-режим)",
                        ghost_topic_id,
                    )
                except Exception as e:
                    logger.warning(
                        "WEB_CHAT upload не смог закрыть topic: {}", e,
                    )
            else:
                # AI отключён → топик открытый, иконка 'web' (💻 — источник виджет)
                try:
                    from app import topic_icons
                    await topic_icons.set_topic_icon(
                        bot, SUPPORT_CHAT_ID, ghost_topic_id, "web",
                    )
                except Exception:
                    pass
                logger.info(
                    "WEB_CHAT upload ghost-topic {} открытый (AI отключён)",
                    ghost_topic_id,
                )
        except Exception as e:
            logger.warning("WEB_CHAT upload ghost-topic failed: {}", e)
            ghost_topic_id = None

    # [v3.5] Зеркалим фото клиента в ghost-topic СРАЗУ
    if ghost_topic_id and bot:
        try:
            from aiogram.types import FSInputFile as _FS
            tg_cap = "📷 <b>Клиент прислал фото</b>"
            if caption:
                import html as _h
                tg_cap += f"\n💬 {_h.escape(caption[:800])}"
            await bot.send_photo(
                chat_id=SUPPORT_CHAT_ID,
                message_thread_id=ghost_topic_id,
                photo=_FS(file_path),
                caption=tg_cap,
                parse_mode="HTML",
                disable_notification=quiet_send,  # [v3.5] тихо/звук по статусу
            )
        except Exception as e:
            logger.warning("WEB_CHAT upload mirror photo: {}", e)

    # [v3.5] Если AI включён и оператор ещё не подключился — пробуем
    # сначала AI с фото. Если AI справится — топик не создаём,
    # переписка остаётся только в виджете.
    ai_handled_photo = False
    try:
        from admin_web import ai_settings
        ai_on = ai_settings.is_enabled()
        op_joined = bool(visitor and visitor.get("operator_joined"))
        logger.info(
            "WEB_CHAT upload_photo: ai_enabled={}, operator_joined={}, "
            "file_size={}, caption={}",
            ai_on, op_joined, len(file_bytes), caption[:100] if caption else "",
        )
        if ai_on and visitor and not op_joined:
            from app import ai_assistant
            import base64 as _b64
            # [v3.5] Лимит увеличен до 10 МБ — современные смартфоны делают
            # большие скриншоты (5 МБ часто не хватало).
            if len(file_bytes) <= 10 * 1024 * 1024:
                b64 = _b64.b64encode(file_bytes).decode("ascii")
                # Определяем MIME по extension
                mime_map = {".jpg": "jpeg", ".jpeg": "jpeg", ".png": "png",
                            ".gif": "gif", ".webp": "webp"}
                mime = mime_map.get(file_ext.lower(), "jpeg")
                image_url = f"data:image/{mime};base64,{b64}"
                logger.info(
                    "WEB_CHAT upload_photo: ВЫЗЫВАЮ AI vision "
                    "(mime={}, base64={} КБ, caption={!r})",
                    mime, len(b64) // 1024,
                    caption[:80] if caption else "(нет)",
                )
                tg_uid = None
                try:
                    raw_uid = visitor.get("user_id")
                    if raw_uid:
                        tg_uid = int(raw_uid)
                except (TypeError, ValueError):
                    pass
                result = await ai_assistant.ask(
                    visitor_id,
                    caption or "Посмотри что на фото и помоги клиенту.",
                    tg_user_id=tg_uid,
                    source="webchat",
                    image_data_url=image_url,
                )
                ai_sender = ai_settings.get_assistant_name()
                if result.ok and not result.escalate:
                    # AI справился — сохраняем ответ, в TG ничего не идёт
                    try:
                        await web_chat_db.add_message(
                            visitor_id, "out", result.text,
                            sender=ai_sender,
                        )
                        # [v3.5] Зеркало ответа AI в ghost-topic
                        if ghost_topic_id and bot:
                            try:
                                await bot.send_message(
                                    chat_id=SUPPORT_CHAT_ID,
                                    message_thread_id=ghost_topic_id,
                                    text=f"🤖 <b>AI:</b>\n{result.text[:3500]}",
                                    parse_mode="HTML",
                                disable_notification=quiet_send,
                            )
                            except Exception as e:
                                logger.warning(
                                    "WEB_CHAT upload mirror AI: {}", e,
                                )
                        # Фото из QA если AI указал
                        if result.photo_keys:
                            await _send_qa_photos_to_widget(
                                visitor_id, result.photo_keys, ai_sender,
                            )
                        ai_handled_photo = True
                        logger.info(
                            "WEB_CHAT AI обработал фото от visitor={} "
                            "({} tokens)",
                            visitor_id, result.tokens_in + result.tokens_out,
                        )
                    except Exception as e:
                        logger.warning("WEB_CHAT save AI photo answer: {}", e)
                else:
                    # AI escalate — сохраним текст если есть
                    if result.text and result.text.strip():
                        try:
                            await web_chat_db.add_message(
                                visitor_id, "out", result.text.strip(),
                                sender=ai_sender,
                            )
                        except Exception as e:
                            logger.warning(
                                "WEB_CHAT save AI escalate-text: {}", e,
                            )
                    logger.info(
                        "WEB_CHAT AI escalate на фото от visitor={}",
                        visitor_id,
                    )
            else:
                logger.warning(
                    "WEB_CHAT upload_photo: фото слишком большое ({} байт, "
                    "лимит 10 МБ) — vision пропущен, отправляю в TG",
                    len(file_bytes),
                )
        else:
            # AI выключен или оператор уже подключился
            if not ai_on:
                logger.info(
                    "WEB_CHAT upload_photo: AI выключен, фото в TG-топик",
                )
            elif op_joined:
                logger.info(
                    "WEB_CHAT upload_photo: оператор подключён (operator_joined=True), "
                    "vision пропущен, фото в TG-топик",
                )
    except Exception as e:
        logger.warning("WEB_CHAT AI vision на фото упал: {}", e)

    # Если AI справился — топик не создаём
    if ai_handled_photo:
        return _json_response(request, {
            "ok": True, "message_id": msg_id,
            "attachment_url": rel_url,
        })

    # [v3.5] Старый блок создания topic + отправки фото удалён.
    # Теперь всё делает v3.5 ghost-topic блок выше — там фото уже
    # зеркалится через bot.send_photo(message_thread_id=ghost_topic_id).
    # Старый блок дублировал создание topic для гостей.

    return _json_response(request, {
        "ok": True,
        "message_id": msg_id,
        "url": rel_url,
        "kind": "photo",
    })


# ============================================================
#  GET /api/chat/file/<visitor_id>/<name> — отдача загруженных файлов
# ============================================================

async def serve_file(request: web.Request) -> web.Response:
    """Отдаёт загруженный файл клиенту/оператору."""
    visitor_id = request.match_info.get("visitor_id", "")
    filename = request.match_info.get("filename", "")
    if not _VISITOR_ID_RE.match(visitor_id):
        return web.Response(status=404)
    # Безопасность: запрещаем .. и /
    if "/" in filename or "\\" in filename or ".." in filename:
        return web.Response(status=400)
    # Проверяем расширение
    if not any(filename.lower().endswith(ext) for ext in ALLOWED_PHOTO_EXT):
        return web.Response(status=404)

    file_path = os.path.join(UPLOAD_DIR, visitor_id, filename)
    if not os.path.isfile(file_path):
        return web.Response(status=404)

    # Определяем content-type по расширению
    ext = os.path.splitext(filename)[1].lower()
    mime = {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".gif": "image/gif", ".webp": "image/webp",
    }.get(ext, "application/octet-stream")

    return web.FileResponse(
        file_path,
        headers={
            "Content-Type": mime,
            "Cache-Control": "public, max-age=3600",
            "Access-Control-Allow-Origin": "*",
        },
    )


# ============================================================
#  GET /api/chat/config — публичная конфигурация для виджета
# ============================================================

async def widget_config(request: web.Request) -> web.Response:
    """
    Возвращает только публичные настройки (цвета, тексты, позицию).
    Виджет загружает их при инициализации.
    Allowed_origins не отдаём — это серверная защита.
    """
    settings = await widget_settings.get_settings()
    # [v3.5] Имя ассистента — берётся из настроек /ai админки, общее с TG
    try:
        from admin_web import ai_settings as _ais
        _ai_name_for_widget = _ais.get_assistant_name() or ""
    except Exception:
        _ai_name_for_widget = ""
    public = {
        "primary_color": settings["primary_color"],
        "position": settings["position"],
        "brand_name": settings["brand_name"],
        "operator_label": settings.get("operator_label", "Оператор"),
        "ai_name": _ai_name_for_widget,
        "welcome_text": settings["welcome_text"],
        "placeholder": settings["placeholder"],
        "send_button_text": settings["send_button_text"],
        "offline_text": settings["offline_text"],
        "button_size": settings.get("button_size", "M"),
        "button_icon": settings.get("button_icon", "💬"),
        "button_shape": settings.get("button_shape", "circle"),
        "button_label": settings.get("button_label", "VPN Support"),
        "window_size": settings.get("window_size", "M"),
        "window_shape": settings.get("window_shape", "default"),
        "bubble_style": settings.get("bubble_style", "rounded"),
        "auto_open_seconds": settings.get("auto_open_seconds", 0),
        "sound_enabled": settings.get("sound_enabled", True),
        "uploads_enabled": settings.get("uploads_enabled", True),
        "operator_avatar": settings.get("operator_avatar", ""),
        "always_online": settings["always_online"],
        "work_hours_from": settings["work_hours_from"],
        "work_hours_to": settings["work_hours_to"],
        "work_timezone": settings["work_timezone"],
        "allow_identify": settings["allow_identify"],

        # v3.2 — кастомизация темы
        "window_opacity": settings.get("window_opacity", 1.0),
        "header_color": settings.get("header_color", ""),
        "header_gradient": settings.get("header_gradient", False),
        "header_color_to": settings.get("header_color_to", ""),
        "window_bg_color": settings.get("window_bg_color", ""),
        "window_bg_gradient": settings.get("window_bg_gradient", False),
        "window_bg_color_to": settings.get("window_bg_color_to", ""),
        "msg_out_color": settings.get("msg_out_color", ""),
        "msg_out_gradient": settings.get("msg_out_gradient", False),
        "msg_out_color_to": settings.get("msg_out_color_to", ""),
        "msg_in_color": settings.get("msg_in_color", ""),
        "msg_in_gradient": settings.get("msg_in_gradient", False),
        "msg_in_color_to": settings.get("msg_in_color_to", ""),
        "input_bg_color": settings.get("input_bg_color", ""),
    }
    return _json_response(request, {"ok": True, "config": public})


# ============================================================
#  GET /api/chat/widget.js — заглушка для Ответа 1A
# ============================================================

async def widget_js(request: web.Request) -> web.Response:
    """Возвращает widget.js — полноценный виджет чата."""
    # Берём API base из настроек если задан, иначе из заголовков запроса
    settings = await widget_settings.get_settings()
    saved_url = (settings.get("public_url") or "").strip().rstrip("/")
    if saved_url:
        api_base = f"{saved_url}/api/chat"
    else:
        proto = request.headers.get("X-Forwarded-Proto", "https")
        host = request.headers.get("X-Forwarded-Host") or request.headers.get("Host", "")
        api_base = f"{proto}://{host}/api/chat"

    js = WIDGET_JS_TEMPLATE.replace("{{API_BASE}}", api_base)
    return web.Response(
        body=js,
        content_type="application/javascript",
        headers={
            "Cache-Control": "public, max-age=60",  # короткий кеш, чтобы изменения URL быстро доходили
            "Access-Control-Allow-Origin": "*",
        },
    )


WIDGET_JS_TEMPLATE = r"""/*!
 * MyChat widget v1.0
 * Встраиваемый виджет чата для сайта.
 * Использование:
 *   <script src="https://example.com/api/chat/widget.js"></script>
 *   <script>
 *     MyChat.identify({user_id: 123, name: "Иван", email: "ivan@example.com"});
 *   </script>
 */
(function() {
  "use strict";

  if (window.MyChatLoaded) return;
  window.MyChatLoaded = true;

  var API = "{{API_BASE}}";
  var STORAGE_KEY = "mychat_visitor_id";
  var LAST_MSG_KEY = "mychat_last_msg_id";

  // Состояние
  var visitorId = null;
  var lastMessageId = 0;
  var config = null;
  var pollTimer = null;
  var isOpen = false;
  var pendingIdentify = null;
  var identifyCalled = false;  // для диагностики: был ли вызов identify хоть раз

  // ============================================================
  //  Утилиты
  // ============================================================

  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function formatTime(iso) {
    try {
      var d = new Date(iso.replace(" ", "T") + "Z");
      var hh = String(d.getHours()).padStart(2, "0");
      var mm = String(d.getMinutes()).padStart(2, "0");
      return hh + ":" + mm;
    } catch (e) {
      return "";
    }
  }

  function lsGet(key) {
    try { return localStorage.getItem(key); } catch (e) { return null; }
  }
  function lsSet(key, val) {
    try { localStorage.setItem(key, String(val)); } catch (e) {}
  }
  function ssGet(key) {
    try { return sessionStorage.getItem(key); } catch (e) { return null; }
  }
  function ssSet(key, val) {
    try { sessionStorage.setItem(key, String(val)); } catch (e) {}
  }
  function cookieGet(name) {
    try {
      var m = document.cookie.match(
        new RegExp("(^|; )" + name + "=([^;]+)")
      );
      return m ? decodeURIComponent(m[2]) : null;
    } catch (e) { return null; }
  }
  function cookieSet(name, val) {
    try {
      var d = new Date(Date.now() + 365 * 24 * 3600 * 1000);
      document.cookie = name + "=" + encodeURIComponent(val) +
        "; expires=" + d.toUTCString() + "; path=/; SameSite=Lax";
    } catch (e) {}
  }

  // window.name переживает reload в той же вкладке, и многие "clear storage"
  // скрипты его не трогают (потому что это устаревший механизм).
  function winNameGet(key) {
    try {
      var raw = window.name;
      if (!raw || !raw.startsWith("__mychat__:")) return null;
      var data = JSON.parse(raw.substring(11));
      return data[key] || null;
    } catch (e) { return null; }
  }
  function winNameSet(key, val) {
    try {
      var raw = window.name;
      var data = {};
      if (raw && raw.startsWith("__mychat__:")) {
        try { data = JSON.parse(raw.substring(11)); } catch (e) {}
      }
      data[key] = val;
      window.name = "__mychat__:" + JSON.stringify(data);
    } catch (e) {}
  }

  // IndexedDB — самое надёжное хранилище. Никакой `localStorage.clear()`
  // его не тронет.
  var _idbDB = null;
  function idbInit(cb) {
    try {
      var req = indexedDB.open("MyChat", 1);
      req.onupgradeneeded = function() {
        try { req.result.createObjectStore("kv"); } catch (e) {}
      };
      req.onsuccess = function() { _idbDB = req.result; cb && cb(); };
      req.onerror = function() { cb && cb(); };
    } catch (e) { cb && cb(); }
  }
  function idbGet(key, cb) {
    if (!_idbDB) return cb(null);
    try {
      var tx = _idbDB.transaction("kv", "readonly");
      var req = tx.objectStore("kv").get(key);
      req.onsuccess = function() { cb(req.result || null); };
      req.onerror = function() { cb(null); };
    } catch (e) { cb(null); }
  }
  function idbSet(key, val) {
    if (!_idbDB) return;
    try {
      var tx = _idbDB.transaction("kv", "readwrite");
      tx.objectStore("kv").put(val, key);
    } catch (e) {}
  }

  /**
   * Получает visitor_id СИНХРОННО из localStorage / cookie / sessionStorage / window.name.
   * IndexedDB читается асинхронно отдельно — там запасная копия.
   */
  function loadVisitorId() {
    return lsGet(STORAGE_KEY) ||
           cookieGet(STORAGE_KEY) ||
           ssGet(STORAGE_KEY) ||
           winNameGet(STORAGE_KEY) ||
           null;
  }

  /**
   * Сохраняет visitor_id во ВСЕ доступные хранилища одновременно.
   */
  function saveVisitorId(id) {
    if (!id) return;
    lsSet(STORAGE_KEY, id);
    cookieSet(STORAGE_KEY, id);
    ssSet(STORAGE_KEY, id);
    winNameSet(STORAGE_KEY, id);
    idbSet(STORAGE_KEY, id);
    console.log("[MyChat] visitor_id сохранён:", id);
  }

  function api(path, options) {
    options = options || {};
    options.headers = options.headers || {};
    options.headers["Content-Type"] = "application/json";
    if (visitorId) {
      options.headers["X-Visitor-Id"] = visitorId;
    }
    return fetch(API + path, options).then(function(r) {
      return r.json().catch(function() { return {ok: false}; });
    });
  }

  // ============================================================
  //  CSS
  // ============================================================

  function injectStyles() {
    var color = (config && config.primary_color) || "#ff8c42";
    var position = (config && config.position) || "bottom-right";
    var posCss = position === "bottom-left"
      ? "left: 20px;"
      : "right: 20px;";

    // ===== v3.2 — кастомные цвета и градиенты =====
    // Helper: вернуть background-CSS на основе настроек.
    // base — fallback цвет если ни одна настройка не задана.
    function bg(colorField, gradField, toField, base) {
      var c = config[colorField];
      if (!c) return base;
      if (config[gradField] && config[toField]) {
        return "linear-gradient(135deg, " + c + " 0%, " + config[toField] + " 100%)";
      }
      return c;
    }
    var headerBg   = bg("header_color",     "header_gradient",     "header_color_to",     color);
    var windowBg   = bg("window_bg_color",  "window_bg_gradient",  "window_bg_color_to",
                        "linear-gradient(180deg, #f7f8fa 0%, #f1f2f5 100%)");
    // msg_in = от ОПЕРАТОРА (в виджете слева, mychat-msg-in в коде = "получено")
    var msgInBg    = bg("msg_in_color",     "msg_in_gradient",     "msg_in_color_to",     color);
    var msgInColor = "#fff";
    // msg_out = от КЛИЕНТА (в виджете справа)
    var msgOutBg   = bg("msg_out_color",    "msg_out_gradient",    "msg_out_color_to",    "#fff");
    // Если кастомный цвет для out-сообщений тёмный — белый текст; иначе тёмный
    var msgOutColor = (config.msg_out_color ? "#fff" : "#2a2a2a");
    var inputBg    = (config.input_bg_color || "#ffffff");

    // Прозрачность окна
    var opacity = config.window_opacity;
    if (typeof opacity !== "number" || isNaN(opacity)) opacity = 1;
    opacity = Math.max(0.3, Math.min(1, opacity));

    // Размер кнопки-launcher
    var btnSize = (config.button_size === "S") ? 48
                : (config.button_size === "L") ? 72
                : 60;
    var btnFont = Math.round(btnSize * 0.45);

    // Форма кнопки
    var btnShape = config.button_shape || "circle";
    var btnRadius, btnWidth, btnHeight, btnPadding, btnDisplayLabel;
    if (btnShape === "pill") {
      // Прямоугольная с надписью
      btnRadius = "999px";
      btnWidth = "auto";
      btnHeight = btnSize + "px";
      btnPadding = "0 18px 0 14px";
      btnDisplayLabel = true;
    } else if (btnShape === "square") {
      // Квадратная с закруглением
      btnRadius = "14px";
      btnWidth = btnSize + "px";
      btnHeight = btnSize + "px";
      btnPadding = "0";
      btnDisplayLabel = false;
    } else if (btnShape === "squircle") {
      // Squircle — что-то среднее между квадратом и кругом
      btnRadius = "30%";
      btnWidth = btnSize + "px";
      btnHeight = btnSize + "px";
      btnPadding = "0";
      btnDisplayLabel = false;
    } else {
      // Круглая (по умолчанию)
      btnRadius = "50%";
      btnWidth = btnSize + "px";
      btnHeight = btnSize + "px";
      btnPadding = "0";
      btnDisplayLabel = false;
    }

    // Размер окна
    var winW = (config.window_size === "S") ? 340
             : (config.window_size === "L") ? 420
             : 380;
    var winH = (config.window_size === "S") ? 480
             : (config.window_size === "L") ? 640
             : 580;

    // Форма окна:
    //   default — стандартная (как сейчас)
    //   wide — шире на 25%, для длинных текстов (документация, переписка)
    //   rounded — очень мягкие закруглённые углы (28px)
    var ws = config.window_shape || "default";
    var winRadius = "18px";
    if (ws === "wide") {
      winW = Math.round(winW * 1.25);
      winRadius = "16px";
    } else if (ws === "rounded") {
      winRadius = "28px";
    }

    // Стиль пузырьков
    // rounded (по умолчанию): закруглённые с маленьким «хвостиком»
    // square: квадратные углы 6px
    // soft: очень мягкие плавные углы, без хвостика, фон полупрозрачный
    // minimal: без фона у входящих, только текст, тонкая граница у исходящих
    // bordered: с границей вокруг пузырька, без тени
    var bs = config.bubble_style || "rounded";
    var bubbleRadius, bubbleTailIn, bubbleTailOut,
        bubbleShadow, bubbleBorder, bubbleInExtra, bubbleOutExtra;

    if (bs === "square") {
      bubbleRadius = "6px";
      bubbleTailIn = "6px"; bubbleTailOut = "6px";
      bubbleShadow = "0 1px 2px rgba(0,0,0,.06)";
      bubbleBorder = "none";
      bubbleInExtra = ""; bubbleOutExtra = "";
    } else if (bs === "soft") {
      bubbleRadius = "22px";
      bubbleTailIn = "22px"; bubbleTailOut = "22px";
      bubbleShadow = "0 2px 6px rgba(0,0,0,.04)";
      bubbleBorder = "none";
      bubbleInExtra = ""; bubbleOutExtra = "";
    } else if (bs === "minimal") {
      bubbleRadius = "14px";
      bubbleTailIn = "14px"; bubbleTailOut = "14px";
      bubbleShadow = "none";
      bubbleBorder = "none";
      bubbleInExtra = "";
      bubbleOutExtra = "background: transparent !important; padding: 6px 4px !important; box-shadow: none !important;";
    } else if (bs === "bordered") {
      bubbleRadius = "16px";
      bubbleTailIn = "6px"; bubbleTailOut = "6px";
      bubbleShadow = "none";
      bubbleBorder = "1px solid rgba(0,0,0,.08)";
      bubbleInExtra = ""; bubbleOutExtra = "";
    } else {
      // rounded — по умолчанию
      bubbleRadius = "18px";
      bubbleTailIn = "5px"; bubbleTailOut = "5px";
      bubbleShadow = "0 1px 2px rgba(0,0,0,.06)";
      bubbleBorder = "none";
      bubbleInExtra = ""; bubbleOutExtra = "";
    }

    var css = ""
      + "#mychat-root { position: fixed; bottom: 20px; " + posCss
      + " z-index: 2147483000; font-family: -apple-system, BlinkMacSystemFont, "
      + " 'Segoe UI', Roboto, sans-serif; }"

      // Кнопка-launcher
      + "#mychat-button { width: " + btnWidth + "; height: " + btnHeight + "; "
      + " border-radius: " + btnRadius + "; padding: " + btnPadding + "; "
      + " background: " + color + "; color: #fff; border: none; "
      + " cursor: pointer; box-shadow: 0 6px 20px rgba(0,0,0,.20), "
      + " 0 0 0 1px rgba(255,255,255,.1) inset; display: inline-flex; align-items: center; "
      + " gap: 8px; justify-content: center; font-size: " + btnFont + "px; "
      + " font-family: inherit; "
      + " transition: transform .2s, box-shadow .2s; position: relative; }"
      + "#mychat-button:hover { transform: scale(1.06); box-shadow: 0 8px 26px rgba(0,0,0,.28); }"
      + "#mychat-button:active { transform: scale(.96); }"
      + "#mychat-button .mychat-btn-icon { line-height: 1; font-size: " + btnFont + "px; }"
      + "#mychat-button .mychat-btn-label { font-size: 15px; font-weight: 600; "
      + " letter-spacing: .2px; white-space: nowrap; }"
      + "#mychat-button .mychat-badge { position: absolute; top: -3px; right: -3px; "
      + " background: #ef4444; color: #fff; border-radius: 50%; min-width: 22px; height: 22px; "
      + " font-size: 11px; display: flex; align-items: center; justify-content: center; "
      + " font-weight: 700; border: 2px solid #fff; padding: 0 5px; box-sizing: border-box; }"

      // Окно
      + "#mychat-window { position: fixed; bottom: " + (btnSize + 32) + "px; " + posCss
      + " width: " + winW + "px; max-width: calc(100vw - 24px); height: " + winH + "px; "
      + " max-height: calc(100vh - 140px); background: #fff; border-radius: " + winRadius + "; "
      + " box-shadow: 0 16px 56px rgba(0,0,0,.22), 0 0 0 1px rgba(0,0,0,.05); "
      + " opacity: " + opacity + "; "
      + " display: flex; flex-direction: column; overflow: hidden; z-index: 2147483000; "
      + " animation: mychat-pop .25s ease-out; }"
      + "#mychat-window.hidden { display: none; }"
      + "@keyframes mychat-pop { from { opacity: 0; transform: translateY(20px) scale(.96); } "
      + " to { opacity: " + opacity + "; transform: translateY(0) scale(1); } }"

      // Шапка
      + "#mychat-header { background: " + headerBg + "; color: #fff; padding: 14px 12px 14px 16px; "
      + " display: flex; align-items: center; justify-content: space-between; flex-shrink: 0; "
      + " box-shadow: 0 2px 8px rgba(0,0,0,.06); position: relative; }"
      + ".mychat-header-info { display: flex; align-items: center; gap: 12px; min-width: 0; }"
      + ".mychat-header-avatar { width: 38px; height: 38px; border-radius: 50%; "
      + " background: rgba(255,255,255,.22); display: flex; align-items: center; "
      + " justify-content: center; font-weight: 700; font-size: 16px; "
      + " box-shadow: 0 0 0 2px rgba(255,255,255,.15); overflow: hidden; flex-shrink: 0; }"
      + ".mychat-header-avatar img { width: 100%; height: 100%; object-fit: cover; }"
      + ".mychat-header-title { font-weight: 600; font-size: 15px; line-height: 1.2; "
      + " white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }"
      + ".mychat-header-status { font-size: 11.5px; opacity: .85; line-height: 1.2; }"
      + ".mychat-header-actions { display: flex; gap: 4px; align-items: center; "
      + " position: relative; flex-shrink: 0; }"
      + ".mychat-menu-btn, .mychat-close-btn { background: rgba(255,255,255,.18); color: #fff; "
      + " border: none; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; "
      + " font-size: 18px; line-height: 1; transition: background .15s; "
      + " display: flex; align-items: center; justify-content: center; }"
      + ".mychat-menu-btn { font-size: 22px; }"
      + ".mychat-close-btn { font-size: 22px; }"
      + ".mychat-menu-btn:hover, .mychat-close-btn:hover { background: rgba(255,255,255,.28); }"
      + ".mychat-menu { position: absolute; top: 100%; right: 36px; margin-top: 8px; "
      + " background: #fff; color: #2a2a2a; border-radius: 10px; "
      + " box-shadow: 0 8px 24px rgba(0,0,0,.18); padding: 6px; min-width: 180px; "
      + " z-index: 10; }"
      + ".mychat-menu[hidden] { display: none; }"
      + ".mychat-menu-item { width: 100%; background: none; color: inherit; border: none; "
      + " padding: 10px 12px; text-align: left; font: inherit; font-size: 13.5px; "
      + " cursor: pointer; border-radius: 6px; }"
      + ".mychat-menu-item:hover { background: #f3f4f6; }"

      // Сообщения
      + "#mychat-messages { flex: 1; overflow-y: auto; padding: 16px 14px; "
      + " background: " + windowBg + "; "
      + " display: flex; flex-direction: column; gap: 4px; scroll-behavior: smooth; "
      + " -webkit-overflow-scrolling: touch; }"
      + "#mychat-messages::-webkit-scrollbar { width: 6px; }"
      + "#mychat-messages::-webkit-scrollbar-thumb { background: rgba(0,0,0,.15); border-radius: 3px; }"

      + ".mychat-msg { display: flex; flex-direction: column; margin-bottom: 6px; "
      + " animation: mychat-fade .2s ease-out; }"
      + "@keyframes mychat-fade { from { opacity: 0; transform: translateY(6px); } "
      + " to { opacity: 1; transform: translateY(0); } }"
      + ".mychat-msg-in { align-items: flex-end; }"
      + ".mychat-msg-out { align-items: flex-start; }"

      + ".mychat-msg-sender { font-size: 11.5px; color: #8b8b8b; "
      + " margin-bottom: 3px; padding: 0 6px; }"

      + ".mychat-msg-bubble { max-width: 80%; padding: 9px 14px; "
      + " border-radius: " + bubbleRadius + "; "
      + " font-size: 14px; line-height: 1.45; word-wrap: break-word; "
      + " box-shadow: " + bubbleShadow + "; "
      + " border: " + bubbleBorder + "; }"
      + ".mychat-msg-in .mychat-msg-bubble { background: " + msgInBg + "; color: " + msgInColor + "; "
      + " border-bottom-right-radius: " + bubbleTailIn + "; "
      + bubbleInExtra + " }"
      + ".mychat-msg-out .mychat-msg-bubble { background: " + msgOutBg + "; color: " + msgOutColor + "; "
      + " border-bottom-left-radius: " + bubbleTailOut + "; "
      + bubbleOutExtra + " }"

      + ".mychat-msg-text { white-space: pre-wrap; }"
      + ".mychat-msg-text a { color: inherit; text-decoration: underline; "
      + " text-underline-offset: 2px; }"
      + ".mychat-msg-text code { background: rgba(0,0,0,.08); padding: 1px 5px; "
      + " border-radius: 4px; font-family: ui-monospace, 'SF Mono', Menlo, Consolas, monospace; "
      + " font-size: 0.92em; }"
      + ".mychat-msg-in .mychat-msg-text code { background: rgba(255,255,255,.18); }"
      + ".mychat-msg-text pre { background: rgba(0,0,0,.08); padding: 8px 10px; "
      + " border-radius: 6px; font-family: ui-monospace, 'SF Mono', Menlo, Consolas, monospace; "
      + " font-size: 0.88em; overflow-x: auto; margin: 4px 0; }"
      + ".mychat-msg-in .mychat-msg-text pre { background: rgba(255,255,255,.18); }"
      + ".mychat-msg-text b, .mychat-msg-text strong { font-weight: 600; }"
      + ".mychat-msg-text i, .mychat-msg-text em { font-style: italic; }"

      + ".mychat-msg-photo { margin: -3px -8px 4px; }"
      + ".mychat-msg-photo:only-child { margin-bottom: -3px; }"
      + ".mychat-msg-photo img { display: block; max-width: 100%; max-height: 240px; "
      + " border-radius: 12px; cursor: zoom-in; transition: transform .15s; }"
      + ".mychat-msg-photo img:hover { transform: scale(1.01); }"

      + ".mychat-msg-meta { display: flex; align-items: center; gap: 4px; "
      + " justify-content: flex-end; margin-top: 3px; font-size: 10.5px; opacity: .75; }"
      + ".mychat-msg-out .mychat-msg-meta { color: #888; }"
      + ".mychat-msg-status { font-size: 11px; }"
      + ".mychat-msg-error .mychat-msg-bubble { background: #fee !important; "
      + " color: #c00 !important; border: 1px solid #fcc; }"

      + "#mychat-welcome { padding: 16px; text-align: center; color: #888; "
      + " font-size: 13.5px; line-height: 1.5; }"

      // Ввод
      + "#mychat-input-wrap { padding: 10px 12px; background: " + inputBg + "; "
      + " border-top: 1px solid #ebebed; display: flex; gap: 6px; align-items: flex-end; "
      + " flex-shrink: 0; }"
      + "#mychat-input { flex: 1; resize: none; border: 1px solid #e0e0e3; "
      + " padding: 9px 14px; border-radius: 22px; font: inherit; font-size: 14px; "
      + " outline: none; max-height: 100px; min-height: 40px; transition: border-color .15s; "
      + " background: #f7f8fa; color: #2a2a2a; }"
      + "#mychat-input:focus { border-color: " + color + "; background: #fff; }"

      + ".mychat-attach-btn { width: 40px; height: 40px; flex-shrink: 0; "
      + " border-radius: 50%; cursor: pointer; display: flex; align-items: center; "
      + " justify-content: center; color: #8b8b8b; transition: background .15s, color .15s; }"
      + ".mychat-attach-btn:hover { background: #f0f1f3; color: " + color + "; }"

      + "#mychat-send { background: " + color + "; color: #fff; border: none; width: 40px; "
      + " height: 40px; border-radius: 50%; cursor: pointer; flex-shrink: 0; "
      + " display: flex; align-items: center; justify-content: center; transition: transform .15s; }"
      + "#mychat-send:hover:not(:disabled) { transform: scale(1.05); }"
      + "#mychat-send:disabled { opacity: .4; cursor: default; }"

      // Мобильная адаптация — компактное окно с отступами, не fullscreen
      + "@media (max-width: 600px) {"
      + "  #mychat-window { "
      + "    position: fixed !important; "
      + "    top: 60px !important; "
      + "    bottom: 16px !important; "
      + "    left: 12px !important; "
      + "    right: 12px !important; "
      + "    width: auto !important; "
      + "    height: auto !important; "
      + "    max-width: none !important; "
      + "    max-height: none !important; "
      + "    border-radius: 16px; "
      + "    animation: mychat-pop .25s ease-out; "
      + "    box-shadow: 0 8px 32px rgba(0,0,0,.35); "
      + "  }"
      + "  #mychat-button { bottom: 16px; right: 16px; left: auto; "
      + "    font-size: 22px; }"
      + (btnShape === "pill"
          ? ("  #mychat-button { height: 52px; padding: 0 18px 0 14px; width: auto; }"
             + "  #mychat-button .mychat-btn-label { font-size: 14px; }")
          : ("  #mychat-button { width: 56px; height: 56px; }"))
      + "  #mychat-header { padding: 10px 8px 10px 12px; }"
      + "  .mychat-header-avatar { width: 36px; height: 36px; font-size: 15px; }"
      + "  .mychat-header-title { font-size: 14px; }"
      + "  .mychat-header-status { font-size: 11px; }"
      + "  .mychat-menu-btn, .mychat-close-btn { width: 32px; height: 32px; }"
      + "  #mychat-messages { padding: 10px 8px; }"
      + "  .mychat-msg-bubble { max-width: 78%; font-size: 14px; padding: 8px 12px; }"
      + "  #mychat-input-wrap { padding: 8px; gap: 4px; }"
      + "  #mychat-input { font-size: 16px; min-height: 38px; padding: 8px 12px; }"  // 16px иначе iOS зумит
      + "  .mychat-attach-btn { width: 36px; height: 36px; }"
      + "  .mychat-attach-btn svg { width: 18px; height: 18px; }"
      + "  #mychat-send { width: 36px; height: 36px; }"
      + "  #mychat-send svg { width: 16px; height: 16px; }"
      + "  .mychat-menu { right: 6px; }"
      + "}"
      // Очень маленькие экраны (например iPhone SE)
      + "@media (max-width: 380px) {"
      + "  #mychat-window { left: 8px !important; right: 8px !important; top: 50px !important; "
      + "    bottom: 12px !important; }"
      + "  #mychat-header { padding: 8px 6px 8px 10px; }"
      + "  .mychat-header-avatar { width: 32px; height: 32px; }"
      + "}";

    var style = document.createElement("style");
    style.id = "mychat-styles";
    style.textContent = css;
    document.head.appendChild(style);
  }

  // ============================================================
  //  Создание DOM
  // ============================================================

  function buildWidget() {
    var root = document.createElement("div");
    root.id = "mychat-root";
    var _btnDisplayLabel = (config.button_shape === "pill");
    var btnContent = '<span class="mychat-btn-icon">'
                   + escapeHtml(config.button_icon || "💬") + '</span>';
    if (_btnDisplayLabel && config.button_label) {
      btnContent += '<span class="mychat-btn-label">'
                  + escapeHtml(config.button_label) + '</span>';
    }
    root.innerHTML = ""
      + '<button id="mychat-button" aria-label="Открыть чат" title="' +
        escapeHtml(config.button_label || config.brand_name || "Поддержка") + '">'
      + btnContent
      + '</button>'
      + '<div id="mychat-window" class="hidden">'
      + '  <div id="mychat-header">'
      + '    <div class="mychat-header-info">'
      + '      <div class="mychat-header-avatar" id="mychat-avatar">' +
              (config.operator_avatar
                ? '<img src="' + escapeHtml(config.operator_avatar) + '" alt="">'
                : escapeHtml((config.brand_name || "?").charAt(0))) + '</div>'
      + '      <div>'
      + '        <div class="mychat-header-title">' + escapeHtml(config.brand_name) + '</div>'
      + '        <div class="mychat-header-status">онлайн</div>'
      + '      </div>'
      + '    </div>'
      + '    <div class="mychat-header-actions">'
      + '      <button class="mychat-close-btn" aria-label="Свернуть">×</button>'
      + '    </div>'
      + '  </div>'
      + '  <div id="mychat-messages">'
      + '    <div id="mychat-welcome">' + escapeHtml(config.welcome_text) + '</div>'
      + '  </div>'
      + '  <div id="mychat-input-wrap">' +
      // [v3.5] Кнопку прикрепления фото показываем по умолчанию.
      // Скрывается ТОЛЬКО если admin явно отключил (uploads_enabled === false).
      // Раньше любое "ложное" значение (undefined/null) скрывало кнопку,
      // из-за чего она пропадала если поле отсутствовало в конфиге.
      (config.uploads_enabled !== false
        ? '    <label class="mychat-attach-btn" title="Прикрепить фото">'
          + '      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
          + '        <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>'
          + '      </svg>'
          + '      <input type="file" id="mychat-file-input" accept="image/*" hidden>'
          + '    </label>'
        : ''
      )
      + '    <textarea id="mychat-input" placeholder="' + escapeHtml(config.placeholder) + '" rows="1"></textarea>'
      + '    <button id="mychat-send" aria-label="Отправить">'
      + '      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">'
      + '        <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>'
      + '      </svg>'
      + '    </button>'
      + '  </div>'
      + '</div>';
    document.body.appendChild(root);

    $("#mychat-button").addEventListener("click", toggleWindow);
    $("#mychat-header .mychat-close-btn").addEventListener("click", closeWindow);
    $("#mychat-send").addEventListener("click", sendMessage);

    // Меню (три точки)
    var menuBtn = $("#mychat-menu-btn");
    var menu = $("#mychat-menu");
    if (menuBtn && menu) {
      menuBtn.addEventListener("click", function(e) {
        e.stopPropagation();
        menu.hidden = !menu.hidden;
      });
      document.addEventListener("click", function() {
        menu.hidden = true;
      });
    }

    // Завершить диалог
    var closeChatBtn = $("#mychat-close-chat-btn");
    if (closeChatBtn) {
      closeChatBtn.addEventListener("click", function() {
        if (!confirm("Завершить диалог?\nВся история этого чата будет очищена, новые сообщения создадут новый диалог.")) return;
        endDialog();
      });
    }

    // Файл — только если есть кнопка
    var fileInput = $("#mychat-file-input");
    if (fileInput) {
      fileInput.addEventListener("change", handleFileSelect);
    }
    var input = $("#mychat-input");
    input.addEventListener("keydown", function(e) {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });
    input.addEventListener("input", function() {
      input.style.height = "auto";
      input.style.height = Math.min(input.scrollHeight, 100) + "px";
    });
  }

  // Завершение диалога
  function endDialog() {
    api("/close", {
      method: "POST",
      body: JSON.stringify({visitor_id: visitorId}),
    }).then(function() {
      // Чистим ВСЕ хранилища
      try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}
      try { localStorage.removeItem(LAST_MSG_KEY); } catch (e) {}
      try { sessionStorage.removeItem(STORAGE_KEY); } catch (e) {}
      try { sessionStorage.removeItem(LAST_MSG_KEY); } catch (e) {}
      try { document.cookie = STORAGE_KEY + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/"; } catch (e) {}
      try { document.cookie = LAST_MSG_KEY + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/"; } catch (e) {}
      try { window.name = ""; } catch (e) {}
      try { idbSet(STORAGE_KEY, null); } catch (e) {}

      // Полностью убираем виджет из DOM
      var oldRoot = document.getElementById("mychat-root");
      if (oldRoot) oldRoot.remove();
      var oldStyles = document.getElementById("mychat-styles");
      if (oldStyles) oldStyles.remove();

      // Останавливаем polling
      if (pollTimer) {
        clearTimeout(pollTimer);
        pollTimer = null;
      }

      // Сбрасываем все переменные виджета
      visitorId = null;
      lastMessageId = 0;
      firstPollDone = false;
      historyLoaded = false;
      isOpen = false;
      identifyCalled = false;
      pendingIdentify = null;
      anyMessageSent = false;

      // Сбрасываем флаг загрузки чтобы init мог отработать снова
      window.MyChatLoaded = false;

      console.log("[MyChat] диалог завершён, виджет перезагружается");

      // Запускаем заново (через небольшую задержку чтобы успели сброситься состояния)
      setTimeout(function() {
        window.MyChatLoaded = true;
        init();
      }, 300);
    }).catch(function(e) {
      console.error("[MyChat] endDialog failed:", e);
      alert("Не удалось завершить диалог. Попробуйте позже.");
    });
  }

  // Отправка фото
  function handleFileSelect(e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    e.target.value = "";  // чтобы можно было выбрать тот же файл повторно

    console.log("[MyChat] handleFileSelect: file=", file.name,
                "size=", file.size, "type=", file.type);

    if (!file.type.startsWith("image/")) {
      alert("Можно только изображения");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      alert("Файл слишком большой (максимум 8 МБ)");
      return;
    }

    if (!visitorId) {
      console.error("[MyChat] upload: нет visitorId, не могу отправить фото");
      alert("Виджет ещё не готов, попробуйте через секунду");
      return;
    }

    // [v3.5] Если в поле ввода уже есть текст — отправляем его как подпись.
    // Поле очищаем сразу, чтобы клиент не отправил его повторно как отдельное.
    var inputEl = $("#mychat-input");
    var caption = "";
    if (inputEl) {
      caption = (inputEl.value || "").trim();
      if (caption) {
        inputEl.value = "";
      }
    }

    tempCounter += 1;
    var tempId = "temp-" + tempCounter;
    var localUrl = URL.createObjectURL(file);

    appendMessage({
      id: tempId,
      direction: "in",
      text: caption,  // [v3.5] подпись отображается под фото
      attachment_url: localUrl,
      attachment_kind: "photo",
      _optimistic: true,
      _local_blob: true,
      created_at: new Date().toISOString().replace("T", " ").slice(0, 19),
    });

    var fd = new FormData();
    fd.append("visitor_id", visitorId);
    fd.append("file", file, file.name);
    // [v3.5] Подпись клиента — передаём в backend, AI и оператор её увидят
    if (caption) {
      fd.append("caption", caption);
    }

    fetch(API + "/upload", {method: "POST", body: fd}).then(function(r) {
      console.log("[MyChat] upload response status:", r.status);
      if (!r.ok) {
        return r.text().then(function(t) {
          console.error("[MyChat] upload HTTP error", r.status, t);
          throw new Error("HTTP " + r.status + ": " + t.substring(0, 200));
        });
      }
      return r.json();
    }).then(function(res) {
      var container = $("#mychat-messages");
      var el = container && container.querySelector('[data-msg-id="' + tempId + '"]');
      if (res && res.ok && res.message_id) {
        if (el) {
          el.setAttribute("data-msg-id", String(res.message_id));
          // Заменяем blob: URL на постоянный, чтобы не утекали ссылки
          var img = el.querySelector(".mychat-msg-photo img");
          if (img && res.url) {
            try { URL.revokeObjectURL(img.src); } catch (e) {}
            img.src = config._api_root + res.url;
          }
          var status = el.querySelector(".mychat-msg-status");
          if (status) status.textContent = "✓";
        }
        if (res.message_id > lastMessageId) lastMessageId = res.message_id;
        var _k = LAST_MSG_KEY + "_" + (visitorId || "anon"); lsSet(_k, lastMessageId); cookieSet(_k, lastMessageId);
      } else {
        if (el) {
          el.classList.add("mychat-msg-error");
          var status = el.querySelector(".mychat-msg-status");
          if (status) status.textContent = "⚠";
        }
        alert("Не удалось отправить фото: " + ((res && res.error) || "ошибка"));
      }
    }).catch(function() {
      var container = $("#mychat-messages");
      var el = container && container.querySelector('[data-msg-id="' + tempId + '"]');
      if (el) {
        el.classList.add("mychat-msg-error");
        var status = el.querySelector(".mychat-msg-status");
        if (status) status.textContent = "⚠";
      }
      alert("Не удалось отправить фото");
    });
  }

  // ============================================================
  //  Действия с UI
  // ============================================================

  function toggleWindow() {
    isOpen ? closeWindow() : openWindow();
  }

  function isMobile() {
    return /Android|iPhone|iPad|iPod|Mobile|Opera Mini/i.test(navigator.userAgent)
        || window.innerWidth <= 600;
  }

  function openWindow() {
    isOpen = true;
    var win = $("#mychat-window");
    if (win) win.classList.remove("hidden");
    setBadge(0);

    // На мобиле — гарантированно блокируем автофокус input:
    // делаем readonly чтобы iOS/Android не открыл клавиатуру при появлении.
    // Снимаем readonly при первом тапе пользователя.
    var input = $("#mychat-input");
    if (isMobile() && input) {
      input.setAttribute("readonly", "readonly");
      var unlockInput = function() {
        input.removeAttribute("readonly");
        input.removeEventListener("touchstart", unlockInput);
        input.removeEventListener("click", unlockInput);
      };
      input.addEventListener("touchstart", unlockInput, {passive: true});
      input.addEventListener("click", unlockInput);

      // Когда клавиатура появляется — подстраиваем высоту окна
      // через visualViewport API (поддерживается iOS Safari 13+ и Chrome)
      if (window.visualViewport && win && !win._keyboardListenerAdded) {
        var adjustForKeyboard = function() {
          var vh = window.visualViewport.height;
          win.style.height = Math.min(vh - 80, window.innerHeight - 80) + "px";
          // И скроллим к низу чтобы input был виден
          var c = document.getElementById("mychat-messages");
          if (c) c.scrollTop = c.scrollHeight;
        };
        window.visualViewport.addEventListener("resize", adjustForKeyboard);
        win._keyboardListenerAdded = true;
      }
    } else if (input) {
      input.focus();
    }

    // Прокручиваем в самый низ — к свежим сообщениям
    setTimeout(scrollToBottom, 50);
    setTimeout(scrollToBottom, 300);  // на случай если контент догрузился

    // При открытии виджета сразу делаем poll — чтобы не ждать таймер
    // и получить свежие сообщения мгновенно. stopPolling() + startPolling()
    // = текущий таймер отменяется и запускается новый цикл с poll() сразу.
    stopPolling();
    startPolling();
  }

  function closeWindow() {
    isOpen = false;
    var win = $("#mychat-window");
    if (win) win.classList.add("hidden");
  }

  function setBadge(count) {
    var btn = $("#mychat-button");
    if (!btn) return;
    var badge = btn.querySelector(".mychat-badge");
    if (count > 0) {
      if (!badge) {
        badge = document.createElement("span");
        badge.className = "mychat-badge";
        btn.appendChild(badge);
      }
      badge.textContent = count > 9 ? "9+" : count;
    } else if (badge) {
      badge.remove();
    }
  }

  function appendMessage(msg) {
    var container = $("#mychat-messages");
    if (!container) return;
    var welcome = $("#mychat-welcome");
    if (welcome) welcome.remove();

    // Проверка дубля: если такое же сообщение уже в DOM, не добавляем второе
    if (msg.id) {
      var existing = container.querySelector('[data-msg-id="' + msg.id + '"]');
      if (existing) return;
    }

    // Дедуп для оптимистичных текстовых: ищем temp-сообщение с тем же текстом
    if (msg.id && msg.direction === "in" && msg.text && !msg.attachment_url) {
      var temps = container.querySelectorAll('[data-msg-id^="temp-"]');
      for (var i = 0; i < temps.length; i++) {
        var t = temps[i];
        if (t.getAttribute("data-text") === msg.text) {
          t.setAttribute("data-msg-id", msg.id);
          var status = t.querySelector(".mychat-msg-status");
          if (status) status.textContent = "✓";
          return;
        }
      }
    }

    // [v3.5] Дедуп для оптимистичных ФОТО:
    // ищем temp-сообщение с фото (есть .mychat-msg-photo внутри) и заменяем id.
    // Без этого polling приносит то же фото и появляется дубль.
    if (msg.id && msg.direction === "in" && msg.attachment_url
        && msg.attachment_kind === "photo") {
      var tempsPhoto = container.querySelectorAll('[data-msg-id^="temp-"]');
      for (var j = 0; j < tempsPhoto.length; j++) {
        var tp = tempsPhoto[j];
        if (tp.querySelector(".mychat-msg-photo")) {
          tp.setAttribute("data-msg-id", String(msg.id));
          // Заменим blob: URL на постоянный
          var imgEl = tp.querySelector(".mychat-msg-photo img");
          if (imgEl) {
            var newSrc = (msg.attachment_url.indexOf("http") === 0)
              ? msg.attachment_url
              : (config._api_root + msg.attachment_url);
            try { URL.revokeObjectURL(imgEl.src); } catch (e) {}
            imgEl.src = newSrc;
          }
          var statusP = tp.querySelector(".mychat-msg-status");
          if (statusP) statusP.textContent = "✓";
          return;
        }
      }
    }

    var div = document.createElement("div");
    div.className = "mychat-msg mychat-msg-" + msg.direction;
    div.setAttribute("data-msg-id", String(msg.id || ""));
    if (msg.text) div.setAttribute("data-text", msg.text);

    var html = "";
    if (msg.direction === "out") {
      // [v3.5] Логика отображения отправителя:
      //   - Если sender совпадает с config.ai_name → показываем AI-имя
      //     (Алиса / 🤖 AI-помощник — из настроек /ai админки)
      //   - Иначе (оператор, система) → общая подпись «Оператор»
      //   - Если ai_name пустой → fallback на config.operator_label
      var senderRaw = (msg.sender || "").trim();
      var aiName = (config.ai_name || "").trim();
      var labelOut;
      if (aiName && senderRaw === aiName) {
        labelOut = aiName;
      } else {
        labelOut = config.operator_label || "Оператор";
      }
      html += '<div class="mychat-msg-sender">' +
              escapeHtml(labelOut) + '</div>';
    }
    html += '<div class="mychat-msg-bubble">';

    // Фото
    if (msg.attachment_url && msg.attachment_kind === "photo") {
      var imgSrc = msg._local_blob
        ? msg.attachment_url
        : (config._api_root + msg.attachment_url);
      html += '<div class="mychat-msg-photo">';
      html += '<img src="' + imgSrc + '" alt="фото" loading="lazy" ';
      html += 'onclick="window.open(this.src, \'_blank\')">';
      html += '</div>';
    }

    // Текст
    if (msg.text) {
      html += '<div class="mychat-msg-text">' + formatHtmlSafe(msg.text) + '</div>';
    }

    html += '<div class="mychat-msg-meta">';
    html += '<span class="mychat-msg-time">' + formatTime(msg.created_at) + '</span>';
    if (msg.direction === "in") {
      html += '<span class="mychat-msg-status">' +
              (msg._optimistic ? "⏳" : "✓") + '</span>';
    }
    html += '</div></div>';
    div.innerHTML = html;
    container.appendChild(div);

    requestAnimationFrame(function() {
      // Если идёт первая загрузка истории — прокручиваем не сразу за каждым
      // сообщением (это создаёт «дёрганый» вид и финал не точный), а в конце
      // через scrollToBottom() из poll()-а.
      if (!historyLoaded) return;
      container.scrollTop = container.scrollHeight;
    });
  }

  function linkify(text) {
    return text.replace(
      /(https?:\/\/[^\s<>"']+)/g,
      '<a href="$1" target="_blank" rel="noopener" style="color:inherit;text-decoration:underline">$1</a>'
    );
  }

  /**
   * Безопасный парсинг Telegram-HTML.
   * Сначала всё экранируем, потом возвращаем как HTML только разрешённые
   * теги: <b>, <strong>, <i>, <em>, <u>, <s>, <strike>, <del>, <code>,
   * <pre>, <a href="...">, <br>.
   * Это нужно потому что в админ-ответах часто используется TG-разметка
   * (HTML parse mode), и без парсинга клиент видит «<b>текст</b>» как сырой текст.
   */
  function formatHtmlSafe(text) {
    if (!text) return "";
    // 1) Всё экранируем
    var safe = escapeHtml(text);
    // 2) Восстанавливаем разрешённые теги
    safe = safe
      .replace(/&lt;b&gt;/gi, '<b>')
      .replace(/&lt;\/b&gt;/gi, '</b>')
      .replace(/&lt;strong&gt;/gi, '<strong>')
      .replace(/&lt;\/strong&gt;/gi, '</strong>')
      .replace(/&lt;i&gt;/gi, '<i>')
      .replace(/&lt;\/i&gt;/gi, '</i>')
      .replace(/&lt;em&gt;/gi, '<em>')
      .replace(/&lt;\/em&gt;/gi, '</em>')
      .replace(/&lt;u&gt;/gi, '<u>')
      .replace(/&lt;\/u&gt;/gi, '</u>')
      .replace(/&lt;s&gt;/gi, '<s>')
      .replace(/&lt;\/s&gt;/gi, '</s>')
      .replace(/&lt;strike&gt;/gi, '<s>')
      .replace(/&lt;\/strike&gt;/gi, '</s>')
      .replace(/&lt;del&gt;/gi, '<s>')
      .replace(/&lt;\/del&gt;/gi, '</s>')
      .replace(/&lt;code&gt;/gi, '<code>')
      .replace(/&lt;\/code&gt;/gi, '</code>')
      .replace(/&lt;pre&gt;/gi, '<pre>')
      .replace(/&lt;\/pre&gt;/gi, '</pre>')
      .replace(/&lt;br\s*\/?&gt;/gi, '<br>')
      // Ссылки: <a href="URL"> и </a>
      .replace(
        /&lt;a\s+href=&quot;([^&"]+)&quot;(?:\s+[^&]*)?&gt;/gi,
        '<a href="$1" target="_blank" rel="noopener" style="color:inherit;text-decoration:underline">'
      )
      .replace(/&lt;\/a&gt;/gi, '</a>');
    // 3) URL автоматически кликабельны (но только если они НЕ внутри уже <a>)
    // Простой подход: пропускаем уже обработанные ссылки
    if (safe.indexOf('<a href=') === -1) {
      safe = linkify(safe);
    }
    return safe;
  }

  // ============================================================
  //  Отправка
  // ============================================================

  var tempCounter = 0;

  // Был ли уже отправлен хоть один message? Используем чтобы первое сообщение
  // дождалось identify, иначе создастся guest_xxx топик.
  var anyMessageSent = false;

  function sendMessage() {
    var input = $("#mychat-input");
    var text = input.value.trim();
    if (!text) return;

    input.disabled = true;
    $("#mychat-send").disabled = true;

    tempCounter += 1;
    var tempId = "temp-" + tempCounter;

    // Оптимистично показываем со статусом ⏳
    appendMessage({
      id: tempId,
      direction: "in",
      text: text,
      created_at: new Date().toISOString().replace("T", " ").slice(0, 19),
      _optimistic: true,
    });
    input.value = "";
    input.style.height = "auto";

    // Если это ПЕРВОЕ сообщение и identify ещё не пришёл — ждём до 2.5 сек.
    // Это критично: иначе создастся анонимный топик "guest_xxx" вместо
    // персонального "user_<telegram_id>".
    var doSend = function() {
      anyMessageSent = true;
      _actualSendMessage(text, tempId, input);
    };

    if (!anyMessageSent && !identifyCalled) {
      console.log("[MyChat] первое сообщение — жду identify до 2.5 сек...");
      var waitStart = Date.now();
      var waitInterval = setInterval(function() {
        if (identifyCalled) {
          clearInterval(waitInterval);
          console.log("[MyChat] identify пришёл, отправляю сообщение");
          doSend();
        } else if (Date.now() - waitStart > 2500) {
          clearInterval(waitInterval);
          console.warn("[MyChat] identify так и не пришёл за 2.5 сек, отправляю как guest");
          doSend();
        }
      }, 100);
    } else {
      doSend();
    }
  }

  function _actualSendMessage(text, tempId, input) {
    api("/message", {
      method: "POST",
      body: JSON.stringify({visitor_id: visitorId, text: text}),
    }).then(function(res) {
      input.disabled = false;
      $("#mychat-send").disabled = false;
      // На мобильном НЕ возвращаем focus — это снова выскочит клавиатура.
      // Пусть клиент сам тапнет по input если хочет писать дальше.
      if (!isMobile()) {
        input.focus();
      }

      if (res && res.ok && res.message_id) {
        // Меняем temp-id на серверный — чтобы при polling не задвоилось
        var container = $("#mychat-messages");
        var el = container && container.querySelector('[data-msg-id="' + tempId + '"]');
        if (el) {
          el.setAttribute("data-msg-id", String(res.message_id));
          var status = el.querySelector(".mychat-msg-status");
          if (status) status.textContent = "✓";
        }
        // Двигаем lastMessageId чтобы это сообщение НЕ пришло в poll
        if (res.message_id > lastMessageId) lastMessageId = res.message_id;
        var _k = LAST_MSG_KEY + "_" + (visitorId || "anon"); lsSet(_k, lastMessageId); cookieSet(_k, lastMessageId);
      } else {
        // Ошибка — помечаем сообщение красным
        var container = $("#mychat-messages");
        var el = container && container.querySelector('[data-msg-id="' + tempId + '"]');
        if (el) {
          el.classList.add("mychat-msg-error");
          var status = el.querySelector(".mychat-msg-status");
          if (status) status.textContent = "⚠";
        }
        alert("Не удалось отправить: " + ((res && res.error) || "ошибка сети"));
      }
    }).catch(function() {
      input.disabled = false;
      $("#mychat-send").disabled = false;
      var container = $("#mychat-messages");
      var el = container && container.querySelector('[data-msg-id="' + tempId + '"]');
      if (el) {
        el.classList.add("mychat-msg-error");
        var status = el.querySelector(".mychat-msg-status");
        if (status) status.textContent = "⚠";
      }
      alert("Не удалось отправить сообщение. Проверьте подключение.");
    });
  }

  // ============================================================
  //  Polling
  // ============================================================

  function startPolling() {
    if (pollTimer) {
      console.log("[MyChat] startPolling: уже запущен, пропускаю");
      return;
    }
    console.log("[MyChat] startPolling: запускаю polling");
    poll();
  }

  function stopPolling() {
    if (pollTimer) {
      clearTimeout(pollTimer);
      pollTimer = null;
      console.log("[MyChat] stopPolling: остановлен");
    }
  }

  var firstPollDone = false;
  var historyLoaded = false;  // была ли загружена история при reload
  var pollErrorCount = 0;

  function poll() {
    // Первый poll после reload — грузим ВСЮ историю (since=0).
    // Иначе после F5 чат окажется пустым, хотя в БД есть сообщения.
    var sinceParam = (!historyLoaded && lastMessageId > 0) ? 0 : lastMessageId;

    api("/poll?visitor_id=" + encodeURIComponent(visitorId)
        + "&since=" + sinceParam).then(function(res) {
      var wasFirstLoad = !historyLoaded;
      var newCount = 0;
      if (res && res.ok && res.messages) {
        res.messages.forEach(function(m) {
          if (m.id > lastMessageId) lastMessageId = m.id;
          // Считаем сколько НОВЫХ outsourced сообщений (от оператора)
          if (firstPollDone && m.direction === "out") newCount++;
          appendMessage(m);
          // Реакция на НОВОЕ сообщение от оператора
          // (firstPollDone — чтобы не сработало при первой загрузке истории)
          if (firstPollDone && m.direction === "out") {
            // Звук — всегда, даже если виджет открыт
            playNotificationSound();
            // Бейдж только если виджет закрыт
            if (!isOpen) {
              var btn = $("#mychat-button");
              var badge = btn && btn.querySelector(".mychat-badge");
              var n = badge ? parseInt(badge.textContent, 10) || 0 : 0;
              setBadge(n + 1);
            } else {
              // Виджет открыт — прокручиваем чтобы было видно
              scrollToBottom();
              requestAnimationFrame(scrollToBottom);
              setTimeout(scrollToBottom, 100);
            }
          }
        });
        var _k = LAST_MSG_KEY + "_" + (visitorId || "anon"); lsSet(_k, lastMessageId); cookieSet(_k, lastMessageId);
        if (newCount > 0) {
          console.log("[MyChat] poll: получено " + newCount +
                      " новых сообщений от оператора");
        }
      }
      pollErrorCount = 0;

      // На первой загрузке истории — гарантированно прокручиваем в самый низ.
      if (wasFirstLoad) {
        scrollToBottom();
        requestAnimationFrame(scrollToBottom);
        setTimeout(scrollToBottom, 50);
        setTimeout(scrollToBottom, 200);
        setTimeout(scrollToBottom, 700);
        var imgs = document.querySelectorAll("#mychat-messages img");
        imgs.forEach(function(img) {
          if (img.complete) {
            scrollToBottom();
          } else {
            img.addEventListener("load", scrollToBottom, {once: true});
            img.addEventListener("error", scrollToBottom, {once: true});
          }
        });
      }

      historyLoaded = true;
      firstPollDone = true;
      // Свёрнутый виджет — опрашиваем чаще (4 сек) чтобы badge и звук
      // появлялись быстро. Открытый — 2.5 сек.
      pollTimer = setTimeout(poll, isOpen ? 2500 : 4000);
    }).catch(function(e) {
      pollErrorCount++;
      console.warn("[MyChat] poll error #" + pollErrorCount + ":", e);
      // Backoff при ошибках — 5/10/15/20 сек максимум
      var delay = Math.min(5000 * pollErrorCount, 20000);
      pollTimer = setTimeout(poll, delay);
    });
  }

  function scrollToBottom() {
    var container = document.getElementById("mychat-messages");
    if (container) container.scrollTop = container.scrollHeight;
  }

  // ============================================================
  //  Identify (публичный API)
  // ============================================================

  window.MyChat = {
    identify: function(data) {
      console.log("[MyChat] identify вызван:", data);
      // Отмечаем флаг ТОЛЬКО если в данных есть user_id или email.
      // Пустой identify {} (когда Jinja не отрендерила) не считается
      // успешным — auto-detect должен сработать.
      if (data && (data.user_id || data.email)) {
        identifyCalled = true;
      }
      if (!visitorId) {
        // Ещё не инициализирован — отложим
        pendingIdentify = data;
        return;
      }
      // Если данных нет — нет смысла спамить сервер пустыми запросами
      if (!data || (!data.user_id && !data.email)) {
        console.warn("[MyChat] identify без данных — пропускаю запрос");
        return;
      }
      var payload = {visitor_id: visitorId};
      if (data.user_id) payload.user_id = data.user_id;
      if (data.name) payload.name = data.name;
      if (data.email) payload.email = data.email;
      api("/identify", {
        method: "POST", body: JSON.stringify(payload),
      }).then(function(res) {
        // Если сервер вернул ДРУГОЙ visitor_id — значит для этого user_id
        // уже был чат. Перезаписываем локальное состояние и перезагружаем
        // историю.
        if (res && res.ok && res.visitor_id && res.visitor_id !== visitorId) {
          console.log("[MyChat] visitor_id восстановлен по user_id:",
                      visitorId, "→", res.visitor_id);
          visitorId = res.visitor_id;
          saveVisitorId(visitorId);
          // Сбрасываем lastMessageId — заберём всю историю заново
          lastMessageId = 0;
          firstPollDone = false;
          // Чистим UI и тянем заново
          var container = $("#mychat-messages");
          if (container) {
            container.innerHTML = '<div id="mychat-welcome">' +
              escapeHtml(config.welcome_text) + '</div>';
          }
          // Стартанём polling сразу, чтоб подгрузить историю
          if (pollTimer) {
            clearTimeout(pollTimer);
            pollTimer = null;
          }
          poll();
        } else if (res && res.ok) {
          console.log("[MyChat] identify ок, user_id привязан");
        }
      });
    },
    open: openWindow,
    close: closeWindow,
  };

  // ВАЖНО: обрабатываем очередь identify-вызовов, которые могли быть
  // зарегистрированы ДО загрузки виджета.
  try {
    var queued = window.MyChatQueue;
    if (queued && queued.length) {
      console.log("[MyChat] обработка очереди identify, шт.:", queued.length);
      var lastCall = queued[queued.length - 1];
      pendingIdentify = lastCall;
      window.MyChatQueue = [];
    }
  } catch (e) {
    console.error("[MyChat] queue processing failed:", e);
  }

  /**
   * Автоматически ищем Telegram ID / email на странице, если identify
   * не был передан явно через JS. Сканируем общие места:
   *   - onclick="copyClientId('123')"
   *   - data-telegram-id="123" / data-user-id="123"
   *   - элементы с email-pattern
   * Это спасает когда шаблонизатор сайта не отрендерил <script>identify</script>,
   * но данные клиента есть в DOM в другом виде.
   */
  function autoDetectIdentify() {
    var data = {};

    // 1) Ищем Telegram ID в onclick атрибутах (copyClientId)
    // Сканируем ВСЕ элементы с onclick, даже скрытые модалки
    try {
      var btns = document.querySelectorAll('[onclick*="copyClientId"]');
      console.log("[MyChat] auto-detect: найдено элементов с copyClientId:",
                  btns.length);
      for (var i = 0; i < btns.length; i++) {
        var oc = btns[i].getAttribute("onclick") || "";
        var m = oc.match(/copyClientId\(\s*['"]?(\d{4,})['"]?/);
        if (m && m[1]) {
          var id = parseInt(m[1], 10);
          if (id > 1000) {
            data.user_id = id;
            console.log("[MyChat] auto-detect: нашёл user_id в onclick:", id);
            break;
          }
        }
      }
    } catch (e) {
      console.warn("[MyChat] auto-detect onclick search failed:", e);
    }

    // 2) Если не нашли — сканируем весь innerHTML страницы (грубо но надёжно)
    if (!data.user_id) {
      try {
        var html = document.documentElement.innerHTML || "";
        // Ищем copyClientId('123456')
        var m2 = html.match(/copyClientId\(\s*['"]?(\d{6,})['"]?\s*\)/);
        if (m2 && m2[1]) {
          var id2 = parseInt(m2[1], 10);
          if (id2 > 1000) {
            data.user_id = id2;
            console.log("[MyChat] auto-detect: нашёл user_id в HTML:", id2);
          }
        }
      } catch (e) {
        console.warn("[MyChat] auto-detect html scan failed:", e);
      }
    }

    // 3) Ищем в data-атрибутах body или html
    if (!data.user_id) {
      try {
        var html_el = document.documentElement;
        var body = document.body;
        var attrs = ["data-telegram-id", "data-tg-id", "data-user-id"];
        for (var j = 0; j < attrs.length; j++) {
          var v = (body && body.getAttribute(attrs[j])) ||
                  (html_el && html_el.getAttribute(attrs[j]));
          if (v && /^\d{4,}$/.test(v)) {
            data.user_id = parseInt(v, 10);
            console.log("[MyChat] auto-detect: нашёл user_id в data-атрибуте:", v);
            break;
          }
        }
      } catch (e) {}
    }

    // 4) Ищем email на странице
    try {
      var emailPattern = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
      var bodyText = (document.body && document.body.textContent) || "";
      var em = bodyText.match(emailPattern);
      if (em && em[0] &&
          !em[0].includes("example.com") &&
          !em[0].includes("noreply") &&
          !em[0].includes("@mail.tld")) {
        data.email = em[0];
        console.log("[MyChat] auto-detect: нашёл email:", em[0]);
      }
    } catch (e) {}

    if (data.user_id || data.email) {
      return data;
    }
    return null;
  }

  // ============================================================
  //  Инициализация
  // ============================================================

  function init() {
    console.log("[MyChat] init start, API=" + API);

    // Гарантируем meta viewport (важно для мобильной адаптации)
    if (!document.querySelector('meta[name="viewport"]')) {
      var vp = document.createElement("meta");
      vp.name = "viewport";
      vp.content = "width=device-width, initial-scale=1.0, viewport-fit=cover";
      document.head.appendChild(vp);
    }

    // Уведомить сервер при закрытии вкладки (если есть visitorId).
    // Сервер посмотрит — были ли непрочитанные ответы оператора, и
    // если да — напишет ему в TG-топик что клиент ушёл не увидев.
    // pagehide надёжнее beforeunload (срабатывает и в мобильных Safari).
    function sendLeaveBeacon() {
      if (!visitorId) return;
      try {
        var data = JSON.stringify({visitor_id: visitorId});
        if (navigator.sendBeacon) {
          // sendBeacon шлёт с типом text/plain или Blob — сервер должен
          // принимать без Content-Type: application/json
          var blob = new Blob([data], {type: "application/json"});
          navigator.sendBeacon(API + "/leave", blob);
        } else {
          // Fallback — синхронный XHR (deprecated но всё ещё работает)
          var xhr = new XMLHttpRequest();
          xhr.open("POST", API + "/leave", false);
          xhr.setRequestHeader("Content-Type", "application/json");
          xhr.send(data);
        }
      } catch (e) {
        // ничего не делаем, страница всё равно закрывается
      }
    }
    window.addEventListener("pagehide", sendLeaveBeacon);
    window.addEventListener("beforeunload", sendLeaveBeacon);

    // Инициализируем IndexedDB параллельно
    idbInit(function() {
      // После того как IDB готова — проверяем синхронные хранилища
      var synced = loadVisitorId();
      if (synced) {
        startInit(synced);
      } else {
        // Если синхронные пусты — пробуем достать из IDB
        idbGet(STORAGE_KEY, function(idbId) {
          if (idbId) {
            console.log("[MyChat] visitor_id восстановлен из IndexedDB:", idbId);
            // Сразу записываем обратно в LS/cookie
            saveVisitorId(idbId);
            startInit(idbId);
          } else {
            startInit(null);
          }
        });
      }
    });
  }

  function startInit(existingVisitorId) {
    // 1) Загружаем конфигурацию
    fetch(API + "/config").then(function(r) { return r.json(); }).then(function(res) {
      if (!res || !res.ok) {
        console.error("[MyChat] failed to load config");
        return;
      }
      config = res.config;
      config._api_root = API.replace(/\/api\/chat$/, "");
      injectStyles();

      visitorId = existingVisitorId;
      // lastMessageId — хранится ПО visitor_id, иначе глобальное значение
      // прошлого visitor (например 519) ломает poll для нового visitor
      // (где в БД всего 11 сообщений, since=519 → 0 results)
      var perVisitorKey = LAST_MSG_KEY + "_" + (visitorId || "anon");
      lastMessageId = parseInt(
        lsGet(perVisitorKey) || cookieGet(perVisitorKey), 10,
      ) || 0;
      // Подчищаем СТАРЫЙ глобальный ключ (legacy от прошлых версий) — он мог
      // содержать «чужие» ID от других visitor'ов и ломать polling
      try {
        localStorage.removeItem(LAST_MSG_KEY);
        document.cookie = LAST_MSG_KEY + "=; path=/; max-age=0";
      } catch (e) {}
      console.log("[MyChat] loaded visitor_id from storage:", visitorId,
                  "lastMessageId:", lastMessageId);

      var headers = {};
      if (visitorId) headers["X-Visitor-Id"] = visitorId;

      return fetch(API + "/session", {
        method: "POST",
        headers: Object.assign({"Content-Type": "application/json"}, headers),
        body: JSON.stringify({referer: window.location.href}),
        credentials: "omit",
      }).then(function(r) { return r.json(); });
    }).then(function(res) {
      if (!res || !res.ok) {
        console.error("[MyChat] /session failed:", res);
        return;
      }
      // Если сервер вернул другой visitor_id (например мерж по user_id) —
      // подгрузим lastMessageId под него
      if (res.visitor_id !== visitorId) {
        visitorId = res.visitor_id;
        var pvKey = LAST_MSG_KEY + "_" + visitorId;
        lastMessageId = parseInt(lsGet(pvKey) || cookieGet(pvKey), 10) || 0;
        console.log("[MyChat] visitor_id обновлён сервером →", visitorId,
                    "lastMessageId:", lastMessageId);
      }
      saveVisitorId(visitorId);
      console.log("[MyChat] session ready, is_new=" + res.is_new);

      buildWidget();

      if (pendingIdentify) {
        // Проверяем — есть ли в pending реальные данные
        var hasData = pendingIdentify.user_id || pendingIdentify.email;
        if (hasData) {
          console.log("[MyChat] применяю pending identify с данными");
          window.MyChat.identify(pendingIdentify);
          pendingIdentify = null;
        } else {
          // Pending identify пустой (Jinja не отрендерила)
          console.warn(
            "[MyChat] pending identify пустой — пробую auto-detect из DOM"
          );
          pendingIdentify = null;
          identifyCalled = false;
        }
      }

      // === Auto-detect РАНЬШЕ — иначе клиент может успеть написать
      // сообщение до того как мы узнаем кто он ===
      if (!identifyCalled) {
        // Сразу пробуем найти ID в DOM (без задержки)
        var auto = autoDetectIdentify();
        if (auto && (auto.user_id || auto.email)) {
          console.log("[MyChat] вызываю identify по данным из DOM (sync):", auto);
          window.MyChat.identify(auto);
        }
      }

      // ВТОРАЯ попытка через 2 сек на случай если страница ещё не дорендерилась
      // (модалки SPA, ленивая загрузка профиля и т.п.)
      setTimeout(function() {
        if (identifyCalled) {
          console.log("[MyChat] identify уже сработал, retry не нужен");
          return;
        }
        var auto2 = autoDetectIdentify();
        if (auto2 && (auto2.user_id || auto2.email)) {
          console.log("[MyChat] retry: вызываю identify по DOM:", auto2);
          window.MyChat.identify(auto2);
        } else {
          console.warn("[MyChat] auto-detect не нашёл данных на странице");
        }
      }, 2000);

      startPolling();

      // Авто-открытие через N секунд
      var autoOpen = parseInt(config.auto_open_seconds, 10) || 0;
      if (autoOpen > 0) {
        setTimeout(function() {
          if (!isOpen) openWindow();
        }, autoOpen * 1000);
      }

      // === ДИАГНОСТИКА: если identify не пришёл за 5 сек — предупреждаем ===
      setTimeout(function() {
        if (!identifyCalled) {
          console.warn(
            "[MyChat] ⚠️ identify не вызван (даже auto-detect не нашёл данных)!\n" +
            "  • Клиент сидит как анонимный гость, ИЛИ\n" +
            "  • Шаблонизатор не отрендерил блок identify, ИЛИ\n" +
            "  • На странице нет ни одного очевидного места с user_id/email\n" +
            "Виджет работает в анонимном режиме."
          );
        }
      }, 5000);
    }).catch(function(e) {
      console.error("[MyChat] init failed:", e);
    });
  }

  // Звук уведомления — двухтоновое «дин-дон» через Web Audio API
  // (без внешних файлов). Похоже на звук Telegram / WhatsApp.
  var _audioCtx = null;
  function playNotificationSound() {
    if (!config || !config.sound_enabled) return;
    try {
      // Переиспользуем один AudioContext (быстрее и не утекает память)
      if (!_audioCtx) {
        _audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }
      // Браузеры блокируют звук пока пользователь не взаимодействовал —
      // resume() пробует разблокировать
      if (_audioCtx.state === "suspended") {
        _audioCtx.resume().catch(function(){});
      }
      var ctx = _audioCtx;
      var now = ctx.currentTime;

      // Первая нота — высокая
      _playTone(ctx, 988, now,         0.10, 0.18);   // B5
      // Вторая нота — чуть ниже, через 120ms
      _playTone(ctx, 740, now + 0.12,  0.10, 0.22);   // F#5
    } catch (e) {}
  }

  function _playTone(ctx, freq, startTime, attack, duration) {
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, startTime);
    // Atak (быстрый рост громкости)
    gain.gain.exponentialRampToValueAtTime(0.18, startTime + attack * 0.3);
    // Decay (плавное затухание)
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
    osc.start(startTime);
    osc.stop(startTime + duration + 0.05);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
"""


# ============================================================
#  СТАРТ СЕРВЕРА
# ============================================================

def build_app(bot: Bot) -> web.Application:
    """Собирает aiohttp-приложение с роутами."""
    # client_max_size: лимит на размер тела запроса (для загрузки фото до 8 МБ)
    app = web.Application(client_max_size=10 * 1024 * 1024)
    app["bot"] = bot

    app.router.add_post("/api/chat/session", create_session)
    app.router.add_post("/api/chat/identify", identify)
    app.router.add_post("/api/chat/message", send_message)
    app.router.add_post("/api/chat/upload", upload_photo)
    app.router.add_post("/api/chat/close", close_chat)
    app.router.add_post("/api/chat/leave", leave_chat)
    app.router.add_get("/api/chat/file/{visitor_id}/{filename}", serve_file)
    app.router.add_get("/api/chat/poll", poll_messages)
    app.router.add_get("/api/chat/config", widget_config)
    app.router.add_get("/api/chat/widget.js", widget_js)
    app.router.add_get("/api/chat/health", health)

    # CORS preflight для всех /api/chat/*
    app.router.add_options("/api/chat/{tail:.*}", cors_preflight)

    return app


async def start_web_chat_server(bot: Bot) -> web.AppRunner:
    """Запускает aiohttp сервер. Возвращает runner для последующей остановки."""
    global _bot_instance
    _bot_instance = bot  # сохраняем для фоновых задач и /leave
    await web_chat_db.init_web_chat_db()
    await widget_settings.init_widget_settings()
    app = build_app(bot)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", WEB_CHAT_PORT)
    await site.start()
    logger.info("Веб-чат API запущен на 0.0.0.0:{}", WEB_CHAT_PORT)

    # Фоновая задача — проверяем неактивных клиентов с непрочитанными ответами
    asyncio.create_task(_inactivity_watcher())

    return runner


# Минут неактивности после которых уведомляем оператора (дефолт)
INACTIVITY_THRESHOLD_MINUTES = 2
# Период проверки (сек)
INACTIVITY_CHECK_INTERVAL = 60


async def _inactivity_watcher() -> None:
    """
    Фоновая задача: раз в минуту ищет клиентов, которым оператор отправил
    сообщение, но они его не забрали через /poll и больше N минут не активны.
    Шлёт уведомление в их TG-топик.

    [v3.5] Управляется настройками в админке (Настройки бота → Уведомления):
      - notify_client_inactive — вкл/выкл
      - client_inactive_minutes — порог в минутах
    Настройки читаются на каждой итерации — изменения применяются без
    перезапуска бота.

    Защита от повтора: помечаем сообщения как notified_offline=1.
    Когда клиент откроет виджет — он забёт сообщения, delivered станет 1,
    и при следующем «уходе» уведомление снова сработает (если будет новое
    непрочитанное).
    """
    logger.info(
        "inactivity_watcher: запущен (порог и вкл/выкл управляются из админки)",
    )
    # Небольшая задержка чтобы бот успел нормально стартовать
    await asyncio.sleep(15)
    while True:
        try:
            # [v3.5] Читаем настройки на каждой итерации
            try:
                from app import bot_settings as _bs
                enabled = _bs.get_bool("notify_client_inactive", True)
                threshold = _bs.get_int("client_inactive_minutes", 2)
                if threshold < 1:
                    threshold = 1  # защита от 0/отрицательных
            except Exception:
                enabled = True
                threshold = INACTIVITY_THRESHOLD_MINUTES

            if not enabled:
                # Уведомления отключены — спим до следующей проверки
                await asyncio.sleep(INACTIVITY_CHECK_INTERVAL)
                continue

            candidates = await web_chat_db.find_inactive_undelivered(
                inactive_minutes=threshold,
            )
            if candidates:
                logger.info(
                    "inactivity_watcher: найдено {} неактивных клиентов (порог={} мин)",
                    len(candidates), threshold,
                )
            for c in candidates:
                try:
                    await _notify_topic_about_offline(
                        c["visitor_id"], reason="inactive",
                    )
                except Exception as e:
                    logger.warning(
                        "inactivity_watcher: failed для {}: {}",
                        c["visitor_id"], e,
                    )
                # Микро-пауза между отправками — не давим на TG API
                # и даём виджету пройти через БД своими запросами
                await asyncio.sleep(0.3)
        except Exception as e:
            logger.warning("inactivity_watcher loop error: {}", e)
        await asyncio.sleep(INACTIVITY_CHECK_INTERVAL)