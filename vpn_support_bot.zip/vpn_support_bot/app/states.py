from aiogram.fsm.state import StatesGroup, State


class SupportStates(StatesGroup):
    # Пользователь нажал «Связаться с поддержкой» — ждём текст/фото
    awaiting_ticket_message = State()
