"""
Билдер клавиатур из БД.

Заменяет `from app.keyboards import main_menu, pay_menu, ...`.
Каждая функция возвращает InlineKeyboardMarkup, собранный из данных
в БД (через content_cache). Если меню в БД нет — fallback на оригинальную
функцию из keyboards.py.

Также билдер обрабатывает env-плейсхолдеры в URL и тексте кнопки —
{COMMUNITY_CHAT_URL}, {NEWS_CHANNEL_URL}, {MAIN_BOT}.
"""

from __future__ import annotations

import os
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from app import content_cache
from app import keyboards as _default_keyboards


_LINK_KEYS = {
    "MAIN_BOT": os.getenv("MAIN_BOT_USERNAME", "vpnmore_bot").lstrip("@").strip(),
    "COMMUNITY_CHAT_URL": os.getenv("COMMUNITY_CHAT_URL", "https://t.me/your_vpn_chat").strip(),
    "NEWS_CHANNEL_URL": os.getenv("NEWS_CHANNEL_URL", "https://t.me/your_vpn_news").strip(),
}


def _apply_links(s: str) -> str:
    if not s or "{" not in s:
        return s
    try:
        return s.format(**_LINK_KEYS)
    except (KeyError, IndexError, ValueError):
        return s


def _build_markup(buttons: list[dict]) -> InlineKeyboardMarkup:
    """Превращает [{text, kind, value}, ...] в InlineKeyboardMarkup (по 1 в ряду)."""
    rows = []
    for b in buttons:
        text = _apply_links(b["text"])
        if b["kind"] == "url":
            url = _apply_links(b["value"])
            btn = InlineKeyboardButton(text=text, url=url)
        else:
            btn = InlineKeyboardButton(text=text, callback_data=b["value"])
        rows.append([btn])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _menu_or_fallback(menu_name: str):
    """Возвращает функцию-фабрику клавиатуры для menu_name."""
    def factory():
        buttons = content_cache.get_menu(menu_name)
        if buttons:
            return _build_markup(buttons)
        # Фолбэк — оригинальная функция из keyboards.py
        original = getattr(_default_keyboards, menu_name, None)
        if callable(original):
            return original()
        # Совсем пусто — возвращаем пустую клавиатуру
        return InlineKeyboardMarkup(inline_keyboard=[])
    factory.__name__ = menu_name
    return factory


# Публичные функции — drop-in замена
main_menu = _menu_or_fallback("main_menu")
pay_menu = _menu_or_fallback("pay_menu")
bot_menu = _menu_or_fallback("bot_menu")
vpn_menu = _menu_or_fallback("vpn_menu")
community_menu = _menu_or_fallback("community_menu")
mykey_back_keyboard = _menu_or_fallback("mykey_back_keyboard")
mykey_reset_confirm_keyboard = _menu_or_fallback("mykey_reset_confirm_keyboard")


# ============================================================
#  АВТО-ОТВЕТЫ
# ============================================================

def admin_quick_keyboard() -> InlineKeyboardMarkup:
    """Клавиатура авто-ответов оператора — собирается из БД."""
    qa = content_cache.get_qa_list()
    if not qa:
        # Фолбэк на оригинал
        original = getattr(_default_keyboards, "admin_quick_keyboard", None)
        if callable(original):
            return original()
        return InlineKeyboardMarkup(inline_keyboard=[])

    rows = [
        [InlineKeyboardButton(text=q["label"], callback_data=q["key"])]
        for q in qa
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_quick_answer_text(key: str) -> str | None:
    """Возвращает текст авто-ответа из БД (или из ADMIN_ANSWERS как fallback)."""
    text = content_cache.get_qa_text(key)
    if text is not None:
        return _apply_links(text)
    # Фолбэк на оригинальный словарь
    original = getattr(_default_keyboards, "ADMIN_ANSWERS", {})
    if key in original:
        return original[key]
    return None


def admin_quick_answer_photo_path(key: str) -> str | None:
    """
    Возвращает имя файла фото (внутри QA_PHOTOS_DIR) если у авто-ответа
    есть прикреплённое фото. Возвращает None если нет фото или ответа.

    Для обратной совместимости — возвращает только ПЕРВОЕ фото.
    Если фото несколько, используйте admin_quick_answer_photos.
    """
    photos = admin_quick_answer_photos(key)
    return photos[0] if photos else None


def admin_quick_answer_photos(key: str) -> list[str]:
    """
    Возвращает список имён файлов фотографий авто-ответа.
    Поддерживает новый JSON-формат и старый формат (одна строка).
    Возвращает [] если ответа нет или фото не прикреплено.
    """
    import json as _json
    q = content_cache.get_qa_by_key(key)
    if not q:
        return []
    raw = q.get("photo_path")
    if not raw:
        return []
    raw = str(raw).strip()
    if not raw:
        return []
    # JSON-массив
    if raw.startswith("["):
        try:
            data = _json.loads(raw)
            if isinstance(data, list):
                return [str(x).strip() for x in data if x and str(x).strip()]
        except (_json.JSONDecodeError, ValueError):
            pass
    # Старый формат
    return [raw]


# Re-экспортируем остальные функции из keyboards.py без изменений —
# те, что не редактируются через админку (например, статические article_keyboard
# для FAQ-статей с фиксированной кнопкой «Назад»).
def __getattr__(name: str):
    if hasattr(_default_keyboards, name):
        return getattr(_default_keyboards, name)
    raise AttributeError(f"module 'keyboards_proxy' has no attribute {name!r}")
