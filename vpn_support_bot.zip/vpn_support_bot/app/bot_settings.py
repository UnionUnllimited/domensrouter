"""
[v3.5] Настройки поведения бота — оперативное управление через админ-панель.

Хранятся в таблице bot_settings (key, value). value всегда строка:
  - bool: "true" / "false"
  - int:  "60"
  - text: произвольная строка

Кеш в памяти + сигнал-файл для перезагрузки — изменения из админки
подхватываются ботом за секунды без рестарта контейнера.

Использование:
    from app import bot_settings
    if bot_settings.get_bool("notify_delivery_ack"):
        await bot.send_message(..., "✅ Доставлено")

    minutes = bot_settings.get_int("ticket_rate_limit_minutes")
"""
from __future__ import annotations

import asyncio
import os
import threading
from pathlib import Path

import aiosqlite
from loguru import logger

# [v3.5] Путь к БД — то же место что и в database.py (через __file__).
# Это нужно потому что бот и админ-веб запускаются с разных рабочих
# директорий, и относительный путь не работает одинаково.
_HERE = Path(__file__).resolve().parent
_DATA_DIR = _HERE.parent / "data"
# В docker-контейнере админки путь иной: /app/bot_settings.py (а не /app/app/)
# Тогда parent = /app, data = /app/data. В боте: /app/app/bot_settings.py,
# parent.parent = /app, data = /app/data. В обоих случаях получаем /app/data
# благодаря volume ./data:/app/data в compose. Если запуск локальный — папка
# рядом с проектом.
if not _DATA_DIR.exists():
    # Альтернативный путь для контейнера админки (там __file__ в /app)
    _alt = _HERE / "data"
    if _alt.exists() or _alt.parent.name == "app":
        _DATA_DIR = _alt
try:
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass

DB_PATH = os.getenv("DB_PATH", str(_DATA_DIR / "vpn_support.db"))
SIGNAL_FILE = Path(os.getenv("SETTINGS_SIGNAL", str(_DATA_DIR / "bot_settings.signal")))

# ============================================================
#  ОПРЕДЕЛЕНИЕ ВСЕХ НАСТРОЕК
# ============================================================

# Структура: ключ → (тип, дефолт, группа, человеческое название, описание)
SETTINGS_SCHEMA = {
    # === 🔔 Уведомления оператору ===
    "notify_delivery_ack": (
        "bool", True, "notify",
        "Подтверждение доставки",
        "После каждого ответа оператора клиенту приходит "
        "тихое «✅ Доставлено» или «❌ Не доставлено».",
    ),
    "notify_undelivered": (
        "bool", True, "notify",
        "Уведомление о недоставке",
        "Если клиент заблокировал бота / удалил аккаунт / не активен — "
        "в топик приходит «❌ Не доставлено» с причиной. "
        "Выключите если эти сообщения мешают.",
    ),
    "notify_client_inactive": (
        "bool", True, "notify",
        "«Клиент не активен на сайте»",
        "Уведомление оператору в топик когда веб-клиент получил сообщение, "
        "но не открыл виджет дольше N минут (для веб-чата с виджета).",
    ),
    "client_inactive_minutes": (
        "int", 2, "notify",
        "Минут до уведомления «клиент не активен»",
        "Сколько минут ждать перед уведомлением что клиент не открыл "
        "сообщение в виджете. По умолчанию 2 минуты.",
    ),
    "notify_topic_closed": (
        "bool", True, "notify",
        "«Тикет закрыт оператором» в топик",
        "Уведомление в топик когда тикет закрыт. Включает имя оператора "
        "(кто закрыл). При закрытии из админ-панели уведомление в топик "
        "НЕ присылается (вы и так видите результат в UI).",
    ),
    "notify_operator_joined": (
        "bool", True, "notify",
        "«Оператор подключился»",
        "Уведомление в топик когда оператор впервые отвечает клиенту "
        "после AI («AI больше не отвечает»).",
    ),
    "notify_client_returned": (
        "bool", True, "notify",
        "«Клиент вернулся в чат»",
        "Уведомление в топик когда клиент пишет после закрытия тикета. "
        "Сам тикет переоткрывается независимо от этой настройки — отключается "
        "только дополнительная плашка с 🔔.",
    ),
    "ticket_header_short": (
        "bool", False, "notify",
        "Короткая шапка тикета",
        "В шапке только ID + ссылка на админку. Полная справка по командам не показывается.",
    ),
    "load_admin_info_on_ticket": (
        "bool", True, "notify",
        "Подгружать данные клиента из 3xUI",
        "При создании тикета сразу подгружаются данные о подписке клиента. "
        "Можно выключить чтобы тикеты создавались быстрее — данные подгружать командой /info.",
    ),
    # === 🔊 Звуки ===
    "sound_new_ticket": (
        "bool", True, "sound",
        "Звук при новом тикете",
        "Если выключен — новые тикеты приходят тихо.",
    ),
    "sound_client_returned": (
        "bool", True, "sound",
        "Звук при возврате клиента",
        "Если выключен — повторные обращения клиента приходят тихо.",
    ),
    "sound_operator_reply_to_client": (
        "bool", False, "sound",
        "Звук на reply клиента → группа",
        "При reply клиента на ответ оператора — звук в группу. По умолчанию тихо.",
    ),
    # === 🤖 AI и тикеты ===
    "ticket_rate_limit_minutes": (
        "int", 5, "ai",
        "Лимит создания тикетов (минуты)",
        "Сколько минут между обращениями клиента создавать тикеты. 0 = без лимита.",
    ),
    "disable_command_ban": (
        "bool", False, "ai",
        "Отключить команду /ban и кнопку «⛔️ Бан»",
        "Если включено — оператор не сможет банить клиентов случайно.",
    ),
    "timezone": (
        "select", "Europe/Moscow", "time",
        "Часовой пояс",
        "Используется для границ «сегодня / вчера / 7 дней» в статистике "
        "(дашборд, AI-метрики, список тикетов). Сохранение/выгрузка "
        "сообщений по-прежнему в UTC, меняется только отображение.",
    ),
}

# Варианты для select-настроек (рендерятся в шаблоне как <select>).
SETTINGS_OPTIONS = {
    "timezone": [
        ("Europe/Kaliningrad",  "Калининград (UTC+2)"),
        ("Europe/Moscow",       "Москва (UTC+3)"),
        ("Europe/Samara",       "Самара (UTC+4)"),
        ("Asia/Yekaterinburg",  "Екатеринбург (UTC+5)"),
        ("Asia/Omsk",           "Омск (UTC+6)"),
        ("Asia/Krasnoyarsk",    "Красноярск (UTC+7)"),
        ("Asia/Irkutsk",        "Иркутск (UTC+8)"),
        ("Asia/Yakutsk",        "Якутск (UTC+9)"),
        ("Asia/Vladivostok",    "Владивосток (UTC+10)"),
        ("Asia/Magadan",        "Магадан (UTC+11)"),
        ("Asia/Kamchatka",      "Камчатка (UTC+12)"),
        ("Europe/Minsk",        "Минск (UTC+3)"),
        ("Europe/Kiev",         "Киев (UTC+2/+3)"),
        ("Asia/Almaty",         "Алматы (UTC+5)"),
        ("Asia/Tbilisi",        "Тбилиси (UTC+4)"),
        ("Europe/London",       "Лондон (UTC+0/+1)"),
        ("UTC",                 "UTC (без сдвига)"),
    ],
}

GROUP_TITLES = {
    "notify": "🔔 Уведомления оператору",
    "sound": "🔊 Звуки в группе",
    "ai": "🤖 AI и поведение тикетов",
    "time": "🕐 Время и статистика",
}

# ============================================================
#  КЕШ
# ============================================================

_cache: dict[str, str] = {}
_lock = threading.RLock()
_last_signal_mtime: float = 0.0


def _signal_mtime() -> float:
    try:
        return SIGNAL_FILE.stat().st_mtime
    except FileNotFoundError:
        return 0.0


def _touch_signal() -> None:
    try:
        SIGNAL_FILE.parent.mkdir(parents=True, exist_ok=True)
        SIGNAL_FILE.touch(exist_ok=True)
        os.utime(SIGNAL_FILE, None)
    except Exception as e:
        logger.warning("bot_settings: touch signal failed: {}", e)


# ============================================================
#  БД
# ============================================================

async def init_settings_db() -> None:
    """Создаёт таблицу bot_settings и загружает кеш."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS bot_settings (
                key        TEXT PRIMARY KEY,
                value      TEXT NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.commit()
    await reload_cache()
    logger.info("bot_settings: загружено {} настроек", len(_cache))


async def reload_cache() -> None:
    """Полностью перечитывает кеш из БД."""
    global _last_signal_mtime
    new_cache: dict[str, str] = {}
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT key, value FROM bot_settings") as cur:
            async for row in cur:
                new_cache[row[0]] = row[1]
    with _lock:
        _cache.clear()
        _cache.update(new_cache)
        _last_signal_mtime = _signal_mtime()


async def set_value(key: str, value: str) -> None:
    """Сохраняет настройку в БД, обновляет кеш и шлёт сигнал боту."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO bot_settings (key, value, updated_at) "
            "VALUES (?, ?, CURRENT_TIMESTAMP)",
            (key, value),
        )
        await db.commit()
    with _lock:
        _cache[key] = value
    _touch_signal()
    logger.info("bot_settings: {} = {!r}", key, value[:60])


async def reset_to_default(key: str) -> None:
    """Удаляет настройку (значение возьмётся из дефолта схемы)."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM bot_settings WHERE key = ?", (key,))
        await db.commit()
    with _lock:
        _cache.pop(key, None)
    _touch_signal()


# ============================================================
#  ПРОВЕРКА СИГНАЛА (вызывается при чтении)
# ============================================================

def _signal_changed() -> bool:
    """Просто проверяем mtime сигнал-файла без обращений к event loop.
    Если изменилось — возвращаем True, чтобы async-код мог перечитать."""
    mtime = _signal_mtime()
    return mtime > _last_signal_mtime


# ============================================================
#  ПУБЛИЧНЫЕ ГЕТТЕРЫ (синхронные — для удобства использования)
# ============================================================

def _get_raw(key: str) -> str:
    """Возвращает сырое значение из БД или дефолт из схемы.

    Синхронный геттер — не пытается перечитать БД (это делает async-код
    через reload_cache при следующем удобном случае). Если сигнал
    сменился — следующий вызов reload_cache подхватит изменения.
    """
    with _lock:
        if key in _cache:
            return _cache[key]
    schema = SETTINGS_SCHEMA.get(key)
    if not schema:
        return ""
    return _format_value(schema[0], schema[1])


def _format_value(type_: str, value) -> str:
    if type_ == "bool":
        return "true" if value else "false"
    return str(value)


def get_bool(key: str, default: bool | None = None) -> bool:
    """Получить булеву настройку. Если не задана — дефолт из схемы или явный."""
    raw = _get_raw(key).strip().lower()
    if raw in ("true", "1", "yes", "on"):
        return True
    if raw in ("false", "0", "no", "off"):
        return False
    if default is not None:
        return default
    schema = SETTINGS_SCHEMA.get(key)
    return bool(schema[1]) if schema else False


def get_int(key: str, default: int | None = None) -> int:
    """Получить числовую настройку."""
    raw = _get_raw(key).strip()
    try:
        return int(raw)
    except (ValueError, TypeError):
        pass
    if default is not None:
        return default
    schema = SETTINGS_SCHEMA.get(key)
    return int(schema[1]) if schema else 0


def get_text(key: str, default: str | None = None) -> str:
    """Получить текстовую настройку."""
    raw = _get_raw(key)
    if raw:
        return raw
    if default is not None:
        return default
    schema = SETTINGS_SCHEMA.get(key)
    return str(schema[1]) if schema else ""


def get_select(key: str, default: str | None = None) -> str:
    """[v3.5] Получить выбранное значение select-настройки.
    Проверяет что значение в списке SETTINGS_OPTIONS — если нет, фоллбэк
    на дефолт схемы."""
    raw = _get_raw(key).strip()
    options = SETTINGS_OPTIONS.get(key, [])
    allowed = {value for value, _label in options}
    if raw and (not allowed or raw in allowed):
        return raw
    if default is not None:
        return default
    schema = SETTINGS_SCHEMA.get(key)
    return str(schema[1]) if schema else ""


# ============================================================
#  ХЕЛПЕРЫ ДЛЯ СТАТИСТИКИ (UTC ↔ часовой пояс из настроек)
# ============================================================

def get_timezone():
    """[v3.5] Возвращает tzinfo для часового пояса из настроек.
    Fallback на UTC при ошибке (например на старых системах без zoneinfo).
    """
    tz_name = get_select("timezone", "Europe/Moscow")
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(tz_name)
    except Exception:
        from datetime import timezone
        return timezone.utc


def get_today_start_utc():
    """[v3.5] Возвращает datetime начала «сегодня» по часовому поясу
    оператора, выраженное в UTC. Используется для границ статистики
    на дашборде («Сегодня / Вчера»).

    Пример: TZ=Europe/Moscow, сейчас 02:00 МСК (= 23:00 UTC вчера).
    Возвращает 21:00:00 UTC вчерашней даты (00:00 МСК сегодня в UTC).
    """
    from datetime import datetime, timezone
    tz = get_timezone()
    now_local = datetime.now(tz=tz)
    day_start_local = now_local.replace(hour=0, minute=0, second=0, microsecond=0)
    return day_start_local.astimezone(timezone.utc)


def get_sqlite_tz_modifier() -> str:
    """[v3.5] Возвращает SQLite-модификатор для смещения 'now' в локальное
    время. Например для UTC+3 → '+3 hours'. Используется в SQL запросах
    где надо определить границы «сегодня» через datetime('now', ...).

    Пример:
        mod = get_sqlite_tz_modifier()  # '+3 hours'
        sql = f"datetime('now', '{mod}', 'start of day', '-{mod}')"
        # → начало сегодняшнего дня в МСК, выраженное в UTC
    """
    from datetime import datetime
    tz = get_timezone()
    now = datetime.now(tz=tz)
    offset = now.utcoffset()
    if offset is None:
        return "+0 hours"
    total_minutes = int(offset.total_seconds() / 60)
    sign = "+" if total_minutes >= 0 else "-"
    h = abs(total_minutes) // 60
    m = abs(total_minutes) % 60
    if m:
        return f"{sign}{h} hours {m} minutes"
    return f"{sign}{h} hours"


def get_all() -> dict[str, dict]:
    """Возвращает все настройки сгруппированные по группам — для UI."""
    grouped: dict[str, list] = {g: [] for g in GROUP_TITLES}
    for key, (type_, default, group, label, description) in SETTINGS_SCHEMA.items():
        if type_ == "bool":
            current = get_bool(key)
        elif type_ == "int":
            current = get_int(key)
        elif type_ == "select":
            current = get_select(key)
        else:
            current = get_text(key)

        grouped[group].append({
            "key": key,
            "type": type_,
            "default": default,
            "current": current,
            "label": label,
            "description": description,
            "is_default": current == default,
            # [v3.5] для type=select — список (value, label) для UI
            "options": SETTINGS_OPTIONS.get(key, []) if type_ == "select" else None,
        })

    return {
        "groups": [
            {"id": gid, "title": GROUP_TITLES[gid], "items": grouped[gid]}
            for gid in GROUP_TITLES
        ],
    }


# ============================================================
#  [v3.5] WATCHER — фоновая задача периодически проверяет
#  signal-файл и перечитывает кеш из БД. Это даёт боту видеть
#  изменения сделанные в админке (которая в другом контейнере).
# ============================================================

_watcher_task: asyncio.Task | None = None


async def _watcher_loop(interval: float = 2.0) -> None:
    """Раз в `interval` секунд проверяем mtime signal-файла. Если
    изменился — перечитываем кеш."""
    global _last_signal_mtime
    while True:
        try:
            await asyncio.sleep(interval)
            mtime = _signal_mtime()
            if mtime > _last_signal_mtime:
                logger.info(
                    "bot_settings: detected signal change ({:.0f} > {:.0f}), "
                    "перечитываю кеш",
                    mtime, _last_signal_mtime,
                )
                await reload_cache()
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning("bot_settings watcher: {}", e)


def start_watcher(interval: float = 2.0) -> None:
    """Запускает фоновую задачу-watcher если ещё не запущена."""
    global _watcher_task
    if _watcher_task and not _watcher_task.done():
        return  # уже работает
    try:
        loop = asyncio.get_event_loop()
        _watcher_task = loop.create_task(_watcher_loop(interval))
        logger.info("bot_settings: watcher запущен (interval={}s)", interval)
    except RuntimeError as e:
        logger.warning("bot_settings: не смог запустить watcher: {}", e)
