import aiosqlite
from datetime import datetime, timedelta

import os

# БД лежит в /app/data — этот путь пробрасывается volume'ом в docker-compose,
# чтобы данные не терялись при пересборке контейнера. На локальном запуске
# (без Docker) папка создастся рядом с проектом.
_DB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
os.makedirs(_DB_DIR, exist_ok=True)
DB_PATH = os.path.join(_DB_DIR, "vpn_support.db")


# ============================================================
#  INIT DB
# ============================================================

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        # WAL-режим: чтение и запись могут идти параллельно. Это критично
        # потому что фоновые задачи (inactivity_watcher и др.) лочат БД
        # длинными запросами, а виджет в это время хочет писать
        # session/identify/messages — без WAL виджет ждёт.
        try:
            await db.execute("PRAGMA journal_mode=WAL")
            await db.execute("PRAGMA synchronous=NORMAL")
            await db.execute("PRAGMA busy_timeout=3000")
        except Exception:
            pass

        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT,
                banned INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                topic_id INTEGER,
                status TEXT DEFAULT 'open',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        # Сообщения тикетов — для просмотра истории через веб-админку.
        # direction: 'in' = от клиента, 'out' = от оператора.
        # kind: 'text' | 'photo' | 'document' | 'voice' | 'video' | 'sticker' | 'other'
        await db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER,
                user_id INTEGER,
                topic_id INTEGER,
                direction TEXT,
                kind TEXT DEFAULT 'text',
                text TEXT,
                operator_id INTEGER,
                operator_name TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_messages_ticket "
            "ON messages(ticket_id, id)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_messages_topic "
            "ON messages(topic_id, id)"
        )
        # [v3.5] Маппинг "сообщение в группе ↔ оригинал в чате клиента".
        # Нужен чтобы оператор мог reply на пересланное/зеркальное сообщение
        # клиента в группе, а клиент в боте увидел этот ответ С ЦИТАТОЙ
        # своего исходного сообщения. forward_from_message_id и
        # forward_origin у форвардов от бота работают ненадёжно — поэтому
        # храним соответствие сами.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tg_message_map (
                group_msg_id  INTEGER PRIMARY KEY,
                user_id       INTEGER NOT NULL,
                client_msg_id INTEGER NOT NULL,
                created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_tg_msg_map_user "
            "ON tg_message_map(user_id, group_msg_id)"
        )

        # [v3.5] ОБРАТНЫЙ маппинг: оператор пишет в группе → бот делает
        # copy_message клиенту → клиент видит у себя сообщение с новым id.
        # Когда клиент в боте делает reply на ответ оператора, нам надо
        # понять какому сообщению в группе соответствует то на что он
        # отвечает — и форварднуть с привязкой в группу.
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tg_operator_msg_map (
                client_received_msg_id INTEGER NOT NULL,
                user_id                INTEGER NOT NULL,
                operator_group_msg_id  INTEGER NOT NULL,
                created_at             TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, client_received_msg_id)
            )
        """)
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_op_msg_map_user "
            "ON tg_operator_msg_map(user_id, client_received_msg_id)"
        )
        # На случай если БД создана старой версией — добавим колонку banned
        try:
            await db.execute("ALTER TABLE users ADD COLUMN banned INTEGER DEFAULT 0")
        except Exception:
            pass
        # operator_joined в tickets — для AI: пометка что оператор вмешался
        # хотя бы один раз. После этого AI не отвечает в этом тикете.
        try:
            await db.execute(
                "ALTER TABLE tickets ADD COLUMN operator_joined INTEGER DEFAULT 0"
            )
        except Exception:
            pass
        await db.commit()


# ============================================================
#  USERS
# ============================================================

async def add_user(user_id: int, username: str | None):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users(id, username) VALUES (?, ?)",
            (user_id, username),
        )
        await db.execute(
            "UPDATE users SET username=? WHERE id=?",
            (username, user_id),
        )
        await db.commit()


async def is_banned(user_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT banned FROM users WHERE id=?", (user_id,)
        )
        row = await cur.fetchone()
        return bool(row and row[0])


async def set_banned(user_id: int, banned: bool):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO users(id, banned) VALUES (?, ?) "
            "ON CONFLICT(id) DO UPDATE SET banned=excluded.banned",
            (user_id, 1 if banned else 0),
        )
        await db.commit()


# ============================================================
#  TICKETS
# ============================================================

async def create_ticket(user_id: int):
    """[v3.5] Создаёт тикет с rate-limit из настроек (по умолчанию 5 минут).
       0 минут = без лимита.
       Возвращает ticket_id или None, если слишком рано."""
    # Берём лимит из настроек бота
    try:
        from app import bot_settings as _bs
        rate_min = _bs.get_int("ticket_rate_limit_minutes")
    except Exception:
        rate_min = 5

    async with aiosqlite.connect(DB_PATH) as db:
        if rate_min > 0:
            cur = await db.execute(
                "SELECT created_at FROM tickets WHERE user_id=? "
                "ORDER BY created_at DESC LIMIT 1",
                (user_id,),
            )
            row = await cur.fetchone()
            if row:
                last = datetime.fromisoformat(row[0])
                if datetime.utcnow() - last < timedelta(minutes=rate_min):
                    return None

        cur = await db.execute(
            "INSERT INTO tickets(user_id) VALUES (?)", (user_id,)
        )
        await db.commit()
        return cur.lastrowid


async def save_topic(ticket_id: int, topic_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE tickets SET topic_id=? WHERE id=?",
            (topic_id, ticket_id),
        )
        await db.commit()


# ============================================================
#  [v3.5] МАППИНГ TG-СООБЩЕНИЙ для reply оператор ↔ клиент
# ============================================================

async def save_tg_message_map(
    group_msg_id: int, user_id: int, client_msg_id: int,
) -> None:
    """[v3.5] Запоминает: «сообщение N в группе соответствует сообщению M
    в чате клиента user_id».

    Используется когда:
    - Клиент пишет в бот → forward в группу → сохраняем (group_id → client_id)
    - AI зеркалит клиентское сообщение в ghost-topic → тоже сохраняем

    Потом если оператор делает reply на это сообщение в группе, мы
    находим оригинал в чате клиента и копируем ответ с reply_to.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO tg_message_map "
            "(group_msg_id, user_id, client_msg_id) VALUES (?, ?, ?)",
            (group_msg_id, user_id, client_msg_id),
        )
        await db.commit()


async def get_client_msg_id(group_msg_id: int) -> tuple[int, int] | None:
    """[v3.5] По id сообщения в группе возвращает (user_id, client_msg_id)
    или None если маппинга нет."""
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT user_id, client_msg_id FROM tg_message_map "
            "WHERE group_msg_id = ?",
            (group_msg_id,),
        )
        row = await cur.fetchone()
        return (int(row[0]), int(row[1])) if row else None


async def save_operator_msg_map(
    user_id: int, client_received_msg_id: int, operator_group_msg_id: int,
) -> None:
    """[v3.5] Запоминает: «сообщение M в чате клиента user_id — это копия
    сообщения N оператора в группе поддержки».

    Используется когда оператор отвечает клиенту через copy_message:
    нужно сохранить связь, чтобы потом если клиент сделает reply на этот
    ответ — мы могли форварднуть в группу с привязкой к оригиналу
    оператора.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR REPLACE INTO tg_operator_msg_map "
            "(user_id, client_received_msg_id, operator_group_msg_id) "
            "VALUES (?, ?, ?)",
            (user_id, client_received_msg_id, operator_group_msg_id),
        )
        await db.commit()


async def get_operator_group_msg_id(
    user_id: int, client_received_msg_id: int,
) -> int | None:
    """[v3.5] По id сообщения в чате клиента возвращает id оригинального
    сообщения оператора в группе или None.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT operator_group_msg_id FROM tg_operator_msg_map "
            "WHERE user_id = ? AND client_received_msg_id = ?",
            (user_id, client_received_msg_id),
        )
        row = await cur.fetchone()
        return int(row[0]) if row else None


async def get_user_by_topic(topic_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT user_id FROM tickets WHERE topic_id=? "
            "ORDER BY id DESC LIMIT 1",
            (topic_id,),
        )
        row = await cur.fetchone()
        return row[0] if row else None


async def get_user_open_ticket(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT id, topic_id FROM tickets "
            "WHERE user_id=? AND status='open'",
            (user_id,),
        )
        row = await cur.fetchone()
        if row:
            return {"id": row[0], "topic_id": row[1]}
        return None


async def get_user_topic(user_id: int):
    """Последний topic_id пользователя (даже если тикет закрыт) — переиспользуем."""
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT topic_id FROM tickets "
            "WHERE user_id=? AND topic_id IS NOT NULL "
            "ORDER BY id DESC LIMIT 1",
            (user_id,),
        )
        row = await cur.fetchone()
        return row[0] if row else None


async def close_ticket_db(topic_id: int) -> int | None:
    """
    Закрывает тикет(ы) с этим topic_id.
    Возвращает user_id владельца тикета (чтобы upstream мог очистить
    его AI-историю и сбросить флаги). None если тикет не найден. [v3.5]

    [v3.5] Закрывает ВСЕ open тикеты этого клиента, не только с указанным
    topic_id. Иначе при модели "1 клиент = 1 вечный тикет" могут оставаться
    исторические open тикеты, которые мешают переоткрытию при возврате.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        # Сначала достанем user_id из активного тикета этого топика
        cur = await db.execute(
            "SELECT user_id FROM tickets WHERE topic_id = ? "
            "AND status = 'open' ORDER BY id DESC LIMIT 1",
            (topic_id,),
        )
        row = await cur.fetchone()
        user_id = int(row[0]) if row else None

        if user_id:
            # Закрываем ВСЕ открытые тикеты этого клиента
            await db.execute(
                "UPDATE tickets SET status='closed' "
                "WHERE user_id=? AND status='open'",
                (user_id,),
            )
        else:
            # Резервный путь — закрываем по topic_id (если user не найден)
            await db.execute(
                "UPDATE tickets SET status='closed' WHERE topic_id=?",
                (topic_id,),
            )
        await db.commit()
        return user_id


async def mark_ticket_operator_joined(user_id: int) -> None:
    """
    Помечает что оператор подключился к ПОСЛЕДНЕМУ тикету клиента.
    После этого AI больше не отвечает в этом тикете.

    [v3.5 fix] Раньше фильтровали по status='open' — но в v3.5-модели
    «один клиент = один вечный тикет» AI-ghost тикеты имеют status='closed'
    пока AI справляется. Из-за фильтра флаг не выставлялся, и AI
    продолжал отвечать после оператора в TG. Теперь помечаем последний
    тикет клиента независимо от статуса.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE tickets SET operator_joined = 1 "
            "WHERE id = ("
            "  SELECT id FROM tickets WHERE user_id = ? "
            "  ORDER BY id DESC LIMIT 1"
            ")",
            (user_id,),
        )
        await db.commit()


async def is_ticket_operator_joined(user_id: int) -> bool:
    """Подключался ли оператор к ПОСЛЕДНЕМУ тикету клиента?

    [v3.5 fix] Без фильтра status — см. mark_ticket_operator_joined.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT operator_joined FROM tickets "
            "WHERE user_id = ? "
            "ORDER BY id DESC LIMIT 1",
            (user_id,),
        )
        row = await cur.fetchone()
        return bool(row[0]) if row else False


async def did_ai_respond_in_ticket(ticket_id: int) -> bool:
    """[v3.5] Был ли хотя бы один ответ AI в этом тикете.

    Используется чтобы показывать уведомление «AI больше не отвечает»
    ТОЛЬКО когда AI реально работал. Если оператор сразу отвечал клиенту
    без AI — уведомление не имеет смысла и не приходит.

    Сообщения AI сохраняются с operator_name='AI'.
    """
    if not ticket_id:
        return False
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT 1 FROM messages "
            "WHERE ticket_id = ? AND operator_name = 'AI' "
            "LIMIT 1",
            (ticket_id,),
        )
        return await cur.fetchone() is not None


# ============================================================
#  MESSAGES (история переписки в тикетах)
# ============================================================

async def save_message(
    *,
    ticket_id: int | None,
    user_id: int | None,
    topic_id: int | None,
    direction: str,           # 'in' | 'out'
    kind: str = "text",       # 'text' | 'photo' | 'document' | 'voice' | 'video' | ...
    text: str | None = None,
    operator_id: int | None = None,
    operator_name: str | None = None,
) -> None:
    """
    Сохраняет одно сообщение тикета. Безопасно вызывать с None в любом поле —
    если нет ticket_id, всё равно запишет (потом можно найти по topic_id).
    """
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO messages
              (ticket_id, user_id, topic_id, direction, kind, text,
               operator_id, operator_name)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                ticket_id, user_id, topic_id, direction, kind, text,
                operator_id, operator_name,
            ),
        )
        await db.commit()


# ============================================================
#  [v3.5] НОВАЯ ЛОГИКА ТИКЕТОВ: один клиент = один вечный тикет
#  Тикет создаётся при первом контакте (status='closed') и потом
#  переключается между closed/open при эскалациях.
# ============================================================

async def get_last_ticket_for_user(user_id: int) -> dict | None:
    """Возвращает последний тикет клиента (любой статус) или None."""
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT id, topic_id, status FROM tickets "
            "WHERE user_id=? ORDER BY id DESC LIMIT 1",
            (user_id,),
        )
        row = await cur.fetchone()
        if not row:
            return None
        return {"id": row[0], "topic_id": row[1], "status": row[2]}


async def get_or_create_ticket(user_id: int) -> dict:
    """
    [v3.5] Возвращает тикет клиента. Если у клиента нет тикета —
    создаёт новый со статусом 'closed' (тикет на будущее, для накопления
    AI-истории до того как клиент эскалирует).

    Логика: один клиент = один вечный тикет.
    """
    existing = await get_last_ticket_for_user(user_id)
    if existing:
        return existing
    # Нет тикета — создаём новый со status='closed'
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO tickets(user_id, status) VALUES (?, 'closed')",
            (user_id,),
        )
        await db.commit()
        return {"id": cur.lastrowid, "topic_id": None, "status": "closed"}


async def reopen_ticket(ticket_id: int) -> None:
    """[v3.5] Переключает status='closed' → 'open' (для эскалации)."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE tickets SET status='open' WHERE id=?",
            (ticket_id,),
        )
        await db.commit()
