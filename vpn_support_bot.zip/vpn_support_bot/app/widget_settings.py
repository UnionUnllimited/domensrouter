"""
Настройки виджета веб-чата.

Хранятся в БД (таблица widget_settings, одна строка с JSON).
Редактируются из админки, читаются виджетом и API при каждом запросе.

Дефолты в коде — используются если в БД ничего нет.
"""

from __future__ import annotations

import json
import os
from typing import Any

import aiosqlite

from app.database import DB_PATH


# Дефолтные настройки. Применяются для свежей установки бота.
DEFAULT_SETTINGS: dict[str, Any] = {
    # Публичный URL админки
    "public_url": "",

    # Внешний вид
    "primary_color": "#ff8c42",
    "position": "bottom-right",
    "brand_name": "VPN Support",
    "operator_label": "Оператор",      # подпись над сообщениями оператора в виджете
    "welcome_text": "👋 Привет! Чем можем помочь?",
    "placeholder": "Напишите сообщение...",
    "send_button_text": "Отправить",
    "offline_text": "Сейчас мы офлайн. Напишите — ответим как только сможем.",

    # Размер кнопки-launcher (S/M/L)
    "button_size": "M",
    # [v3.5] Форма кнопки-launcher: circle (круглая, классика),
    # square (закруглённый квадрат), squircle (мягкий квадрат),
    # pill (прямоугольная с названием бота)
    "button_shape": "circle",
    # Название бота на кнопке (показывается только при button_shape == "pill")
    "button_label": "VPN Support",
    # Иконка кнопки
    "button_icon": "💬",
    # Размер окна чата (S/M/L)
    "window_size": "M",
    # Форма окна: default | wide (шире для длинных текстов) | rounded (мягкое со скругленными углами)
    "window_shape": "default",
    # Стиль пузырьков сообщений (rounded/square/soft/bordered/minimal)
    "bubble_style": "rounded",
    # Авто-открытие чата через N секунд (0 = не открывать)
    "auto_open_seconds": 0,
    # Звук при новом сообщении
    "sound_enabled": True,
    # Прикрепление файлов
    "uploads_enabled": True,
    # Аватарка оператора (URL картинки или эмодзи). Если пусто — первая буква бренда
    "operator_avatar": "",

    # ===== Кастомизация темы (v3.2) =====
    # Прозрачность окна виджета: 0.5 (полупрозрачное) .. 1.0 (непрозрачное)
    "window_opacity": 1.0,

    # Цвет шапки виджета. Если пусто — используется primary_color.
    "header_color": "",
    # Включить градиент шапки. Если включено — header_color это начало,
    # header_color_to — конец градиента (по диагонали).
    "header_gradient": False,
    "header_color_to": "",

    # Цвет фона окна виджета (область с сообщениями). Если пусто — авто (тёмный).
    "window_bg_color": "",
    "window_bg_gradient": False,
    "window_bg_color_to": "",

    # Цвет пузырьков сообщений от клиента (out: справа в виджете)
    "msg_out_color": "",
    "msg_out_gradient": False,
    "msg_out_color_to": "",

    # Цвет пузырьков сообщений от оператора (in: слева)
    "msg_in_color": "",
    "msg_in_gradient": False,
    "msg_in_color_to": "",

    # Цвет фона формы ввода внизу. Если пусто — авто.
    "input_bg_color": "",

    # Часы работы
    "always_online": True,
    "work_hours_from": "09:00",
    "work_hours_to": "21:00",
    "work_timezone": "Europe/Moscow",

    # CORS — список доменов
    "allowed_origins": ["*"],

    "allow_identify": True,
}


_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS widget_settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    data TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


async def init_widget_settings() -> None:
    """Создаёт таблицу. Безопасно вызывать многократно."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(_TABLE_SQL)
        await db.commit()


async def get_settings() -> dict[str, Any]:
    """Читает настройки. Если в БД нет — возвращает дефолты."""
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT data FROM widget_settings WHERE id = 1")
        row = await cur.fetchone()

    if not row:
        return dict(DEFAULT_SETTINGS)

    try:
        stored = json.loads(row[0])
    except (json.JSONDecodeError, TypeError):
        return dict(DEFAULT_SETTINGS)

    # Мержим — на случай если в коде появились новые поля
    result = dict(DEFAULT_SETTINGS)
    result.update(stored)
    return result


async def save_settings(data: dict[str, Any]) -> tuple[bool, str]:
    """Сохраняет настройки. Валидирует входные данные."""
    # Валидация
    if not isinstance(data, dict):
        return False, "Невалидные данные"

    # public_url — опционально, но если задан — должен быть валидным URL
    public_url = data.get("public_url", "")
    if not isinstance(public_url, str):
        return False, "public_url должен быть строкой"
    if public_url:
        # Удаляем хвостовой / для единообразия
        public_url = public_url.rstrip("/")
        if not (public_url.startswith("http://") or public_url.startswith("https://")):
            return False, (
                "Адрес должен начинаться с http:// или https:// "
                "(например https://your-domain.com)"
            )
        if len(public_url) > 200:
            return False, "Слишком длинный URL"
        # Проверяем что нет пути после домена (только https://domain[:port])
        from urllib.parse import urlparse
        try:
            parsed = urlparse(public_url)
        except Exception:
            return False, "Невалидный URL"
        if parsed.path and parsed.path != "/":
            return False, (
                "Укажите только домен без пути. Например: "
                "https://your-domain.com — БЕЗ /admin или /widget"
            )
        if not parsed.netloc:
            return False, "Не указан домен"
        data["public_url"] = public_url

    # Цвет — должен быть HEX
    color = data.get("primary_color", "")
    if not isinstance(color, str) or not color.startswith("#") or len(color) not in (4, 7):
        return False, "primary_color должен быть HEX-цветом (например #ff8c42)"

    # Позиция
    if data.get("position") not in ("bottom-right", "bottom-left"):
        return False, "position должна быть bottom-right или bottom-left"

    # Тексты
    for field in ("brand_name", "operator_label", "welcome_text", "placeholder",
                  "send_button_text", "offline_text", "operator_avatar"):
        val = data.get(field, "")
        if not isinstance(val, str):
            return False, f"{field} должен быть строкой"
        if len(val) > 500:
            return False, f"{field} слишком длинный (>500)"

    # Размеры и стили
    if data.get("button_size") not in ("S", "M", "L"):
        data["button_size"] = "M"
    # button_label — название бота на pill-кнопке
    bl = data.get("button_label", "")
    if not isinstance(bl, str) or len(bl) > 40:
        data["button_label"] = "VPN Support"
    if data.get("window_size") not in ("S", "M", "L"):
        data["window_size"] = "M"
    if data.get("window_shape") not in ("default", "wide", "rounded"):
        data["window_shape"] = "default"
    # [v3.5] Форма кнопки: circle (классика), square (с закруглением),
    # squircle (мягкий квадрат), pill (прямоугольная с надписью).
    # Старая валидация на round/square/pill — устарела, удалена.
    if data.get("button_shape") not in ("circle", "square", "squircle", "pill"):
        data["button_shape"] = "circle"
    if data.get("bubble_style") not in ("rounded", "square", "minimal", "bordered", "soft"):
        data["bubble_style"] = "rounded"

    # auto_open_seconds
    try:
        a = int(data.get("auto_open_seconds", 0))
        data["auto_open_seconds"] = max(0, min(300, a))
    except (TypeError, ValueError):
        data["auto_open_seconds"] = 0

    # CORS — список строк
    origins = data.get("allowed_origins", [])
    if not isinstance(origins, list):
        return False, "allowed_origins должен быть списком"
    for o in origins:
        if not isinstance(o, str):
            return False, "Origin должен быть строкой"
        if o != "*" and not (o.startswith("http://") or o.startswith("https://")):
            return False, f"Origin '{o}' должен начинаться с http:// или https://"
        if len(o) > 200:
            return False, "Origin слишком длинный"

    # always_online — bool
    if not isinstance(data.get("always_online"), bool):
        return False, "always_online должен быть true/false"

    # Часы работы — HH:MM
    import re
    time_re = re.compile(r"^([01]?\d|2[0-3]):[0-5]\d$")
    if not time_re.match(data.get("work_hours_from", "")):
        return False, "work_hours_from должен быть в формате HH:MM"
    if not time_re.match(data.get("work_hours_to", "")):
        return False, "work_hours_to должен быть в формате HH:MM"

    # === Новые поля темы (v3.2) ===
    # window_opacity — float 0.3..1.0
    try:
        op = float(data.get("window_opacity", 1.0))
        data["window_opacity"] = max(0.3, min(1.0, op))
    except (TypeError, ValueError):
        data["window_opacity"] = 1.0

    # HEX-цвета (опциональные — пустая строка = не задан)
    hex_re = re.compile(r"^#[0-9A-Fa-f]{3}([0-9A-Fa-f]{3})?$")
    for key in (
        "header_color", "header_color_to",
        "window_bg_color", "window_bg_color_to",
        "msg_out_color", "msg_out_color_to",
        "msg_in_color", "msg_in_color_to",
        "input_bg_color",
    ):
        val = data.get(key, "")
        if not isinstance(val, str):
            data[key] = ""
            continue
        val = val.strip()
        if val and not hex_re.match(val):
            return False, f"{key} должен быть HEX-цветом (например #336699)"
        data[key] = val

    # Bool-флаги градиентов
    for key in ("header_gradient", "window_bg_gradient",
                "msg_out_gradient", "msg_in_gradient"):
        data[key] = bool(data.get(key, False))

    # Сохраняем
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO widget_settings (id, data, updated_at)
            VALUES (1, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(id) DO UPDATE SET
                data = excluded.data,
                updated_at = CURRENT_TIMESTAMP
            """,
            (json.dumps(data, ensure_ascii=False),),
        )
        await db.commit()

    return True, "Настройки сохранены"


def get_settings_sync() -> dict[str, Any]:
    """
    Синхронный вызов для FastAPI роутов.
    Использует asyncio.run в отдельном потоке — безопасно для async-контекста.
    """
    import asyncio
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as ex:
                return ex.submit(asyncio.run, get_settings()).result()
        return loop.run_until_complete(get_settings())
    except RuntimeError:
        return asyncio.run(get_settings())


def save_settings_sync(data: dict[str, Any]) -> tuple[bool, str]:
    import asyncio
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as ex:
                return ex.submit(asyncio.run, save_settings(data)).result()
        return loop.run_until_complete(save_settings(data))
    except RuntimeError:
        return asyncio.run(save_settings(data))


def _normalize_origin(s: str) -> str:
    """
    Нормализует строку домена/Origin для сравнения.
    Примеры:
      'https://moremore.pro/'        → 'moremore.pro'
      'https://moremore.pro/cabinet' → 'moremore.pro'
      'http://www.moremore.pro:443'  → 'www.moremore.pro'
      'moremore.pro'                 → 'moremore.pro'
    """
    if not s:
        return ""
    s = s.strip().lower()
    # Срезаем схему
    for scheme in ("https://", "http://", "//"):
        if s.startswith(scheme):
            s = s[len(scheme):]
            break
    # Срезаем путь и query
    for sep in ("/", "?", "#"):
        if sep in s:
            s = s.split(sep, 1)[0]
    # Срезаем порт (но только стандартные — для других может быть значимым,
    # хотя для веб-виджета на нестандартном порте — крайне редкий случай)
    if ":" in s:
        host, _, port = s.partition(":")
        # Срезаем порт только если это 80 или 443 (стандартные)
        if port in ("80", "443", ""):
            s = host
    return s


def is_origin_allowed(origin: str, settings: dict) -> bool:
    """
    Проверяет что Origin в whitelist'е.
    Сравнение делается по нормализованной форме (без схемы, порта, пути,
    регистра) — то есть пользователь может вводить домен в любом виде:
      moremore.pro
      https://moremore.pro
      https://moremore.pro/
      https://moremore.pro/cabinet
    Все эти варианты эквивалентны.

    Также поддерживается wildcard для поддоменов:
      *.example.com  → app.example.com, www.example.com, sub.example.com
    """
    if not origin:
        return False
    allowed = settings.get("allowed_origins", [])
    if not allowed:
        return False
    # Звёздочка — разрешаем всё
    if "*" in allowed:
        return True

    origin_norm = _normalize_origin(origin)
    if not origin_norm:
        return False

    for a in allowed:
        a_str = (a or "").strip()
        if not a_str:
            continue
        # Wildcard для поддоменов: *.example.com
        if a_str.startswith("*."):
            base = _normalize_origin(a_str[2:])
            if origin_norm == base or origin_norm.endswith("." + base):
                return True
            continue
        # Обычное точное совпадение по нормализованной форме
        a_norm = _normalize_origin(a_str)
        if a_norm and origin_norm == a_norm:
            return True

    return False
