# app/admin_panel.py
"""
Асинхронный клиент к админ-панели 3XUIStore.

Логинится по паролю (POST /login с полем `password`), хранит сессионную cookie
в памяти, автоматически перелогинивается при 302→/login или 401/403.

Ходит только в read-only JSON-эндпоинты:
  GET /api/users/{telegram_id}            — основная информация
  GET /api/users/{telegram_id}/security   — устройства, последний IP, HWID
  GET /api/users/{telegram_id}/keys       — VLESS-ссылки клиента
  GET /users/{telegram_id}/traffic        — трафик по серверам 3X-UI

Кэширует ответы на 60 секунд, чтобы не долбить админку при каждом сообщении
в тикете.

ВАЖНО: модуль НЕ делает изменяющих запросов (renew, block, delete). Если
понадобится — добавим отдельно с явным подтверждением оператора.
"""

import asyncio
import time
from typing import Any
from urllib.parse import urljoin

import aiohttp
from loguru import logger


# ============================================================
#  Конфиг (читается один раз при импорте)
# ============================================================

import os

ADMIN_BASE_URL = os.getenv(
    "ADMIN_BASE_URL",
    "https://ltefreemore.online/FixPakapassFGg_g34/"
).rstrip("/") + "/"
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "").strip()
ADMIN_CACHE_TTL = int(os.getenv("ADMIN_CACHE_TTL", "60"))  # секунд
ADMIN_REQUEST_TIMEOUT = int(os.getenv("ADMIN_REQUEST_TIMEOUT", "10"))


# ============================================================
#  Клиент
# ============================================================

class AdminPanelClient:
    """
    Один экземпляр на всё приложение. Создаётся в main.py при старте и
    переиспользуется. Внутри держит aiohttp.ClientSession с cookie jar.
    """

    def __init__(self) -> None:
        self._session: aiohttp.ClientSession | None = None
        self._login_lock = asyncio.Lock()  # чтобы не логиниться параллельно
        self._authed = False
        self._cache: dict[str, tuple[float, Any]] = {}  # key -> (ts, data)
        self._cache_lock = asyncio.Lock()

    # --------------------------------------------------------
    #  Lifecycle
    # --------------------------------------------------------

    async def start(self) -> None:
        """Вызывается один раз при старте бота."""
        if self._session is not None:
            return
        logger.info("admin_panel: использую URL {}", ADMIN_BASE_URL)
        timeout = aiohttp.ClientTimeout(total=ADMIN_REQUEST_TIMEOUT)
        # Свой cookie jar, изолированный от любых других сессий
        jar = aiohttp.CookieJar(unsafe=False)
        self._session = aiohttp.ClientSession(
            timeout=timeout,
            cookie_jar=jar,
            headers={"User-Agent": "vpn-support-bot/1.0"},
        )
        if not ADMIN_PASSWORD:
            logger.warning(
                "ADMIN_PASSWORD не задан в .env — интеграция с админкой "
                "отключена, шапка тикета будет без расширенной инфы."
            )

    async def close(self) -> None:
        if self._session is not None:
            await self._session.close()
            self._session = None
        self._authed = False

    # --------------------------------------------------------
    #  Авторизация
    # --------------------------------------------------------

    async def _login(self) -> bool:
        """
        POST /login с полем password. Ожидаем 302 → /users.
        Возвращает True при успехе.
        """
        if not ADMIN_PASSWORD or self._session is None:
            return False

        async with self._login_lock:
            if self._authed:
                # Кто-то параллельно уже залогинился, пока мы ждали lock
                return True

            url = urljoin(ADMIN_BASE_URL, "login")
            try:
                async with self._session.post(
                    url,
                    data={"password": ADMIN_PASSWORD},
                    allow_redirects=False,
                ) as resp:
                    if resp.status in (302, 303):
                        location = resp.headers.get("Location", "")
                        # При успехе админка редиректит на /users
                        if "/users" in location or "login" not in location:
                            self._authed = True
                            logger.info(
                                "admin_panel: успешный логин (redirect → {})",
                                location,
                            )
                            return True
                        logger.error(
                            "admin_panel: логин не принят, редирект на {}",
                            location,
                        )
                        return False
                    if resp.status == 200:
                        # Некоторые версии при ошибке отдают 200 с формой
                        text = await resp.text()
                        if "Неверный" in text or "password" in text.lower():
                            logger.error(
                                "admin_panel: неверный пароль (200 с формой)"
                            )
                            return False
                        # 200 без редиректа — необычно, считаем успехом
                        self._authed = True
                        return True
                    logger.error(
                        "admin_panel: логин вернул HTTP {}",
                        resp.status,
                    )
                    return False
            except asyncio.TimeoutError:
                logger.error("admin_panel: таймаут при логине")
                return False
            except aiohttp.ClientError as e:
                logger.error("admin_panel: ошибка сети при логине: {}", e)
                return False

    # --------------------------------------------------------
    #  Низкоуровневый GET с авто-релогином
    # --------------------------------------------------------

    async def _get_json(self, path: str) -> dict | None:
        """
        GET-запрос к админке. Если сессия истекла (редирект на /login
        или 401/403) — релогинимся и повторяем один раз.
        """
        if self._session is None or not ADMIN_PASSWORD:
            return None

        if not self._authed:
            ok = await self._login()
            if not ok:
                return None

        url = urljoin(ADMIN_BASE_URL, path.lstrip("/"))

        for attempt in (1, 2):
            try:
                async with self._session.get(
                    url,
                    allow_redirects=False,
                    headers={"Accept": "application/json"},
                ) as resp:
                    # Сессия истекла — админка редиректит на /login
                    if resp.status in (302, 303):
                        location = resp.headers.get("Location", "")
                        if "login" in location:
                            logger.info(
                                "admin_panel: сессия истекла, релогин (попытка {})",
                                attempt,
                            )
                            self._authed = False
                            if attempt == 1:
                                ok = await self._login()
                                if ok:
                                    continue
                            return None
                        # Какой-то другой редирект — не наш случай
                        logger.warning(
                            "admin_panel: неожиданный редирект {} → {}",
                            url, location,
                        )
                        return None

                    if resp.status in (401, 403):
                        logger.info(
                            "admin_panel: {} вернул {}, релогин",
                            url, resp.status,
                        )
                        self._authed = False
                        if attempt == 1:
                            ok = await self._login()
                            if ok:
                                continue
                        return None

                    if resp.status == 404:
                        logger.debug("admin_panel: {} → 404", url)
                        return None

                    if resp.status != 200:
                        logger.warning(
                            "admin_panel: {} → HTTP {}",
                            url, resp.status,
                        )
                        return None

                    # Проверяем Content-Type
                    ct = resp.headers.get("Content-Type", "")
                    if "application/json" not in ct:
                        # Иногда админка отдаёт HTML с логин-формой даже без редиректа
                        text_preview = (await resp.text())[:200]
                        if "<form" in text_preview and "password" in text_preview:
                            logger.info(
                                "admin_panel: получили HTML логина вместо JSON, релогин"
                            )
                            self._authed = False
                            if attempt == 1:
                                ok = await self._login()
                                if ok:
                                    continue
                            return None
                        logger.warning(
                            "admin_panel: {} вернул не JSON (Content-Type={})",
                            url, ct,
                        )
                        return None

                    try:
                        return await resp.json()
                    except (aiohttp.ContentTypeError, ValueError) as e:
                        logger.warning(
                            "admin_panel: не смог распарсить JSON от {}: {}",
                            url, e,
                        )
                        return None

            except asyncio.TimeoutError:
                logger.warning(
                    "admin_panel: таймаут на {} (попытка {})",
                    url, attempt,
                )
                if attempt == 2:
                    return None
            except aiohttp.ClientError as e:
                logger.warning(
                    "admin_panel: ошибка сети на {}: {} (попытка {})",
                    url, e, attempt,
                )
                if attempt == 2:
                    return None

        return None

    # --------------------------------------------------------
    #  Кэш
    # --------------------------------------------------------

    async def _cached_get(self, cache_key: str, path: str) -> dict | None:
        async with self._cache_lock:
            now = time.time()
            if cache_key in self._cache:
                ts, data = self._cache[cache_key]
                if now - ts < ADMIN_CACHE_TTL:
                    return data

        data = await self._get_json(path)

        async with self._cache_lock:
            self._cache[cache_key] = (time.time(), data)
            # Простая очистка: если в кэше больше 500 записей, выкидываем
            # все старше TTL*2
            if len(self._cache) > 500:
                threshold = time.time() - ADMIN_CACHE_TTL * 2
                self._cache = {
                    k: v for k, v in self._cache.items() if v[0] > threshold
                }
        return data

    def invalidate(self, telegram_id: int | str) -> None:
        """Сбросить кэш для конкретного пользователя (например, по кнопке «Обновить»)."""
        tid = str(telegram_id)
        keys_to_remove = [k for k in self._cache if tid in k]
        for k in keys_to_remove:
            self._cache.pop(k, None)

    # --------------------------------------------------------
    #  Высокоуровневые методы
    # --------------------------------------------------------

    async def get_user(self, telegram_id: int) -> dict | None:
        """
        Возвращает payload эндпоинта /api/users/{id} как есть (или None).
        Структура (исходя из реальной админки): {ok: True, data: {user: {...}, remnawave: {...}, payments: [...], ...}}
        """
        return await self._cached_get(
            f"user:{telegram_id}",
            f"api/users/{telegram_id}",
        )

    async def get_security(self, telegram_id: int) -> dict | None:
        return await self._cached_get(
            f"security:{telegram_id}",
            f"api/users/{telegram_id}/security",
        )

    async def get_keys(self, telegram_id: int) -> dict | None:
        return await self._cached_get(
            f"keys:{telegram_id}",
            f"api/users/{telegram_id}/keys",
        )

    # --------------------------------------------------------
    #  ИЗМЕНЯЮЩИЕ ЗАПРОСЫ (требуют осторожности!)
    # --------------------------------------------------------

    async def revoke_subscription(self, telegram_id: int) -> tuple[bool, str]:
        """
        Сброс подписки клиента: генерирует новые UUID, инвалидирует старые
        ключи. Эндпоинт POST /api/users/{id}/revoke-subscription.

        Админка отдаёт ответ как Server-Sent Events:
            data: {"step": 1}
            data: {"step": 2}
            ...
            data: {"complete": true}

        Возвращает (success: bool, message: str). Сообщение подходит для
        показа оператору.
        """
        if not ADMIN_PASSWORD or self._session is None:
            return False, "ADMIN_PASSWORD не задан в .env"

        if not self._authed:
            ok = await self._login()
            if not ok:
                return False, "Не удалось залогиниться в админку"

        url = urljoin(ADMIN_BASE_URL, f"api/users/{telegram_id}/revoke-subscription")

        for attempt in (1, 2):
            try:
                # Таймаут для SSE — больше обычного, операция небыстрая
                timeout = aiohttp.ClientTimeout(total=60)
                async with self._session.post(
                    url,
                    headers={
                        "Accept": "application/json, text/event-stream",
                        "X-Requested-With": "XMLHttpRequest",
                    },
                    allow_redirects=False,
                    timeout=timeout,
                ) as resp:
                    # Сессия истекла — релогин и повтор
                    if resp.status in (302, 303, 401, 403):
                        logger.info(
                            "admin_panel.revoke: статус {}, релогин (попытка {})",
                            resp.status, attempt,
                        )
                        self._authed = False
                        if attempt == 1:
                            ok = await self._login()
                            if ok:
                                continue
                        return False, "Сессия истекла, попробуй ещё раз"

                    if resp.status == 404:
                        return False, "Клиент не найден в админке (404)"

                    if resp.status >= 500:
                        return False, f"Админка вернула HTTP {resp.status}"

                    if resp.status != 200:
                        return False, f"Неожиданный статус: HTTP {resp.status}"

                    ct = resp.headers.get("Content-Type", "")
                    last_step = 0
                    error_msg: str | None = None
                    completed = False

                    if "text/event-stream" in ct:
                        # SSE-стрим: читаем построчно
                        import json
                        async for raw_line in resp.content:
                            line = raw_line.decode("utf-8", errors="replace").strip()
                            if not line.startswith("data:"):
                                continue
                            payload_str = line[5:].strip()
                            if not payload_str:
                                continue
                            try:
                                event = json.loads(payload_str)
                            except json.JSONDecodeError:
                                continue
                            if isinstance(event, dict):
                                if "step" in event:
                                    try:
                                        last_step = int(event["step"])
                                    except (TypeError, ValueError):
                                        pass
                                if event.get("error"):
                                    error_msg = str(event["error"])
                                if event.get("complete"):
                                    completed = True
                                    break
                    else:
                        # Обычный JSON-ответ (на случай, если админка изменит формат)
                        try:
                            data = await resp.json()
                        except (aiohttp.ContentTypeError, ValueError):
                            return False, "Не удалось распарсить ответ админки"
                        if isinstance(data, dict):
                            if data.get("ok") or data.get("complete"):
                                completed = True
                            if data.get("error"):
                                error_msg = str(data["error"])

                    # Инвалидируем кэш — данные клиента точно изменились
                    self.invalidate(telegram_id)

                    if error_msg:
                        return False, f"Админка вернула ошибку: {error_msg}"
                    if completed:
                        return True, "Подписка сброшена (новые UUID и ключи сгенерированы)"
                    if last_step > 0:
                        return False, (
                            f"Операция прервалась на шаге {last_step}/6. "
                            "Проверь админку — возможно, часть серверов недоступна."
                        )
                    return False, "Админка не подтвердила завершение операции"

            except asyncio.TimeoutError:
                logger.warning(
                    "admin_panel.revoke: таймаут (попытка {})", attempt,
                )
                if attempt == 2:
                    return False, "Таймаут запроса к админке (60 сек). Проверь админку вручную — операция могла частично выполниться."
            except aiohttp.ClientError as e:
                logger.warning("admin_panel.revoke: ошибка сети: {}", e)
                if attempt == 2:
                    return False, f"Ошибка сети: {e}"

        return False, "Не удалось выполнить сброс"

    # --------------------------------------------------------
    #  POST формы (universal) — для renew/reduce и т.п.
    # --------------------------------------------------------

    async def _post_form(
        self,
        path: str,
        data: dict[str, str],
        request_timeout: float = 60.0,
    ) -> tuple[bool, str]:
        """
        POST с application/x-www-form-urlencoded. Релогин на 302/401/403.
        Возвращает (ok, short_message). ok=True если HTTP 200 или 2xx и
        тело не содержит явной ошибки.

        request_timeout: на длинные операции (продление/уменьшение/сброс)
            ставим 60 секунд — иначе 10-секундный таймаут сессии падает,
            а админка тем временем успешно выполняет действие → клиент
            видит ошибку и повторяет, получая двойное продление.
        """
        if not ADMIN_PASSWORD or self._session is None:
            return False, "ADMIN_PASSWORD не задан в .env"

        if not self._authed:
            ok = await self._login()
            if not ok:
                return False, "Не удалось залогиниться в админку"

        url = urljoin(ADMIN_BASE_URL, path.lstrip("/"))

        # Локальный таймаут для этого конкретного запроса — перекрывает
        # короткий глобальный таймаут сессии
        long_timeout = aiohttp.ClientTimeout(total=request_timeout)

        for attempt in (1, 2):
            try:
                async with self._session.post(
                    url,
                    data=data,
                    headers={"X-Requested-With": "XMLHttpRequest"},
                    allow_redirects=False,
                    timeout=long_timeout,
                ) as resp:
                    if resp.status in (302, 303):
                        location = resp.headers.get("Location", "")
                        if "login" in location:
                            self._authed = False
                            if attempt == 1:
                                ok = await self._login()
                                if ok:
                                    continue
                            return False, "Сессия истекла, попробуй ещё раз"
                        # Админка часто отвечает 302 на /users — это успех
                        return True, "OK"

                    if resp.status in (401, 403):
                        self._authed = False
                        if attempt == 1:
                            ok = await self._login()
                            if ok:
                                continue
                        return False, f"Доступ запрещён (HTTP {resp.status})"

                    if resp.status == 404:
                        return False, "Клиент не найден в админке (404)"

                    if resp.status >= 500:
                        return False, f"Админка вернула HTTP {resp.status}"

                    if resp.status == 200:
                        # Может быть JSON {ok: true} или HTML страницы — оба норм
                        ct = resp.headers.get("Content-Type", "")
                        if "application/json" in ct:
                            try:
                                payload = await resp.json()
                            except (aiohttp.ContentTypeError, ValueError):
                                return True, "OK"
                            if isinstance(payload, dict):
                                if payload.get("ok") is False or payload.get("error"):
                                    return False, str(
                                        payload.get("error")
                                        or payload.get("message")
                                        or "Ошибка"
                                    )
                            return True, "OK"
                        # HTML-ответ: считаем успехом, если не вернулась форма логина
                        text = await resp.text()
                        if "<form" in text and "password" in text.lower():
                            self._authed = False
                            if attempt == 1:
                                ok = await self._login()
                                if ok:
                                    continue
                            return False, "Сессия истекла"
                        return True, "OK"

                    return False, f"Неожиданный статус HTTP {resp.status}"

            except asyncio.TimeoutError:
                if attempt == 2:
                    return False, "Таймаут запроса"
            except aiohttp.ClientError as e:
                if attempt == 2:
                    return False, f"Ошибка сети: {e}"

        return False, "Не удалось выполнить запрос"

    async def extend_subscription(
        self,
        telegram_id: int,
        days: int,
        notify_user: bool = True,
    ) -> tuple[bool, str]:
        """Продлить подписку клиента на N дней.

        Эндпоинт админки: POST /users/{id}/renew (form-urlencoded).
        notify_user=True попросит админку отправить клиенту уведомление.
        """
        if days <= 0 or days > 3650:
            return False, "Количество дней должно быть от 1 до 3650"

        body: dict[str, str] = {"days": str(days)}
        if notify_user:
            body["notify_user"] = "1"

        ok, msg = await self._post_form(f"users/{telegram_id}/renew", body)
        # Инвалидируем кэш — подписка изменилась
        self.invalidate(telegram_id)
        if ok:
            return True, f"Подписка продлена на {days} дн."
        return False, msg

    async def reduce_subscription(
        self,
        telegram_id: int,
        days: int,
    ) -> tuple[bool, str]:
        """Уменьшить срок подписки на N дней.

        Эндпоинт админки: POST /users/{id}/reduce (form-urlencoded).
        Клиента НЕ уведомляем (нет такого флага у эндпоинта).
        """
        if days <= 0 or days > 3650:
            return False, "Количество дней должно быть от 1 до 3650"

        ok, msg = await self._post_form(
            f"users/{telegram_id}/reduce",
            {"days": str(days)},
        )
        self.invalidate(telegram_id)
        if ok:
            return True, f"Срок уменьшен на {days} дн."
        return False, msg


# ============================================================
#  Singleton + удобный геттер
# ============================================================

_client: AdminPanelClient | None = None


def get_client() -> AdminPanelClient:
    global _client
    if _client is None:
        _client = AdminPanelClient()
    return _client


# ============================================================
#  Форматирование шапки тикета
# ============================================================

def _bytes_to_gb(val: Any) -> str:
    """Байты → '12.34 GB' или '—'."""
    try:
        n = float(val)
        if n <= 0:
            return "—"
        return f"{n / (1024 ** 3):.2f} GB"
    except (TypeError, ValueError):
        return "—"


def _fmt_date(val: Any) -> str:
    """ISO-дата → 'дд.мм.гггг чч:мм' (без часового пояса) или '—'."""
    if not val:
        return "—"
    try:
        from datetime import datetime
        # Принимаем как ISO с Z, так и без
        s = str(val).replace("Z", "+00:00")
        dt = datetime.fromisoformat(s)
        return dt.strftime("%d.%m.%Y %H:%M")
    except (ValueError, TypeError):
        return str(val)


def format_user_block(payload: dict | None) -> str:
    """
    Собирает HTML-блок для шапки тикета из payload /api/users/{id}.
    Возвращает пустую строку, если данных нет (бот тогда покажет шапку
    без расширенной инфы, как раньше).

    Поля устойчивы к отсутствию ключей: если что-то не пришло, просто
    пропускаем строку.
    """
    if not payload or not isinstance(payload, dict):
        return ""

    data = payload.get("data") if "data" in payload else payload
    if not isinstance(data, dict):
        return ""

    user = data.get("user") or {}
    remna = data.get("remnawave") or {}

    if not user:
        return ""

    lines: list[str] = ["", "<b>📊 Данные клиента из админки:</b>"]

    # Статус подписки
    end_date = user.get("subscription_end_date")
    if end_date:
        from datetime import datetime, timezone
        try:
            s = str(end_date).replace("Z", "+00:00")
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            now = datetime.now(tz=timezone.utc)
            expired = dt < now
            status = "🔴 истекла" if expired else "🟢 активна"
            lines.append(f"• Подписка: {status} ({_fmt_date(end_date)})")
        except (ValueError, TypeError):
            lines.append(f"• Подписка до: {_fmt_date(end_date)}")

    # Блокировка
    if user.get("is_blocked"):
        lines.append("• ⛔ <b>Аккаунт заблокирован в админке</b>")

    # Провайдер
    provider = user.get("subscription_provider") or "x-ui"
    provider_label = "Remnawave" if provider == "remnawave" else "X-UI"
    lines.append(f"• Провайдер: {provider_label}")

    # Лимит устройств
    limit_ip = user.get("limit_ip")
    if limit_ip is not None:
        limit_str = "∞ (без лимита)" if not limit_ip else str(limit_ip)
        lines.append(f"• Лимит устройств: {limit_str}")

    # Дата регистрации
    created = user.get("created_at")
    if created:
        lines.append(f"• Зарегистрирован: {_fmt_date(created)}")

    # Доп. триал
    free_renewal = user.get("free_renewal_used")
    if free_renewal in (1, True, "1"):
        lines.append("• 🎁 Доп. триал: получен")

    # Тег
    tag = user.get("user_tag")
    if tag:
        lines.append(f"• Тег: {tag}")

    # Remnawave-инфа (если есть)
    if isinstance(remna, dict) and (remna.get("username") or remna.get("uuid")):
        traffic = remna.get("user_traffic") or {}
        used = traffic.get("used_traffic_bytes")
        limit = remna.get("traffic_limit_bytes")
        if used is not None or limit is not None:
            used_str = _bytes_to_gb(used) if used is not None else "—"
            limit_str = _bytes_to_gb(limit) if limit else "∞"
            lines.append(f"• Трафик Remnawave: {used_str} / {limit_str}")

        online_at = traffic.get("online_at")
        if online_at:
            from datetime import datetime, timezone
            try:
                s = str(online_at).replace("Z", "+00:00")
                dt = datetime.fromisoformat(s)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                now = datetime.now(tz=timezone.utc)
                diff = (now - dt).total_seconds()
                if diff < 300:
                    lines.append("• 🟢 Сейчас онлайн (Remnawave)")
                else:
                    lines.append(
                        f"• Последний онлайн: {_fmt_date(online_at)}"
                    )
            except (ValueError, TypeError):
                pass

    if len(lines) == 2:
        # Кроме заголовка ничего не добавилось
        return ""

    return "\n".join(lines)


def format_security_block(payload: dict | None) -> str:
    """
    Краткая выжимка из /api/users/{id}/security: количество устройств +
    последний IP/ОС. Полный список устройств не вставляем (это шапка
    тикета, а не отчёт).
    """
    if not payload or not isinstance(payload, dict):
        return ""

    devices = payload.get("devices") or []
    latest = payload.get("latest_access") or {}

    if not devices and not latest:
        return ""

    lines: list[str] = ["", "<b>🔐 Безопасность:</b>"]

    if devices:
        lines.append(f"• Уникальных устройств: {len(devices)}")

    if latest:
        ip = latest.get("ip_address")
        os_name = latest.get("os")
        os_ver = latest.get("os_version")
        model = latest.get("model")
        when = latest.get("access_time")

        device_str_parts = []
        if os_name:
            device_str_parts.append(
                f"{os_name} {os_ver}".strip() if os_ver else os_name
            )
        if model:
            device_str_parts.append(model)
        device_str = " · ".join(device_str_parts) if device_str_parts else None

        if ip:
            lines.append(f"• Последний IP: <code>{ip}</code>")
        if device_str:
            lines.append(f"• Последнее устройство: {device_str}")
        if when:
            lines.append(f"• Последний запрос: {_fmt_date(when)}")

    if len(lines) == 2:
        return ""

    return "\n".join(lines)


async def build_ticket_info_block(telegram_id: int) -> str:
    """
    Главная функция для main.py.

    Собирает расширенный блок с инфой клиента из админки. Если что-то
    недоступно — возвращает пустую строку, тикет создаётся без блока.
    """
    if not ADMIN_PASSWORD:
        return ""

    client = get_client()
    if client._session is None:
        # На случай, если кто-то забыл вызвать start()
        await client.start()

    try:
        # Запрашиваем параллельно, чтобы не ждать по очереди
        user_data, security_data = await asyncio.gather(
            client.get_user(telegram_id),
            client.get_security(telegram_id),
            return_exceptions=True,
        )
    except Exception as e:
        logger.warning(
            "admin_panel: не удалось собрать инфу по {}: {}",
            telegram_id, e,
        )
        return ""

    parts: list[str] = []

    if not isinstance(user_data, Exception):
        block = format_user_block(user_data)
        if block:
            parts.append(block)

    if not isinstance(security_data, Exception):
        block = format_security_block(security_data)
        if block:
            parts.append(block)

    return "\n".join(parts)


# ============================================================
#  РАСШИРЕННЫЙ БЛОК ДЛЯ ПОДМЕНЮ «🛠 Админка»
#  Подробная инфа о клиенте + платежи + Remnawave + устройства
# ============================================================

def _fmt_money(val: Any, currency: str = "₽") -> str:
    try:
        n = float(val)
        return f"{n:.2f} {currency}"
    except (TypeError, ValueError):
        return "—"


def _payment_status_emoji(status: str) -> str:
    return {
        "succeeded": "✅",
        "processing": "⏳",
        "pending": "⏸",
        "canceled": "🚫",
        "failed": "❌",
    }.get(status or "", "•")


def _format_payments_block(payments: list | None, limit: int = 5) -> str:
    if not payments:
        return "\n\n<b>💳 Платежи:</b> нет"

    lines = ["", "<b>💳 Последние платежи:</b>"]
    for p in payments[:limit]:
        if not isinstance(p, dict):
            continue
        status = p.get("status") or ""
        emoji = _payment_status_emoji(status)
        amount = _fmt_money(p.get("amount") or p.get("price") or 0, p.get("currency") or "₽")
        date = _fmt_date(p.get("created_at"))
        method = p.get("payment_method") or "—"
        # тариф
        tariff = "—"
        title = p.get("tariff_title")
        info = p.get("tariff_info") or {}
        if title:
            tariff = title
        elif isinstance(info, dict):
            if info.get("days"):
                tariff = f"{info.get('days')} дн."
            elif info.get("traffic_gb"):
                tariff = f"+{info.get('traffic_gb')} GB"

        lines.append(
            f"  {emoji} {amount} · {tariff} · {method}\n"
            f"     <i>{date}</i>"
        )
    if len(payments) > limit:
        lines.append(f"  <i>…и ещё {len(payments) - limit}</i>")
    return "\n".join(lines)


def _format_remnawave_block(remna: dict | None) -> str:
    if not remna or not isinstance(remna, dict):
        return ""
    if not (remna.get("username") or remna.get("uuid")):
        return ""

    lines = ["", "<b>🌐 Remnawave:</b>"]
    if remna.get("username"):
        lines.append(f"  • Username: <code>{remna['username']}</code>")
    if remna.get("status"):
        status_emoji = {"active": "🟢", "inactive": "🔴"}.get(remna["status"], "⚪")
        lines.append(f"  • Статус: {status_emoji} {remna['status'].upper()}")

    traffic = remna.get("user_traffic") or {}
    used = traffic.get("used_traffic_bytes")
    limit = remna.get("traffic_limit_bytes")
    if used is not None or limit is not None:
        used_str = _bytes_to_gb(used) if used is not None else "—"
        limit_str = _bytes_to_gb(limit) if limit else "∞"
        lines.append(f"  • Трафик: {used_str} / {limit_str}")

    lifetime = traffic.get("lifetime_used_traffic_bytes")
    if lifetime:
        lines.append(f"  • За всё время: {_bytes_to_gb(lifetime)}")

    online_at = traffic.get("online_at")
    if online_at:
        from datetime import datetime, timezone
        try:
            s = str(online_at).replace("Z", "+00:00")
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            diff = (datetime.now(tz=timezone.utc) - dt).total_seconds()
            if diff < 300:
                lines.append("  • 🟢 Сейчас онлайн")
            else:
                lines.append(f"  • Последний онлайн: {_fmt_date(online_at)}")
        except (ValueError, TypeError):
            pass

    return "\n".join(lines)


def _format_devices_block(security: dict | None) -> str:
    if not security or not isinstance(security, dict):
        return ""
    devices = security.get("devices") or []
    latest = security.get("latest_access") or {}
    if not devices and not latest:
        return ""

    lines = ["", "<b>📱 Устройства и доступы:</b>"]
    if devices:
        lines.append(f"  • Всего уникальных: <b>{len(devices)}</b>")
    if latest:
        ip = latest.get("ip_address")
        os_name = latest.get("os")
        os_ver = latest.get("os_version")
        model = latest.get("model")
        when = latest.get("access_time")
        if ip:
            lines.append(f"  • Последний IP: <code>{ip}</code>")
        device_parts = []
        if os_name:
            device_parts.append(f"{os_name} {os_ver}".strip() if os_ver else os_name)
        if model:
            device_parts.append(model)
        if device_parts:
            lines.append(f"  • Последнее устройство: {' · '.join(device_parts)}")
        if when:
            lines.append(f"  • Последний запрос: {_fmt_date(when)}")

    # Топ-3 устройства подробно
    if devices:
        lines.append("")
        lines.append("  <i>Топ устройств:</i>")
        for i, d in enumerate(devices[:3], start=1):
            if not isinstance(d, dict):
                continue
            hwid = d.get("hwid")
            os_n = d.get("os")
            os_v = d.get("os_version")
            count = d.get("access_count")
            os_label = f"{os_n} {os_v}".strip() if os_n and os_v else (os_n or "—")
            hwid_short = (hwid[:12] + "…") if hwid and len(hwid) > 13 else (hwid or "—")
            lines.append(
                f"  {i}. {os_label} · <code>{hwid_short}</code>"
                + (f" · обращений: {count}" if count else "")
            )

    return "\n".join(lines)


async def build_admin_panel_view(telegram_id: int) -> str:
    """
    Большой подробный блок для подменю «🛠 Админка».
    Возвращает HTML-текст, готовый к отправке в Telegram.

    Если админка недоступна — возвращает сообщение об этом,
    чтобы оператор понимал, что произошло.
    """
    if not ADMIN_PASSWORD:
        return (
            "⚠️ <b>Интеграция с админкой не настроена</b>\n\n"
            "Заполни <code>ADMIN_PASSWORD</code> в <code>.env</code>, "
            "чтобы видеть подробную инфу о клиенте."
        )

    client = get_client()
    if client._session is None:
        await client.start()

    try:
        user_data, security_data = await asyncio.gather(
            client.get_user(telegram_id),
            client.get_security(telegram_id),
            return_exceptions=True,
        )
    except Exception as e:
        return f"⚠️ Не удалось получить данные из админки: {e}"

    if isinstance(user_data, Exception) or not user_data:
        return (
            "⚠️ <b>Админка не ответила</b>\n\n"
            f"Клиент: <code>{telegram_id}</code>\n"
            "Проверь доступность панели и пароль в <code>.env</code>."
        )

    # Разбираем payload
    data = user_data.get("data") if isinstance(user_data, dict) and "data" in user_data else user_data
    if not isinstance(data, dict):
        return "⚠️ Неожиданный формат ответа админки"

    user = data.get("user") or {}
    remna = data.get("remnawave") or {}
    payments = data.get("payments") or []

    header = (
        f"🛠 <b>АДМИНКА КЛИЕНТА</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 ID: <code>{telegram_id}</code>"
    )

    # --- Блок 1: Подписка ---
    sub_lines = ["", "<b>📋 Подписка:</b>"]
    end_date = user.get("subscription_end_date")
    if end_date:
        from datetime import datetime, timezone
        try:
            s = str(end_date).replace("Z", "+00:00")
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            now = datetime.now(tz=timezone.utc)
            expired = dt < now
            if expired:
                diff_days = (now - dt).days
                sub_lines.append(
                    f"  • Статус: 🔴 истекла {diff_days} дн. назад"
                )
            else:
                diff_days = (dt - now).days
                sub_lines.append(
                    f"  • Статус: 🟢 активна (ещё {diff_days} дн.)"
                )
            sub_lines.append(f"  • Истекает: {_fmt_date(end_date)}")
        except (ValueError, TypeError):
            sub_lines.append(f"  • Истекает: {_fmt_date(end_date)}")

    provider = user.get("subscription_provider") or "x-ui"
    provider_label = "Remnawave" if provider == "remnawave" else "X-UI"
    sub_lines.append(f"  • Провайдер: {provider_label}")

    limit_ip = user.get("limit_ip")
    if limit_ip is not None:
        limit_str = "∞ (без лимита)" if not limit_ip else f"{limit_ip} устройств"
        sub_lines.append(f"  • Лимит: {limit_str}")

    if user.get("is_blocked"):
        sub_lines.append("  • ⛔ <b>ЗАБЛОКИРОВАН В АДМИНКЕ</b>")

    if user.get("free_renewal_used") in (1, True, "1"):
        sub_lines.append("  • 🎁 Доп. триал: получен")

    created = user.get("created_at")
    if created:
        sub_lines.append(f"  • Регистрация: {_fmt_date(created)}")

    tag = user.get("user_tag")
    if tag:
        sub_lines.append(f"  • Тег: {tag}")

    # --- Блок 2: Платежи ---
    payments_block = _format_payments_block(payments, limit=5)

    # --- Блок 3: Remnawave ---
    remna_block = _format_remnawave_block(remna)

    # --- Блок 4: Устройства ---
    devices_block = ""
    if not isinstance(security_data, Exception) and security_data:
        devices_block = _format_devices_block(security_data)

    parts = [header, "\n".join(sub_lines), payments_block]
    if remna_block:
        parts.append(remna_block)
    if devices_block:
        parts.append(devices_block)

    parts.append("\n━━━━━━━━━━━━━━━━━━━━")

    return "\n".join(parts)
