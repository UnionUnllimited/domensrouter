"""
Иконки топиков — отдельный модуль чтобы и app.main, и app.web_chat_api
видели один и тот же словарь _TOPIC_ICONS.

Проблема которую это решает:
  python -m app.main → импортирует app.main как __main__
  web_chat_api → import app.main → второй экземпляр модуля
В итоге _TOPIC_ICONS существует в двух копиях, одна пустая.

Здесь логика общая.
"""

from __future__ import annotations

from loguru import logger


# Маппинг: символ эмодзи → custom_emoji_id (заполняется в load_topic_icons)
_TOPIC_ICONS: dict[str, str] = {}


# Иконки топиков по роли. Telegram даёт 112 фиксированных эмодзи,
# из которых эти 3 точно есть всегда.
# [v3.5] Активный диалог (tg ИЛИ web) → 💬, чтобы не дублировать
# источник, который уже отражён в имени топика префиксом 📱 / 🌐.
# Visualно в TG: 💬 📱 @user (TG) или 💬 🌐 Алиса (Web).
_TOPIC_ICON_PREFS: dict[str, list[str]] = {
    "tg":     ["💬"],
    "web":    ["💬"],
    "closed": ["✅"],
    "banned": ["🤡"],
}


def pick(role: str, fallback: str) -> str:
    """Подобрать первый доступный эмодзи для роли. Если нет — fallback."""
    for e in _TOPIC_ICON_PREFS.get(role, []):
        if e in _TOPIC_ICONS:
            return e
    return fallback


def get_icon_id(role: str) -> tuple[str | None, str | None]:
    """
    Возвращает (emoji, icon_id) для роли.
    role: 'tg' | 'web' | 'closed' | 'banned'
    Если ни один эмодзи не доступен — (None, None).
    """
    for e in _TOPIC_ICON_PREFS.get(role, []):
        cid = _TOPIC_ICONS.get(e)
        if cid:
            return e, cid
    return None, None


async def load_topic_icons(bot) -> None:
    """
    Получает список доступных эмодзи через getForumTopicIconStickers
    и заполняет _TOPIC_ICONS. Вызывается один раз при старте бота.
    """
    try:
        stickers = await bot.get_forum_topic_icon_stickers()
        for s in stickers:
            emoji = getattr(s, "emoji", None)
            cid = getattr(s, "custom_emoji_id", None)
            if emoji and cid and emoji not in _TOPIC_ICONS:
                _TOPIC_ICONS[emoji] = cid

        logger.info(
            "Topic icons: tg/web={} closed={} banned={} "
            "(всего доступно {} эмодзи)",
            pick("tg", "💬"), pick("closed", "✅"), pick("banned", "🤡"),
            len(_TOPIC_ICONS),
        )
    except Exception as e:
        logger.warning("Не смог получить getForumTopicIconStickers: {}", e)


async def set_topic_icon(
    bot, chat_id: int, topic_id: int, role: str,
) -> None:
    """
    Меняет иконку форум-топика по роли. Если эмодзи недоступен или
    ошибка — тихо игнорирует (logger.debug).
    role: 'tg' | 'web' | 'closed' | 'banned'
    """
    if not topic_id or not chat_id:
        return
    emoji, icon_id = get_icon_id(role)
    if not icon_id:
        logger.debug(
            "set_topic_icon: нет доступной иконки для роли {!r} "
            "(icons загружено: {})", role, len(_TOPIC_ICONS),
        )
        return
    try:
        await bot.edit_forum_topic(
            chat_id=chat_id,
            message_thread_id=topic_id,
            icon_custom_emoji_id=icon_id,
        )
        logger.info(
            "set_topic_icon: топик {} → {} (роль {})",
            topic_id, emoji, role,
        )
    except Exception as e:
        # TOPIC_NOT_MODIFIED = иконка уже та же, не страшно
        msg = str(e)
        if "TOPIC_NOT_MODIFIED" not in msg:
            logger.debug("set_topic_icon failed: {}", e)
